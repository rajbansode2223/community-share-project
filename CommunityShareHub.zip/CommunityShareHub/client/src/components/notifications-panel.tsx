import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, Clock, Heart, Star, Gift, HandHeart, X } from "lucide-react";
import { Notification } from "@shared/schema";

interface NotificationsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NotificationsPanel({ isOpen, onClose }: NotificationsPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: notifications, isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    queryFn: () => fetch("/api/notifications?limit=20").then(res => res.json()),
    enabled: isOpen,
  });

  const markReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      await apiRequest("PATCH", `/api/notifications/${notificationId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to mark notification as read",
        variant: "destructive",
      });
    },
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", "/api/notifications/mark-all-read");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      toast({
        title: "Success",
        description: "All notifications marked as read",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to mark all notifications as read",
        variant: "destructive",
      });
    },
  });

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "claim_approved":
        return <CheckCircle className="h-4 w-4 text-success-custom" />;
      case "claim_received":
        return <Gift className="h-4 w-4 text-primary-custom" />;
      case "pickup_reminder":
        return <Clock className="h-4 w-4 text-warning-custom" />;
      case "rating_request":
        return <Star className="h-4 w-4 text-accent-custom" />;
      case "new_post_nearby":
        return <Heart className="h-4 w-4 text-error-custom" />;
      default:
        return <Gift className="h-4 w-4 text-medium-custom" />;
    }
  };

  const getNotificationBgColor = (type: string, isRead: boolean) => {
    if (isRead) return "";
    
    switch (type) {
      case "claim_approved":
        return "bg-green-50";
      case "pickup_reminder":
        return "bg-yellow-50";
      case "rating_request":
        return "bg-blue-50";
      case "new_post_nearby":
        return "bg-red-50";
      default:
        return "bg-blue-50";
    }
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const notificationDate = new Date(date);
    const diffInMs = now.getTime() - notificationDate.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return notificationDate.toLocaleDateString();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 md:relative md:inset-auto">
      {/* Mobile backdrop */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 md:hidden"
        onClick={onClose}
      />
      
      {/* Panel */}
      <div className="fixed top-0 right-0 h-full w-full max-w-sm bg-white shadow-xl md:absolute md:top-16 md:right-4 md:h-auto md:max-h-96 md:w-80 md:rounded-lg md:border md:border-gray-200 z-50">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <h3 className="font-semibold text-dark-custom">Notifications</h3>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => markAllReadMutation.mutate()}
                disabled={markAllReadMutation.isPending || !notifications?.some(n => !n.isRead)}
                className="text-primary-custom text-sm hover:text-primary-custom/80"
              >
                Mark all read
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="md:hidden"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-hidden">
            {isLoading ? (
              <div className="p-4 space-y-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="animate-pulse flex items-start space-x-3 p-3">
                    <div className="w-4 h-4 bg-gray-200 rounded-full"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : notifications?.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                <Gift className="h-12 w-12 text-medium-custom opacity-50 mb-4" />
                <h4 className="font-medium text-dark-custom mb-2">No notifications</h4>
                <p className="text-sm text-medium-custom">
                  You're all caught up! Notifications will appear here when you have updates.
                </p>
              </div>
            ) : (
              <ScrollArea className="h-full">
                <div className="p-4 space-y-1">
                  {notifications?.map(notification => (
                    <div
                      key={notification.id}
                      className={`flex items-start space-x-3 p-3 rounded-lg cursor-pointer transition-colors hover:bg-gray-50 ${
                        getNotificationBgColor(notification.type, notification.isRead)
                      }`}
                      onClick={() => !notification.isRead && markReadMutation.mutate(notification.id)}
                    >
                      <div className="mt-1">
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <h4 className={`text-sm font-medium text-dark-custom ${
                            !notification.isRead ? "font-semibold" : ""
                          }`}>
                            {notification.title}
                          </h4>
                          {!notification.isRead && (
                            <div className="w-2 h-2 bg-primary-custom rounded-full ml-2 mt-1 flex-shrink-0"></div>
                          )}
                        </div>
                        <p className="text-sm text-medium-custom mt-1 line-clamp-2">
                          {notification.message}
                        </p>
                        <p className="text-xs text-medium-custom mt-2">
                          {formatTimeAgo(notification.createdAt)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>

          {/* Footer */}
          {notifications && notifications.length > 0 && (
            <div className="border-t border-gray-200 p-4">
              <Button 
                variant="ghost" 
                className="w-full text-center text-primary-custom hover:text-primary-custom/80"
                onClick={() => {
                  // In a real app, this would navigate to a full notifications page
                  toast({
                    title: "Coming Soon",
                    description: "Full notifications view will be available soon",
                  });
                }}
              >
                View all notifications
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
