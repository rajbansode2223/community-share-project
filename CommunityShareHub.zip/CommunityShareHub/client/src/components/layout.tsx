import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Home,
  Building2,
  Heart,
  Calendar,
  MapPin,
  Stethoscope,
  Building,
  Users,
  Camera,
  MessageCircle,
  HelpCircle,
  Utensils,
  TrendingUp,
  ChevronLeft,
  ChevronRight,
  Shirt,
  Handshake,
  UserCheck,
  Target,
  Bell,
  Menu,
  X,
  User,
  LogOut
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import NotificationsPanel from "@/components/notifications-panel";
import UserProfileMenu from "@/components/user-profile-menu";

const navigationItems = [
  {
    title: "Browse",
    href: "/",
    icon: Home,
    description: "Discover food sharing opportunities"
  },
  {
    title: "Adopt Communities",
    href: "/adopt-a-slum",
    icon: Building2,
    description: "Support underserved communities"
  },
  {
    title: "Care Institutions",
    href: "/care-institutions",
    icon: Heart,
    description: "Connect with orphanages & elderly care"
  },
  {
    title: "Event Pickup",
    href: "/event-food-pickup",
    icon: Calendar,
    description: "Coordinate event food collection"
  },
  {
    title: "Donation Centers",
    href: "/donation-centers",
    icon: MapPin,
    description: "Find nearby donation points"
  },
  {
    title: "Medical Aid",
    href: "/medical-aid",
    icon: Stethoscope,
    description: "Healthcare support & supplies"
  },
  {
    title: "Corporate CSR",
    href: "/corporate-csr",
    icon: Building,
    description: "Business social responsibility"
  },
  {
    title: "Meal Partners",
    href: "/meal-partners",
    icon: Utensils,
    description: "Restaurant partnerships"
  },
  {
    title: "Community Impact",
    href: "/community-impact",
    icon: TrendingUp,
    description: "View impact statistics"
  },
  {
    title: "Photo Stories",
    href: "/photo-stories",
    icon: Camera,
    description: "Share inspiring moments"
  },
  {
    title: "Chat",
    href: "/chat",
    icon: MessageCircle,
    description: "Connect with community"
  },
  {
    title: "Help & Support",
    href: "/help-support",
    icon: HelpCircle,
    description: "Get assistance"
  }
];

const additionalItems = [
  {
    title: "Clothing Donations",
    href: "/clothing-donations",
    icon: Shirt,
    description: "Donate and receive clothing"
  },
  {
    title: "Community Partnerships",
    href: "/community-partnerships",
    icon: Handshake,
    description: "Partner organizations"
  },
  {
    title: "Volunteer Registration",
    href: "/volunteer-registration",
    icon: UserCheck,
    description: "Join our volunteer network"
  },
  {
    title: "Volunteer Missions",
    href: "/volunteer-missions",
    icon: Target,
    description: "Active volunteer opportunities"
  },
  {
    title: "Group Givers",
    href: "/group-givers",
    icon: Users,
    description: "Collective giving initiatives"
  }
];

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { user } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);

  const { data: unreadCount } = useQuery<{ count: number }>({
    queryKey: ["/api/notifications/unread-count"],
    refetchInterval: 30000,
  });

  const isActive = (href: string) => {
    if (href === "/") {
      return location === "/";
    }
    return location.startsWith(href);
  };

  const allItems = [...navigationItems, ...additionalItems];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Header with Motto */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold">FoodShare</span>
            </Link>

            {/* Motto and Aim - Center */}
            <div className="hidden md:flex flex-col items-center text-center">
              <h1 className="text-lg font-semibold text-gray-900">Connecting Hearts Through Food</h1>
              <p className="text-sm text-muted-foreground">Building compassionate communities where no one goes hungry</p>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <Button 
                variant="ghost" 
                size="sm" 
                className="relative"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="h-5 w-5" />
                {unreadCount && unreadCount.count > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 text-xs">
                    {unreadCount.count}
                  </Badge>
                )}
                <span className="sr-only">Notifications</span>
              </Button>

              {/* User Profile Menu */}
              {user ? (
                <UserProfileMenu />
              ) : (
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <User className="h-5 w-5 mr-2" />
                    Sign In
                  </Button>
                  <Button size="sm">
                    Get Started
                  </Button>
                </div>
              )}

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="sm"
                className={`lg:hidden p-2 rounded-lg transition-all duration-200 ${
                  showMobileSidebar 
                    ? "bg-primary/10 text-primary" 
                    : "hover:bg-gray-100"
                }`}
                onClick={() => setShowMobileSidebar(!showMobileSidebar)}
              >
                <div className="relative">
                  <Menu 
                    className={`h-5 w-5 transition-transform duration-200 ${
                      showMobileSidebar ? "rotate-90 opacity-0" : "rotate-0 opacity-100"
                    }`} 
                  />
                  <X 
                    className={`h-5 w-5 absolute inset-0 transition-transform duration-200 ${
                      showMobileSidebar ? "rotate-0 opacity-100" : "-rotate-90 opacity-0"
                    }`} 
                  />
                </div>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Desktop Sidebar */}
        <div className={`hidden lg:block fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white border-r transition-all duration-300 z-40 ${
          sidebarCollapsed ? "w-16" : "w-64"
        }`}>
          {/* Toggle Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="absolute -right-3 top-4 h-6 w-6 rounded-full border bg-white shadow-md"
          >
            {sidebarCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>

          <ScrollArea className="h-full">
            <div className="p-3 space-y-1">
              {allItems.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);
                
                return (
                  <Link key={item.href} href={item.href}>
                    <div className={`group flex items-start space-x-3 p-3 rounded-lg transition-all duration-200 cursor-pointer ${
                      active 
                        ? "bg-primary/10 text-primary border border-primary/20 shadow-sm" 
                        : "hover:bg-gray-50 text-gray-700 hover:shadow-sm"
                    }`}>
                      <div className={`p-1.5 rounded-md transition-colors ${
                        active 
                          ? "bg-primary/10" 
                          : "bg-gray-100 group-hover:bg-gray-200"
                      }`}>
                        <Icon className={`h-4 w-4 ${active ? "text-primary" : "text-gray-600"}`} />
                      </div>
                      {!sidebarCollapsed && (
                        <div className="flex-1 min-w-0 py-0.5">
                          <p className={`font-semibold text-sm leading-tight mb-1 ${active ? "text-primary" : "text-gray-900"}`}>
                            {item.title}
                          </p>
                          <p className="text-xs text-gray-500 leading-relaxed line-clamp-2">
                            {item.description}
                          </p>
                        </div>
                      )}
                      {active && !sidebarCollapsed && (
                        <div className="w-1 h-6 bg-primary rounded-full mt-1"></div>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Mobile Sidebar */}
        {showMobileSidebar && (
          <>
            <div 
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-30 lg:hidden backdrop-enter"
              onClick={() => setShowMobileSidebar(false)}
            />
            <div className="fixed left-0 top-16 h-[calc(100vh-4rem)] w-80 bg-white border-r shadow-2xl z-40 lg:hidden sidebar-enter">
              {/* Mobile Sidebar Header */}
              <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-orange-50 to-red-50">
                <div className="flex items-center space-x-2">
                  <Heart className="h-6 w-6 text-primary" />
                  <h3 className="font-semibold text-gray-900">Navigation</h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowMobileSidebar(false)}
                  className="h-8 w-8 rounded-full"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <ScrollArea className="h-[calc(100%-80px)]">
                <div className="p-4 space-y-2">
                  {allItems.map((item, index) => {
                    const Icon = item.icon;
                    const active = isActive(item.href);
                    
                    return (
                      <Link key={item.href} href={item.href}>
                        <div 
                          className={`flex items-start space-x-3 p-4 rounded-xl transition-all duration-200 cursor-pointer transform hover:scale-[1.02] ${
                            active 
                              ? "bg-gradient-to-r from-primary/10 to-primary/5 text-primary border border-primary/20 shadow-sm" 
                              : "hover:bg-gradient-to-r hover:from-gray-50 hover:to-gray-25 text-gray-700 hover:shadow-sm"
                          }`}
                          onClick={() => setShowMobileSidebar(false)}
                          style={{ 
                            animationDelay: `${index * 50}ms`,
                            animation: showMobileSidebar ? 'slideInLeft 0.3s ease-out forwards' : 'none'
                          }}
                        >
                          <div className={`p-2 rounded-lg ${active ? "bg-primary/10" : "bg-gray-100"}`}>
                            <Icon className={`h-5 w-5 ${active ? "text-primary" : "text-gray-600"}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={`font-semibold text-sm leading-tight ${active ? "text-primary" : "text-gray-900"}`}>
                              {item.title}
                            </p>
                            <p className="text-xs text-gray-500 mt-1.5 leading-relaxed">
                              {item.description}
                            </p>
                          </div>
                          {active && (
                            <div className="w-1 h-8 bg-primary rounded-full"></div>
                          )}
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </ScrollArea>
              
              {/* Mobile Sidebar Footer */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-gray-50 to-transparent border-t">
                <p className="text-xs text-center text-gray-500">
                  Connecting Hearts Through Food 💛
                </p>
              </div>
            </div>
          </>
        )}

        {/* Main Content */}
        <main className={`flex-1 transition-all duration-300 ${
          sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'
        }`}>
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>

      {/* Notifications Panel */}
      {showNotifications && (
        <NotificationsPanel 
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)} 
        />
      )}
    </div>
  );
}