import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Gift, HandHeart, MapPin } from "lucide-react";
import { PostWithAuthor } from "@shared/schema";

interface MapViewProps {
  posts: PostWithAuthor[];
  onBack: () => void;
}

export default function MapView({ posts, onBack }: MapViewProps) {
  const donations = posts.filter(post => post.type === "donation");
  const requests = posts.filter(post => post.type === "request");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-dark-custom">Community Food Map</h1>
          </div>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-secondary-custom rounded-full"></div>
              <span>{donations.length} Donations</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-accent-custom rounded-full"></div>
              <span>{requests.length} Requests</span>
            </div>
          </div>
        </div>
      </div>

      {/* Map Container */}
      <div className="relative h-screen">
        {/* Mock Map Background */}
        <div className="absolute inset-0 bg-gray-200 flex items-center justify-center">
          <div className="text-center text-medium-custom">
            <MapPin className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-semibold mb-2">Interactive Map View</h3>
            <p className="mb-4">This would show a real map with food sharing locations</p>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <div className="bg-white p-4 rounded-lg shadow">
                <Gift className="h-8 w-8 text-secondary-custom mx-auto mb-2" />
                <div className="text-sm font-medium">Food Donations</div>
                <div className="text-xs text-medium-custom">Available for pickup</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <HandHeart className="h-8 w-8 text-accent-custom mx-auto mb-2" />
                <div className="text-sm font-medium">Food Requests</div>
                <div className="text-xs text-medium-custom">People seeking help</div>
              </div>
            </div>
          </div>
        </div>

        {/* Map Pins Overlay */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Mock pin positions - in a real app these would be calculated from coordinates */}
          <div className="absolute top-1/4 left-1/4 pointer-events-auto">
            <div className="bg-secondary-custom text-white p-2 rounded-full shadow-lg cursor-pointer hover:scale-110 transition-transform">
              <Gift className="h-4 w-4" />
            </div>
          </div>
          <div className="absolute top-1/3 right-1/3 pointer-events-auto">
            <div className="bg-accent-custom text-white p-2 rounded-full shadow-lg cursor-pointer hover:scale-110 transition-transform">
              <HandHeart className="h-4 w-4" />
            </div>
          </div>
          <div className="absolute bottom-1/3 left-1/3 pointer-events-auto">
            <div className="bg-primary-custom text-white p-2 rounded-full shadow-lg cursor-pointer hover:scale-110 transition-transform">
              <Gift className="h-4 w-4" />
            </div>
          </div>
          <div className="absolute top-1/2 right-1/4 pointer-events-auto">
            <div className="bg-secondary-custom text-white p-2 rounded-full shadow-lg cursor-pointer hover:scale-110 transition-transform">
              <Gift className="h-4 w-4" />
            </div>
          </div>
        </div>

        {/* Post List Sidebar */}
        <div className="absolute top-0 right-0 w-80 h-full bg-white shadow-lg overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-dark-custom">Nearby Posts</h2>
            <p className="text-sm text-medium-custom">{posts.length} posts in your area</p>
          </div>
          
          <div className="p-4 space-y-4">
            {posts.length === 0 ? (
              <div className="text-center py-8 text-medium-custom">
                <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No posts in this area</p>
              </div>
            ) : (
              posts.map(post => (
                <Card key={post.id} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-dark-custom text-sm truncate flex-1">
                        {post.title}
                      </h4>
                      <Badge 
                        className={`ml-2 ${
                          post.type === "donation" 
                            ? "bg-secondary-custom" 
                            : "bg-accent-custom"
                        } text-white text-xs`}
                      >
                        {post.type}
                      </Badge>
                    </div>
                    <p className="text-xs text-medium-custom mb-2 line-clamp-2">
                      {post.description}
                    </p>
                    <div className="flex items-center text-xs text-medium-custom">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span className="truncate">{post.location}</span>
                    </div>
                    <div className="mt-2 text-xs text-medium-custom">
                      by {post.author.firstName} {post.author.lastName?.charAt(0)}.
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
