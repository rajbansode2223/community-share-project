import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, ThumbsUp, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { PostWithAuthor, User } from "@shared/schema";

interface RatingFormProps {
  post: PostWithAuthor;
  currentUser: User;
  onComplete: () => void;
}

export default function RatingForm({ post, currentUser, onComplete }: RatingFormProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Determine who to rate based on the transaction type
  const userToRate = post.type === "donation" 
    ? post.claimedBy 
    : post.author;
  
  const transactionType = post.type === "donation" ? "donation" : "request";
  const ratingContext = post.type === "donation" 
    ? "How was your experience receiving this donation?"
    : "How was your experience providing this food?";

  const submitRating = useMutation({
    mutationFn: async () => {
      if (!userToRate) throw new Error("No user to rate");
      
      await apiRequest("/api/ratings", "POST", {
        ratedUserId: userToRate.id,
        raterId: currentUser.id,
        postId: post.id,
        rating,
        comment: comment.trim() || null,
        transactionType,
        isVerified: true
      });
    },
    onSuccess: () => {
      toast({
        title: "Rating submitted",
        description: "Thank you for your feedback! This helps build trust in our community.",
      });
      
      // Invalidate relevant caches
      queryClient.invalidateQueries({ queryKey: ["/api/ratings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      onComplete();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Error",
        description: "Failed to submit rating. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (!userToRate) {
    return null;
  }

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <ThumbsUp className="h-5 w-5 mr-2" />
          Rate Your Experience
        </CardTitle>
        <p className="text-sm text-muted-foreground">{ratingContext}</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* User Being Rated */}
        <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
          <Avatar className="w-12 h-12">
            <AvatarImage src={userToRate.profileImageUrl || ""} />
            <AvatarFallback>
              {userToRate.firstName?.[0]}{userToRate.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold">{userToRate.firstName} {userToRate.lastName}</p>
            <Badge variant="secondary" className="text-xs">
              {post.type === "donation" ? "Donor" : "Requester"}
            </Badge>
          </div>
        </div>

        {/* Star Rating */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Overall Rating</label>
          <div className="flex items-center space-x-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="p-1 rounded transition-colors hover:bg-muted"
              >
                <Star
                  className={`h-8 w-8 transition-colors ${
                    star <= (hoveredRating || rating)
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-muted-foreground"
                  }`}
                />
              </button>
            ))}
            {rating > 0 && (
              <span className="ml-2 text-sm text-muted-foreground">
                {rating} star{rating !== 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>

        {/* Comment */}
        <div className="space-y-2">
          <label className="text-sm font-medium flex items-center">
            <MessageSquare className="h-4 w-4 mr-1" />
            Comment (Optional)
          </label>
          <Textarea
            placeholder="Share details about your experience..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={3}
            maxLength={500}
          />
          <p className="text-xs text-muted-foreground">
            {comment.length}/500 characters
          </p>
        </div>

        {/* Transaction Context */}
        <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Badge variant="outline" className="text-xs">
              {post.type === "donation" ? "🎁 Food Donation" : "🤝 Food Request"}
            </Badge>
          </div>
          <p className="text-sm font-medium">{post.title}</p>
          {post.description && (
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
              {post.description}
            </p>
          )}
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-between pt-4 border-t">
          <p className="text-xs text-muted-foreground">
            Ratings help build trust in our community
          </p>
          <Button
            onClick={() => submitRating.mutate()}
            disabled={rating === 0 || submitRating.isPending}
            className="min-w-24"
          >
            {submitRating.isPending ? "Submitting..." : "Submit Rating"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}