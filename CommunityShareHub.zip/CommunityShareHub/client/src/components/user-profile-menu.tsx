import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu";
import { 
  User, 
  Settings, 
  LogOut, 
  Activity,
  Heart,
  Gift,
  Trophy,
  Calendar,
  MapPin,
  Phone,
  Mail,
  Edit,
  Bell,
  Star,
  TrendingUp,
  Users,
  Clock,
  Target
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";

interface UserStats {
  totalDonations: number;
  totalPickups: number;
  impactScore: number;
  badgesEarned: number;
  communitiesHelped: number;
  activeStreaks: number;
  volunteeredHours: number;
  feedbackRating: number;
}

interface RecentActivity {
  id: number;
  type: 'donation' | 'pickup' | 'volunteer' | 'badge' | 'review';
  title: string;
  description: string;
  timestamp: string;
  points?: number;
}

export default function UserProfileMenu() {
  const { user } = useAuth();
  const [showStats, setShowStats] = useState(false);

  const { data: userStats } = useQuery<UserStats>({
    queryKey: ["/api/user/stats"],
    enabled: !!user,
  });

  const { data: recentActivity } = useQuery<RecentActivity[]>({
    queryKey: ["/api/user/recent-activity"],
    enabled: !!user,
  });

  if (!user) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10 ring-2 ring-primary/20">
            <AvatarImage src={user.profileImageUrl || ""} alt={user.firstName || ""} />
            <AvatarFallback className="bg-gradient-to-br from-primary/20 to-secondary/20">
              {user.firstName?.[0]}{user.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          {userStats?.impactScore && userStats.impactScore > 100 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 bg-orange-500 text-white text-xs">
              {Math.floor(userStats.impactScore / 100)}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent className="w-80" align="end" forceMount>
        {/* User Info Header */}
        <div className="flex items-start gap-3 p-4 border-b">
          <Avatar className="h-12 w-12">
            <AvatarImage src={user.profileImageUrl || ""} alt={user.firstName || ""} />
            <AvatarFallback className="bg-gradient-to-br from-primary/20 to-secondary/20">
              {user.firstName?.[0]}{user.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm">
              {user.firstName} {user.lastName}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user.email}
            </p>
            {userStats && (
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="secondary" className="text-xs">
                  <Trophy className="h-3 w-3 mr-1" />
                  Impact: {userStats.impactScore}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  <Heart className="h-3 w-3 mr-1" />
                  {userStats.totalDonations}
                </Badge>
              </div>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowStats(!showStats)}
            className="h-8 w-8 p-0"
          >
            <TrendingUp className="h-4 w-4" />
          </Button>
        </div>

        {/* Quick Stats */}
        {showStats && userStats && (
          <div className="p-3 border-b bg-muted/50">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-1">
                <Gift className="h-3 w-3 text-green-600" />
                <span>{userStats.totalDonations} Donations</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-3 w-3 text-blue-600" />
                <span>{userStats.communitiesHelped} Communities</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3 text-purple-600" />
                <span>{userStats.volunteeredHours}h Volunteer</span>
              </div>
              <div className="flex items-center gap-1">
                <Star className="h-3 w-3 text-yellow-600" />
                <span>{userStats.feedbackRating}/5 Rating</span>
              </div>
            </div>
          </div>
        )}

        {/* Profile Management */}
        <DropdownMenuGroup>
          <DropdownMenuLabel className="text-xs font-medium text-muted-foreground">
            Profile & Settings
          </DropdownMenuLabel>
          <DropdownMenuItem asChild>
            <Link href={`/profile/${user.id}`} className="cursor-pointer">
              <User className="mr-2 h-4 w-4" />
              <span>View Profile</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile/edit" className="cursor-pointer">
              <Edit className="mr-2 h-4 w-4" />
              <span>Edit Profile</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/settings" className="cursor-pointer">
              <Settings className="mr-2 h-4 w-4" />
              <span>Account Settings</span>
            </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        {/* Activity & Progress */}
        <DropdownMenuGroup>
          <DropdownMenuLabel className="text-xs font-medium text-muted-foreground">
            Activity & Progress
          </DropdownMenuLabel>
          <DropdownMenuItem asChild>
            <Link href="/profile/activity" className="cursor-pointer">
              <Activity className="mr-2 h-4 w-4" />
              <span>My Activity</span>
              {recentActivity && recentActivity.length > 0 && (
                <Badge className="ml-auto h-5 w-5 p-0 text-xs">
                  {recentActivity.length}
                </Badge>
              )}
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile/donations" className="cursor-pointer">
              <Gift className="mr-2 h-4 w-4" />
              <span>My Donations</span>
              {userStats?.totalDonations && (
                <span className="ml-auto text-xs text-muted-foreground">
                  {userStats.totalDonations}
                </span>
              )}
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile/pickups" className="cursor-pointer">
              <Calendar className="mr-2 h-4 w-4" />
              <span>My Pickups</span>
              {userStats?.totalPickups && (
                <span className="ml-auto text-xs text-muted-foreground">
                  {userStats.totalPickups}
                </span>
              )}
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile/badges" className="cursor-pointer">
              <Trophy className="mr-2 h-4 w-4" />
              <span>Badges & Achievements</span>
              {userStats?.badgesEarned && (
                <Badge className="ml-auto h-5 w-5 p-0 text-xs bg-yellow-500">
                  {userStats.badgesEarned}
                </Badge>
              )}
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile/impact" className="cursor-pointer">
              <Target className="mr-2 h-4 w-4" />
              <span>Impact Dashboard</span>
            </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        {/* Recent Activity Preview */}
        {recentActivity && recentActivity.length > 0 && (
          <div className="p-3 border-b">
            <div className="text-xs font-medium text-muted-foreground mb-2">
              Recent Activity
            </div>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {recentActivity.slice(0, 3).map((activity) => (
                <div key={activity.id} className="flex items-start gap-2 text-xs">
                  <div className="mt-0.5">
                    {activity.type === 'donation' && <Gift className="h-3 w-3 text-green-600" />}
                    {activity.type === 'pickup' && <Calendar className="h-3 w-3 text-blue-600" />}
                    {activity.type === 'volunteer' && <Users className="h-3 w-3 text-purple-600" />}
                    {activity.type === 'badge' && <Trophy className="h-3 w-3 text-yellow-600" />}
                    {activity.type === 'review' && <Star className="h-3 w-3 text-orange-600" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{activity.title}</p>
                    <p className="text-muted-foreground truncate">{activity.description}</p>
                    <p className="text-muted-foreground">{activity.timestamp}</p>
                  </div>
                  {activity.points && (
                    <Badge className="h-4 text-xs">+{activity.points}</Badge>
                  )}
                </div>
              ))}
            </div>
            <Link href="/profile/activity">
              <Button variant="ghost" size="sm" className="w-full mt-2 h-7 text-xs">
                View All Activity
              </Button>
            </Link>
          </div>
        )}

        <DropdownMenuSeparator />

        {/* Logout */}
        <DropdownMenuItem
          className="cursor-pointer text-destructive focus:text-destructive"
          onClick={() => window.location.href = "/api/logout"}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}