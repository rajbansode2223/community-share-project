import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Users, 
  Truck, 
  Building, 
  Search,
  Navigation,
  Star,
  AlertCircle
} from "lucide-react";
import Navbar from "@/components/navbar";
import { DonationCenterWithDetails } from "@shared/schema";

export default function DonationCenters() {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [sortBy, setSortBy] = useState("distance");

  const { data: centers, isLoading } = useQuery<DonationCenterWithDetails[]>({
    queryKey: ["/api/donation-centers"],
    select: (data) => {
      if (!data) return [];
      
      // Calculate distances if user location is available
      const centersWithDistance = data.map(center => {
        if (userLocation && center.latitude && center.longitude) {
          const distance = calculateDistance(
            userLocation.lat,
            userLocation.lng,
            parseFloat(center.latitude || "0"),
            parseFloat(center.longitude || "0")
          );
          return { ...center, distance };
        }
        return center;
      });

      // Apply filters
      let filtered = centersWithDistance.filter(center => {
        const matchesSearch = !searchQuery || 
          center.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          center.address.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesType = filterType === "all" || center.centerType === filterType;
        
        return matchesSearch && matchesType && center.isActive;
      });

      // Apply sorting
      if (sortBy === "distance" && userLocation) {
        filtered.sort((a, b) => (a.distance || 0) - (b.distance || 0));
      } else if (sortBy === "capacity") {
        filtered.sort((a, b) => ((b.capacity || 0) - (b.currentLoad || 0)) - ((a.capacity || 0) - (a.currentLoad || 0)));
      } else if (sortBy === "name") {
        filtered.sort((a, b) => a.name.localeCompare(b.name));
      }

      return filtered;
    }
  });

  // Get user's location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.warn("Could not get user location:", error);
        }
      );
    }
  }, []);

  // Calculate distance between two points in kilometers
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const getAvailabilityColor = (capacity: number, currentLoad: number) => {
    const percentage = (currentLoad / capacity) * 100;
    if (percentage < 50) return "bg-green-100 text-green-800";
    if (percentage < 80) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getCenterTypeIcon = (type: string) => {
    switch (type) {
      case "collection":
        return <Truck className="h-4 w-4" />;
      case "distribution":
        return <Users className="h-4 w-4" />;
      default:
        return <Building className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen app-bg">
      <Navbar />
      
      {/* Header */}
      <section className="bg-gradient-to-r from-primary/10 to-primary/5 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Donation Centers & NGO Partners
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Find nearby collection and distribution centers to maximize your food donation impact
          </p>
          
          {!userLocation && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 max-w-2xl mx-auto">
              <div className="flex items-center space-x-2">
                <Navigation className="h-5 w-5 text-blue-600" />
                <span className="text-sm text-blue-800">
                  Enable location access to see distances and get personalized recommendations
                </span>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Filters */}
      <section className="bg-white border-b py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search centers by name or location..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2 flex-wrap">
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="collection">Collection Only</SelectItem>
                  <SelectItem value="distribution">Distribution Only</SelectItem>
                  <SelectItem value="both">Collection & Distribution</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="distance">Distance</SelectItem>
                  <SelectItem value="capacity">Availability</SelectItem>
                  <SelectItem value="name">Name</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="h-64">
                <div className="animate-pulse p-6">
                  <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
                  <div className="h-20 bg-muted rounded mb-4"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </div>
              </Card>
            ))}
          </div>
        ) : centers && centers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {centers.map((center) => (
              <Card key={center.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{center.name}</CardTitle>
                    <div className="flex items-center space-x-1">
                      {getCenterTypeIcon(center.centerType)}
                      <Badge variant="outline" className="text-xs">
                        {center.centerType}
                      </Badge>
                    </div>
                  </div>
                  {center.distance && (
                    <div className="flex items-center text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4 mr-1" />
                      {center.distance.toFixed(1)} km away
                    </div>
                  )}
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Description */}
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {center.description}
                  </p>

                  {/* Address */}
                  <div className="flex items-start space-x-2">
                    <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                    <span className="text-sm">{center.address}</span>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-2">
                    {center.contactPhone && (
                      <div className="flex items-center space-x-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{center.contactPhone}</span>
                      </div>
                    )}
                    {center.contactEmail && (
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{center.contactEmail}</span>
                      </div>
                    )}
                  </div>

                  {/* Operating Hours */}
                  {center.operatingHours && (
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        {center.operatingHours || "Check for hours"}
                      </span>
                    </div>
                  )}

                  {/* Capacity */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Capacity</span>
                    <Badge className={getAvailabilityColor(center.capacity || 0, center.currentLoad || 0)}>
                      {(center.capacity || 0) - (center.currentLoad || 0)} spots available
                    </Badge>
                  </div>

                  {/* NGO Partnerships */}
                  {center.partnerships && center.partnerships.length > 0 && (
                    <div>
                      <span className="text-sm font-medium">Partner NGOs:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {center.partnerships.slice(0, 2).map(partnership => (
                          <Badge key={partnership.id} variant="secondary" className="text-xs">
                            {partnership.ngo.name}
                          </Badge>
                        ))}
                        {center.partnerships.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{center.partnerships.length - 2} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      View Details
                    </Button>
                    <Button size="sm" className="flex-1">
                      Schedule Donation
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center p-12">
            <Building className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No donation centers found</h3>
            <p className="text-muted-foreground">
              {searchQuery || filterType !== "all" 
                ? "Try adjusting your search terms or filters"
                : "No donation centers are currently available in your area"
              }
            </p>
          </Card>
        )}
      </main>
    </div>
  );
}