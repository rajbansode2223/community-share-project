import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Activity,
  Gift,
  Calendar,
  Users,
  Trophy,
  Star,
  Filter,
  Download,
  TrendingUp,
  Clock,
  MapPin,
  Heart
} from "lucide-react";

interface ActivityItem {
  id: number;
  type: 'donation' | 'pickup' | 'volunteer' | 'badge' | 'review';
  title: string;
  description: string;
  timestamp: string;
  points?: number;
  location?: string;
  status?: string;
}

interface ActivityStats {
  totalActivities: number;
  thisMonth: number;
  pointsEarned: number;
  streak: number;
}

export default function ProfileActivity() {
  const [filterType, setFilterType] = useState<string>("all");
  const [timeRange, setTimeRange] = useState<string>("all");

  const { data: activities, isLoading: activitiesLoading } = useQuery<ActivityItem[]>({
    queryKey: ["/api/user/activity-history", filterType, timeRange],
  });

  const { data: stats } = useQuery<ActivityStats>({
    queryKey: ["/api/user/activity-stats"],
  });

  const { data: recentActivity } = useQuery<ActivityItem[]>({
    queryKey: ["/api/user/recent-activity"],
  });

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'donation': return <Gift className="h-4 w-4 text-green-600" />;
      case 'pickup': return <Calendar className="h-4 w-4 text-blue-600" />;
      case 'volunteer': return <Users className="h-4 w-4 text-purple-600" />;
      case 'badge': return <Trophy className="h-4 w-4 text-yellow-600" />;
      case 'review': return <Star className="h-4 w-4 text-orange-600" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'donation': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'pickup': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'volunteer': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'badge': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'review': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const mockActivities: ActivityItem[] = [
    {
      id: 1,
      type: 'donation',
      title: 'Food Donation Completed',
      description: 'Donated 5kg rice, 2kg lentils to Downtown Community Center',
      timestamp: '2 hours ago',
      points: 25,
      location: 'Downtown Community Center',
      status: 'completed'
    },
    {
      id: 2,
      type: 'pickup',
      title: 'Restaurant Pickup Coordinated',
      description: 'Successfully coordinated pickup from Metro Restaurant',
      timestamp: '1 day ago',
      points: 15,
      location: 'Metro Restaurant, Main St',
      status: 'completed'
    },
    {
      id: 3,
      type: 'badge',
      title: 'Community Hero Badge Earned',
      description: 'Reached milestone of 10 successful donations',
      timestamp: '3 days ago',
      points: 50,
      status: 'earned'
    },
    {
      id: 4,
      type: 'volunteer',
      title: 'Distribution Center Volunteer',
      description: 'Helped distribute meals to 50+ families at food bank',
      timestamp: '5 days ago',
      points: 30,
      location: 'Central Food Bank',
      status: 'completed'
    },
    {
      id: 5,
      type: 'review',
      title: 'Received 5-Star Review',
      description: 'Excellent service from Sunrise Orphanage',
      timestamp: '1 week ago',
      points: 10,
      location: 'Sunrise Orphanage',
      status: 'received'
    },
    {
      id: 6,
      type: 'donation',
      title: 'Fresh Produce Donation',
      description: 'Donated 10kg fresh vegetables to elderly care home',
      timestamp: '1 week ago',
      points: 35,
      location: 'Golden Years Care Home',
      status: 'completed'
    },
    {
      id: 7,
      type: 'pickup',
      title: 'Bakery Surplus Collection',
      description: 'Collected day-old bread and pastries for shelter',
      timestamp: '2 weeks ago',
      points: 20,
      location: 'Sunshine Bakery',
      status: 'completed'
    },
    {
      id: 8,
      type: 'badge',
      title: 'Early Bird Badge Earned',
      description: 'Completed 5 early morning pickups',
      timestamp: '2 weeks ago',
      points: 25,
      status: 'earned'
    }
  ];

  const displayActivities = activities || mockActivities;
  const filteredActivities = displayActivities.filter(activity => 
    filterType === "all" || activity.type === filterType
  );

  return (
    <div className="container mx-auto py-8 px-4 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Activity History</h1>
        <p className="text-muted-foreground">Track your food sharing journey and impact</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{displayActivities.length}</p>
                <p className="text-sm text-muted-foreground">Total Activities</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl font-bold">4</p>
                <p className="text-sm text-muted-foreground">This Month</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">210</p>
                <p className="text-sm text-muted-foreground">Points Earned</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">7</p>
                <p className="text-sm text-muted-foreground">Day Streak</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Actions */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Activities</SelectItem>
              <SelectItem value="donation">Donations</SelectItem>
              <SelectItem value="pickup">Pickups</SelectItem>
              <SelectItem value="volunteer">Volunteer</SelectItem>
              <SelectItem value="badge">Badges</SelectItem>
              <SelectItem value="review">Reviews</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2 ml-auto">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <Tabs defaultValue="timeline" className="w-full">
        <TabsList>
          <TabsTrigger value="timeline">Timeline View</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
              <CardDescription>
                Your latest food sharing activities and contributions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredActivities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start space-x-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <div className="mt-1">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium">{activity.title}</h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            {activity.description}
                          </p>
                          {activity.location && (
                            <div className="flex items-center mt-2 text-xs text-muted-foreground">
                              <MapPin className="h-3 w-3 mr-1" />
                              {activity.location}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-2 ml-4">
                          <Badge className={getTypeColor(activity.type)}>
                            {activity.type}
                          </Badge>
                          {activity.points && (
                            <Badge variant="secondary">+{activity.points} pts</Badge>
                          )}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {activity.timestamp}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="summary" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Activity Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Gift className="h-4 w-4 text-green-600" />
                      <span>Donations</span>
                    </div>
                    <Badge>3</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span>Pickups</span>
                    </div>
                    <Badge>2</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 text-purple-600" />
                      <span>Volunteer Work</span>
                    </div>
                    <Badge>1</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Trophy className="h-4 w-4 text-yellow-600" />
                      <span>Badges Earned</span>
                    </div>
                    <Badge>2</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Impact Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Meals Provided</span>
                    <span className="font-bold">127</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Families Helped</span>
                    <span className="font-bold">45</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Food Saved (kg)</span>
                    <span className="font-bold">85.5</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Carbon Footprint Reduced</span>
                    <span className="font-bold">34 kg CO₂</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Badges & Achievements</CardTitle>
              <CardDescription>Recognition for your food sharing contributions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg text-center">
                  <Trophy className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                  <h4 className="font-medium">Community Hero</h4>
                  <p className="text-sm text-muted-foreground">10+ successful donations</p>
                  <Badge className="mt-2">Earned</Badge>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <Clock className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <h4 className="font-medium">Early Bird</h4>
                  <p className="text-sm text-muted-foreground">5+ early morning pickups</p>
                  <Badge className="mt-2">Earned</Badge>
                </div>
                <div className="p-4 border rounded-lg text-center opacity-50">
                  <Heart className="h-8 w-8 text-red-600 mx-auto mb-2" />
                  <h4 className="font-medium">Compassionate Giver</h4>
                  <p className="text-sm text-muted-foreground">25+ donations needed</p>
                  <Badge variant="outline" className="mt-2">12/25</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}