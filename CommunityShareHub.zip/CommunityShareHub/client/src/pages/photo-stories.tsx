import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Camera, 
  Heart, 
  MessageCircle, 
  Share2, 
  Plus, 
  Image as ImageIcon,
  MapPin,
  Calendar,
  Users,
  Award,
  Eye,
  EyeOff,
  Verified,
  Star,
  TrendingUp
} from "lucide-react";
import Navbar from "@/components/navbar";

interface PhotoStory {
  id: number;
  userId: string;
  postId?: number;
  title: string;
  description: string;
  beforePhotoUrl?: string;
  afterPhotoUrl: string;
  category: string;
  location: string;
  impactMetrics: {
    people_fed?: number;
    meals_distributed?: number;
    families_helped?: number;
    animals_fed?: number;
  };
  isPublic: boolean;
  isVerified: boolean;
  verifiedBy?: string;
  tags: string[];
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  featuredAt?: string;
  createdAt: string;
  user: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
  isLikedByUser?: boolean;
}

export default function PhotoStories() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedStory, setSelectedStory] = useState<PhotoStory | null>(null);

  const { data: stories = [], isLoading } = useQuery<PhotoStory[]>({
    queryKey: ["/api/photo-stories", selectedCategory],
    enabled: !!user,
  });

  const { data: featuredStories = [] } = useQuery<PhotoStory[]>({
    queryKey: ["/api/photo-stories/featured"],
    enabled: !!user,
  });

  const createStoryMutation = useMutation({
    mutationFn: async (storyData: any) => {
      return apiRequest("/api/photo-stories", "POST", storyData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photo-stories"] });
      setShowCreateModal(false);
      toast({
        title: "Success",
        description: "Your photo story has been shared!",
      });
    },
  });

  const likeStoryMutation = useMutation({
    mutationFn: async (storyId: number) => {
      return apiRequest(`/api/photo-stories/${storyId}/like`, "POST");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photo-stories"] });
    },
  });

  const shareStoryMutation = useMutation({
    mutationFn: async ({ storyId, platform }: { storyId: number; platform: string }) => {
      return apiRequest(`/api/photo-stories/${storyId}/share`, "POST", { platform });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photo-stories"] });
      toast({
        title: "Shared!",
        description: "Story shared successfully",
      });
    },
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'meal_pickup': return '🍽️';
      case 'kids_fed': return '👶';
      case 'strays_fed': return '🐕';
      case 'community_event': return '🎉';
      default: return '📸';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'meal_pickup': return 'Meal Pickup';
      case 'kids_fed': return 'Kids Fed';
      case 'strays_fed': return 'Strays Fed';
      case 'community_event': return 'Community Event';
      default: return 'Other';
    }
  };

  const filteredStories = selectedCategory === "all" 
    ? stories 
    : stories.filter(story => story.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-orange-500 to-pink-500 rounded-full">
              <Camera className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
              Before & After Photo Stories
            </h1>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            📸 <strong>Make impact visible.</strong><br/>
            Share your journey of making a difference through powerful before & after photos
          </p>
        </div>

        {/* Action Bar */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex flex-wrap gap-2">
            {['all', 'meal_pickup', 'kids_fed', 'strays_fed', 'community_event'].map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category ? "bg-orange-600 hover:bg-orange-700" : ""}
              >
                <span className="mr-2">{getCategoryIcon(category)}</span>
                {category === 'all' ? 'All Stories' : getCategoryLabel(category)}
              </Button>
            ))}
          </div>
          
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600">
                <Plus className="h-4 w-4 mr-2" />
                Share Your Story
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5" />
                  Share Your Impact Story
                </DialogTitle>
              </DialogHeader>
              <CreateStoryForm 
                onSubmit={(data) => createStoryMutation.mutate(data)}
                isLoading={createStoryMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="timeline" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="timeline" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Timeline
            </TabsTrigger>
            <TabsTrigger value="featured" className="flex items-center gap-2">
              <Star className="h-4 w-4" />
              Featured
            </TabsTrigger>
            <TabsTrigger value="trending" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Trending
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timeline" className="space-y-6">
            {/* Stories Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStories.map(story => (
                <StoryCard 
                  key={story.id} 
                  story={story}
                  onLike={() => likeStoryMutation.mutate(story.id)}
                  onShare={(platform) => shareStoryMutation.mutate({ storyId: story.id, platform })}
                  onClick={() => setSelectedStory(story)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="featured" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredStories.map(story => (
                <StoryCard 
                  key={story.id} 
                  story={story}
                  onLike={() => likeStoryMutation.mutate(story.id)}
                  onShare={(platform) => shareStoryMutation.mutate({ storyId: story.id, platform })}
                  onClick={() => setSelectedStory(story)}
                  featured={true}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trending" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStories
                .sort((a, b) => (b.likesCount + b.sharesCount) - (a.likesCount + a.sharesCount))
                .slice(0, 9)
                .map(story => (
                  <StoryCard 
                    key={story.id} 
                    story={story}
                    onLike={() => likeStoryMutation.mutate(story.id)}
                    onShare={(platform) => shareStoryMutation.mutate({ storyId: story.id, platform })}
                    onClick={() => setSelectedStory(story)}
                  />
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Story Detail Modal */}
        {selectedStory && (
          <Dialog open={!!selectedStory} onOpenChange={() => setSelectedStory(null)}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <StoryDetailView 
                story={selectedStory}
                onLike={() => likeStoryMutation.mutate(selectedStory.id)}
                onShare={(platform) => shareStoryMutation.mutate({ storyId: selectedStory.id, platform })}
              />
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}

function StoryCard({ 
  story, 
  onLike, 
  onShare, 
  onClick, 
  featured = false 
}: { 
  story: PhotoStory; 
  onLike: () => void; 
  onShare: (platform: string) => void; 
  onClick: () => void;
  featured?: boolean;
}) {
  return (
    <Card className={`hover:shadow-lg transition-shadow cursor-pointer ${
      featured ? 'ring-2 ring-yellow-400 dark:ring-yellow-600' : ''
    }`} onClick={onClick}>
      <div className="relative">
        {/* Before/After Image Comparison */}
        <div className="grid grid-cols-2 gap-1 p-2">
          {story.beforePhotoUrl && (
            <div className="relative">
              <img 
                src={story.beforePhotoUrl} 
                alt="Before" 
                className="w-full h-32 object-cover rounded-lg"
              />
              <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                Before
              </div>
            </div>
          )}
          <div className="relative">
            <img 
              src={story.afterPhotoUrl} 
              alt="After" 
              className="w-full h-32 object-cover rounded-lg"
            />
            <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
              After
            </div>
          </div>
        </div>
        
        {featured && (
          <div className="absolute top-2 right-2 bg-yellow-400 text-yellow-900 text-xs px-2 py-1 rounded-full flex items-center gap-1">
            <Star className="h-3 w-3" />
            Featured
          </div>
        )}
        
        {story.isVerified && (
          <div className="absolute bottom-2 right-2 bg-blue-500 text-white p-1 rounded-full">
            <Verified className="h-3 w-3" />
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="font-semibold text-lg mb-1">{story.title}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
              <span className="text-lg">{getCategoryIcon(story.category)}</span>
              <span>{getCategoryLabel(story.category)}</span>
              {story.isPublic ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
            </div>
          </div>
        </div>
        
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-3 line-clamp-2">
          {story.description}
        </p>
        
        {/* Impact Metrics */}
        <div className="flex flex-wrap gap-2 mb-3">
          {story.impactMetrics.people_fed && (
            <Badge variant="secondary" className="text-xs">
              👥 {story.impactMetrics.people_fed} people fed
            </Badge>
          )}
          {story.impactMetrics.animals_fed && (
            <Badge variant="secondary" className="text-xs">
              🐕 {story.impactMetrics.animals_fed} animals fed
            </Badge>
          )}
          {story.impactMetrics.meals_distributed && (
            <Badge variant="secondary" className="text-xs">
              🍽️ {story.impactMetrics.meals_distributed} meals
            </Badge>
          )}
        </div>
        
        {/* User Info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-r from-orange-400 to-pink-400 rounded-full flex items-center justify-center text-white text-xs font-bold">
              {story.user.firstName?.[0]}
            </div>
            <span className="text-sm text-gray-600 dark:text-gray-300">
              {story.user.firstName} {story.user.lastName}
            </span>
          </div>
          <div className="text-xs text-gray-500">
            {new Date(story.createdAt).toLocaleDateString()}
          </div>
        </div>
        
        {/* Engagement Stats */}
        <div className="flex items-center gap-4 mt-3 pt-3 border-t">
          <button 
            onClick={(e) => { e.stopPropagation(); onLike(); }}
            className={`flex items-center gap-1 text-sm ${
              story.isLikedByUser ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
            }`}
          >
            <Heart className={`h-4 w-4 ${story.isLikedByUser ? 'fill-current' : ''}`} />
            {story.likesCount}
          </button>
          <div className="flex items-center gap-1 text-sm text-gray-500">
            <MessageCircle className="h-4 w-4" />
            {story.commentsCount}
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); onShare('internal'); }}
            className="flex items-center gap-1 text-sm text-gray-500 hover:text-blue-500"
          >
            <Share2 className="h-4 w-4" />
            {story.sharesCount}
          </button>
        </div>
      </CardContent>
    </Card>
  );
}

function CreateStoryForm({ onSubmit, isLoading }: { onSubmit: (data: any) => void; isLoading: boolean }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    location: '',
    isPublic: true,
    beforePhotoUrl: '',
    afterPhotoUrl: '',
    impactMetrics: {
      people_fed: 0,
      meals_distributed: 0,
      animals_fed: 0,
    },
    tags: [] as string[],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Story Title</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="Give your story a compelling title..."
          required
        />
      </div>
      
      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Tell the story behind your photos..."
          rows={3}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="category">Category</Label>
          <Select onValueChange={(value) => setFormData({ ...formData, category: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="meal_pickup">🍽️ Meal Pickup</SelectItem>
              <SelectItem value="kids_fed">👶 Kids Fed</SelectItem>
              <SelectItem value="strays_fed">🐕 Strays Fed</SelectItem>
              <SelectItem value="community_event">🎉 Community Event</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="Where did this happen?"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="beforePhoto">Before Photo URL</Label>
          <Input
            id="beforePhoto"
            value={formData.beforePhotoUrl}
            onChange={(e) => setFormData({ ...formData, beforePhotoUrl: e.target.value })}
            placeholder="Optional: URL to before photo"
          />
        </div>
        
        <div>
          <Label htmlFor="afterPhoto">After Photo URL</Label>
          <Input
            id="afterPhoto"
            value={formData.afterPhotoUrl}
            onChange={(e) => setFormData({ ...formData, afterPhotoUrl: e.target.value })}
            placeholder="URL to after photo"
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="peopleFed">People Fed</Label>
          <Input
            id="peopleFed"
            type="number"
            min="0"
            value={formData.impactMetrics.people_fed}
            onChange={(e) => setFormData({ 
              ...formData, 
              impactMetrics: { 
                ...formData.impactMetrics, 
                people_fed: parseInt(e.target.value) || 0 
              } 
            })}
          />
        </div>
        
        <div>
          <Label htmlFor="mealsDistributed">Meals Distributed</Label>
          <Input
            id="mealsDistributed"
            type="number"
            min="0"
            value={formData.impactMetrics.meals_distributed}
            onChange={(e) => setFormData({ 
              ...formData, 
              impactMetrics: { 
                ...formData.impactMetrics, 
                meals_distributed: parseInt(e.target.value) || 0 
              } 
            })}
          />
        </div>
        
        <div>
          <Label htmlFor="animalsFed">Animals Fed</Label>
          <Input
            id="animalsFed"
            type="number"
            min="0"
            value={formData.impactMetrics.animals_fed}
            onChange={(e) => setFormData({ 
              ...formData, 
              impactMetrics: { 
                ...formData.impactMetrics, 
                animals_fed: parseInt(e.target.value) || 0 
              } 
            })}
          />
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <Switch
          id="isPublic"
          checked={formData.isPublic}
          onCheckedChange={(checked) => setFormData({ ...formData, isPublic: checked })}
        />
        <Label htmlFor="isPublic">Make this story public</Label>
      </div>
      
      <Button type="submit" disabled={isLoading} className="w-full">
        {isLoading ? "Sharing..." : "Share Your Story"}
      </Button>
    </form>
  );
}

function StoryDetailView({ 
  story, 
  onLike, 
  onShare 
}: { 
  story: PhotoStory; 
  onLike: () => void; 
  onShare: (platform: string) => void; 
}) {
  return (
    <div className="space-y-6">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <span className="text-lg">{getCategoryIcon(story.category)}</span>
          {story.title}
          {story.isVerified && <Verified className="h-5 w-5 text-blue-500" />}
        </DialogTitle>
      </DialogHeader>
      
      {/* Photo Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {story.beforePhotoUrl && (
          <div className="space-y-2">
            <h3 className="font-semibold">Before</h3>
            <img 
              src={story.beforePhotoUrl} 
              alt="Before" 
              className="w-full h-64 object-cover rounded-lg"
            />
          </div>
        )}
        <div className="space-y-2">
          <h3 className="font-semibold">After</h3>
          <img 
            src={story.afterPhotoUrl} 
            alt="After" 
            className="w-full h-64 object-cover rounded-lg"
          />
        </div>
      </div>
      
      {/* Story Details */}
      <div className="space-y-4">
        <p className="text-gray-700 dark:text-gray-300">{story.description}</p>
        
        {/* Impact Metrics */}
        <div className="flex flex-wrap gap-2">
          {story.impactMetrics.people_fed && (
            <Badge className="bg-green-100 text-green-800">
              👥 {story.impactMetrics.people_fed} people fed
            </Badge>
          )}
          {story.impactMetrics.animals_fed && (
            <Badge className="bg-blue-100 text-blue-800">
              🐕 {story.impactMetrics.animals_fed} animals fed
            </Badge>
          )}
          {story.impactMetrics.meals_distributed && (
            <Badge className="bg-orange-100 text-orange-800">
              🍽️ {story.impactMetrics.meals_distributed} meals
            </Badge>
          )}
        </div>
        
        {/* Location and Date */}
        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-300">
          {story.location && (
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              {story.location}
            </div>
          )}
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            {new Date(story.createdAt).toLocaleDateString()}
          </div>
        </div>
        
        {/* Engagement Actions */}
        <div className="flex items-center gap-4 pt-4 border-t">
          <button 
            onClick={onLike}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
              story.isLikedByUser 
                ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300' 
                : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
            }`}
          >
            <Heart className={`h-5 w-5 ${story.isLikedByUser ? 'fill-current' : ''}`} />
            {story.likesCount} Likes
          </button>
          
          <button 
            onClick={() => onShare('internal')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
          >
            <Share2 className="h-5 w-5" />
            Share Story
          </button>
        </div>
      </div>
    </div>
  );
}

function getCategoryIcon(category: string) {
  switch (category) {
    case 'meal_pickup': return '🍽️';
    case 'kids_fed': return '👶';
    case 'strays_fed': return '🐕';
    case 'community_event': return '🎉';
    default: return '📸';
  }
}

function getCategoryLabel(category: string) {
  switch (category) {
    case 'meal_pickup': return 'Meal Pickup';
    case 'kids_fed': return 'Kids Fed';
    case 'strays_fed': return 'Strays Fed';
    case 'community_event': return 'Community Event';
    default: return 'Other';
  }
}