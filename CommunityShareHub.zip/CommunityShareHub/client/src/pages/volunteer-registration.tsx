import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { insertVolunteerSchema, type InsertVolunteer, type VolunteerWithStats } from "@shared/schema";
import { Truck, Clock, MapPin, Star, Phone, AlertCircle, CheckCircle2 } from "lucide-react";

const vehicleTypes = [
  { value: "walking", label: "Walking", icon: "🚶" },
  { value: "bike", label: "Bicycle", icon: "🚲" },
  { value: "scooter", label: "Scooter/Motorcycle", icon: "🛵" },
  { value: "car", label: "Car", icon: "🚗" },
  { value: "van", label: "Van/Truck", icon: "🚐" },
];

const workingDaysOptions = [
  "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"
];

type VolunteerFormData = InsertVolunteer & {
  workingDays: string[];
};

export default function VolunteerRegistration() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: existingVolunteer, isLoading } = useQuery({
    queryKey: ["/api/volunteers/profile"],
    enabled: isAuthenticated,
  });

  const form = useForm<VolunteerFormData>({
    resolver: zodResolver(insertVolunteerSchema.extend({
      workingDays: insertVolunteerSchema.shape.workingDays,
    })),
    defaultValues: {
      userId: user?.id || "",
      vehicleType: "car",
      availabilityZone: "",
      maxDistance: 10,
      phoneNumber: "",
      isActive: true,
      availableFrom: "09:00",
      availableTo: "18:00",
      workingDays: [],
      emergencyContact: "",
      notes: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: VolunteerFormData) => {
      return await apiRequest("/api/volunteers/register", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Registration Successful!",
        description: "Welcome to our volunteer delivery team. You'll be notified of nearby delivery opportunities.",
      });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: VolunteerFormData) => {
      return await apiRequest("/api/volunteers/profile", {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your volunteer profile has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: VolunteerFormData) => {
    setIsSubmitting(true);
    try {
      if (existingVolunteer) {
        await updateMutation.mutateAsync(data);
      } else {
        await registerMutation.mutateAsync(data);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-8 text-center">
            <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Authentication Required</h2>
            <p className="text-gray-600 mb-4">Please log in to register as a volunteer delivery driver.</p>
            <Button onClick={() => window.location.href = '/api/login'}>
              Log In to Continue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Truck className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">
            {existingVolunteer ? "Update Volunteer Profile" : "Become a Delivery Volunteer"}
          </h1>
        </div>
        <p className="text-lg text-gray-600">
          Join our community of volunteers helping deliver food to those in need. Make a difference during your travels or free time.
        </p>
      </div>

      {/* Benefits Section */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="font-semibold mb-2">Flexible Locations</h3>
            <p className="text-sm text-gray-600">Choose your service area and work in familiar neighborhoods</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="font-semibold mb-2">Your Schedule</h3>
            <p className="text-sm text-gray-600">Set your own availability and accept deliveries when convenient</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="font-semibold mb-2">Community Impact</h3>
            <p className="text-sm text-gray-600">Help reduce food waste while supporting community members</p>
          </CardContent>
        </Card>
      </div>

      {existingVolunteer && (
        <Card className="mb-8 border-green-200 bg-green-50">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-6 w-6 text-green-600" />
              <div>
                <h3 className="font-semibold text-green-800">Active Volunteer</h3>
                <p className="text-green-600">
                  Rating: {existingVolunteer.rating?.toFixed(1)} ⭐ | 
                  Deliveries: {existingVolunteer.totalDeliveries} | 
                  Status: {existingVolunteer.isVerified ? "Verified" : "Pending Verification"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Registration Form */}
      <Card>
        <CardHeader>
          <CardTitle>Volunteer Information</CardTitle>
          <CardDescription>
            Tell us about yourself and your availability to help with food deliveries
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Vehicle Type */}
              <FormField
                control={form.control}
                name="vehicleType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transportation Method</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your vehicle type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vehicleTypes.map((vehicle) => (
                          <SelectItem key={vehicle.value} value={vehicle.value}>
                            {vehicle.icon} {vehicle.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Service Area */}
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="availabilityZone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Area</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Downtown, North Side, University District" {...field} />
                      </FormControl>
                      <FormDescription>
                        Specify the area where you're willing to make deliveries
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="maxDistance"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Distance (km)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="1" 
                          max="50" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 10)}
                        />
                      </FormControl>
                      <FormDescription>
                        How far are you willing to travel for deliveries?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Contact Information */}
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="phoneNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="+1 (555) 123-4567" {...field} />
                      </FormControl>
                      <FormDescription>
                        Used for delivery coordination and emergencies
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="emergencyContact"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Emergency Contact</FormLabel>
                      <FormControl>
                        <Input placeholder="Name and phone number" {...field} />
                      </FormControl>
                      <FormDescription>
                        Someone to contact in case of emergency
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Availability */}
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="availableFrom"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Available From</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="availableTo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Available Until</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Working Days */}
              <FormField
                control={form.control}
                name="workingDays"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Available Days</FormLabel>
                    <div className="grid grid-cols-4 gap-2">
                      {workingDaysOptions.map((day) => (
                        <div key={day} className="flex items-center space-x-2">
                          <Checkbox
                            id={day}
                            checked={field.value?.includes(day)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                field.onChange([...(field.value || []), day]);
                              } else {
                                field.onChange(field.value?.filter((d) => d !== day));
                              }
                            }}
                          />
                          <label
                            htmlFor={day}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                          >
                            {day.slice(0, 3)}
                          </label>
                        </div>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Notes */}
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Information</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Any special skills, equipment, or preferences (e.g., insulated bags, cooler, can handle large orders)" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Submit Button */}
              <div className="flex gap-4">
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  {isSubmitting ? "Processing..." : existingVolunteer ? "Update Profile" : "Register as Volunteer"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Information Section */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5" />
            What to Expect
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Verification Process</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Background check (may be required)</li>
                <li>• Phone verification</li>
                <li>• Vehicle documentation (if applicable)</li>
                <li>• Safety training materials</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Delivery Process</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Receive delivery requests via app</li>
                <li>• Accept or decline based on availability</li>
                <li>• Pickup and deliver with photo confirmation</li>
                <li>• Rate and provide feedback</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}