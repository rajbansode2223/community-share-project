import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Store, 
  MapPin, 
  Clock, 
  Users, 
  Star, 
  Trophy, 
  TrendingUp, 
  FileText, 
  DollarSign,
  CheckCircle,
  Calendar,
  Phone,
  Mail,
  Heart,
  Award,
  PieChart,
  BookOpen,
  Utensils,
  ShieldCheck
} from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";

// Form schemas
const mealPartnerSchema = z.object({
  restaurantName: z.string().min(2, "Restaurant name is required"),
  ownerName: z.string().min(2, "Owner name is required"),
  email: z.string().email("Valid email required"),
  phoneNumber: z.string().min(10, "Valid phone number required"),
  address: z.string().min(10, "Complete address required"),
  cuisineType: z.string().min(1, "Cuisine type required"),
  businessLicense: z.string().optional(),
  gstNumber: z.string().optional(),
  mealsPerDay: z.number().min(1, "Must offer at least 1 meal per day"),
  mealTypes: z.array(z.string()).min(1, "Select at least one meal type"),
  operatingHours: z.string().min(5, "Operating hours required"),
  specialDietaryOptions: z.array(z.string()).optional(),
});

const reservationSchema = z.object({
  mealPartnerId: z.number(),
  reservationDate: z.date(),
  mealType: z.string().min(1, "Meal type required"),
  numberOfPeople: z.number().min(1, "Number of people required"),
  specialRequests: z.string().optional(),
});

export default function MealPartners() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("browse");

  // Forms
  const partnerForm = useForm({
    resolver: zodResolver(mealPartnerSchema),
    defaultValues: {
      restaurantName: "",
      ownerName: "",
      email: "",
      phoneNumber: "",
      address: "",
      cuisineType: "",
      businessLicense: "",
      gstNumber: "",
      mealsPerDay: 10,
      mealTypes: [],
      operatingHours: "",
      specialDietaryOptions: [],
    },
  });

  const reservationForm = useForm({
    resolver: zodResolver(reservationSchema),
    defaultValues: {
      mealPartnerId: 0,
      reservationDate: new Date(),
      mealType: "",
      numberOfPeople: 1,
      specialRequests: "",
    },
  });

  // Query meal partners
  const { data: mealPartners = [] } = useQuery({
    queryKey: ["/api/meal-partners"],
  });

  // Query user's reservations
  const { data: userReservations = [] } = useQuery({
    queryKey: ["/api/meal-reservations/my"],
  });

  // Mutations
  const registerPartnerMutation = useMutation({
    mutationFn: async (data: z.infer<typeof mealPartnerSchema>) => {
      return apiRequest("/api/meal-partners", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Registration Successful",
        description: "Your meal partner application has been submitted for review!",
      });
      partnerForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/meal-partners"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const makereservationMutation = useMutation({
    mutationFn: async (data: z.infer<typeof reservationSchema>) => {
      return apiRequest("/api/meal-reservations", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Reservation Confirmed",
        description: "Your free meal has been reserved successfully!",
      });
      reservationForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/meal-reservations/my"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to make reservation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "pending": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "suspended": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
    }
  };

  const getCuisineIcon = (cuisine: string) => {
    switch (cuisine.toLowerCase()) {
      case "indian": return "🍛";
      case "chinese": return "🥢";
      case "italian": return "🍝";
      case "mexican": return "🌮";
      default: return "🍽️";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white dark:bg-gray-800 px-4 py-2 rounded-full shadow-sm mb-4">
            <Store className="h-5 w-5 text-orange-600" />
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Meal Partners Program</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4">
            Restaurant Meal Partners
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Join our network of restaurants providing free meals to those in need. Enjoy tax benefits, CSR compliance, and make a positive community impact.
          </p>
        </div>

        {/* Benefits Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Tax Benefits</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Claim tax deductions for meals provided to underprivileged communities
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">CSR Compliance</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Meet corporate social responsibility requirements and boost your CSR score
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Community Impact</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Build brand reputation while making a meaningful difference in your community
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Interface */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browse" className="flex items-center gap-2">
              <Store className="h-4 w-4" />
              Browse Partners
            </TabsTrigger>
            <TabsTrigger value="register" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Register Restaurant
            </TabsTrigger>
            <TabsTrigger value="reservations" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              My Reservations
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <PieChart className="h-4 w-4" />
              Impact Analytics
            </TabsTrigger>
          </TabsList>

          {/* Browse Partners Tab */}
          <TabsContent value="browse" className="space-y-6">
            <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {mealPartners.map((partner: any) => (
                <Card key={partner.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center">
                          <span className="text-lg">{getCuisineIcon(partner.cuisineType)}</span>
                        </div>
                        <div>
                          <CardTitle className="text-lg">{partner.restaurantName}</CardTitle>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{partner.cuisineType} Cuisine</p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(partner.partnershipStatus)}>
                        {partner.partnershipStatus}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-gray-500" />
                        <span className="text-gray-600 dark:text-gray-400">{partner.address}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span className="text-gray-600 dark:text-gray-400">{partner.operatingHours}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <Utensils className="h-4 w-4 text-gray-500" />
                        <span className="text-gray-600 dark:text-gray-400">
                          {partner.mealsPerDay} meals/day
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="text-gray-600 dark:text-gray-400">
                          {partner.averageRating || "0.0"} ({partner.totalRatings || 0} reviews)
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-1 mt-3">
                        {partner.mealTypes?.map((type: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>

                      {partner.specialDietaryOptions?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {partner.specialDietaryOptions.map((option: string, index: number) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {option}
                            </Badge>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-2 mt-4">
                        <Button 
                          size="sm" 
                          className="flex-1"
                          onClick={() => {
                            reservationForm.setValue("mealPartnerId", partner.id);
                            setActiveTab("reservations");
                          }}
                        >
                          Reserve Meal
                        </Button>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Register Restaurant Tab */}
          <TabsContent value="register" className="space-y-6">
            <Card className="max-w-4xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Store className="h-5 w-5" />
                  Register as Meal Partner
                </CardTitle>
                <p className="text-gray-600 dark:text-gray-400">
                  Join our network of restaurants making a difference in the community
                </p>
              </CardHeader>
              <CardContent>
                <Form {...partnerForm}>
                  <form onSubmit={partnerForm.handleSubmit((data) => registerPartnerMutation.mutate(data))} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={partnerForm.control}
                        name="restaurantName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Restaurant Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter restaurant name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="ownerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Owner Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter owner's full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="restaurant@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter contact number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="cuisineType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cuisine Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select cuisine type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="indian">Indian</SelectItem>
                                <SelectItem value="chinese">Chinese</SelectItem>
                                <SelectItem value="italian">Italian</SelectItem>
                                <SelectItem value="mexican">Mexican</SelectItem>
                                <SelectItem value="continental">Continental</SelectItem>
                                <SelectItem value="fast-food">Fast Food</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="mealsPerDay"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Meals Per Day</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1" 
                                placeholder="Number of free meals daily"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="operatingHours"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Operating Hours</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., 9:00 AM - 10:00 PM" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="businessLicense"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business License (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="Business license number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={partnerForm.control}
                        name="gstNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>GST Number (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="GST registration number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={partnerForm.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Complete Address</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Enter complete restaurant address with landmarks"
                              className="min-h-[80px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Alert>
                      <ShieldCheck className="h-4 w-4" />
                      <AlertDescription>
                        By registering, you agree to provide free meals to community members in need and maintain food safety standards. Our team will verify your restaurant before activation.
                      </AlertDescription>
                    </Alert>

                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={registerPartnerMutation.isPending}
                    >
                      {registerPartnerMutation.isPending ? "Submitting..." : "Submit Application"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reservations Tab */}
          <TabsContent value="reservations" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Make New Reservation */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Reserve Free Meal
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...reservationForm}>
                    <form onSubmit={reservationForm.handleSubmit((data) => makereservationMutation.mutate(data))} className="space-y-4">
                      <FormField
                        control={reservationForm.control}
                        name="mealPartnerId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Restaurant</FormLabel>
                            <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select restaurant" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {mealPartners.filter((p: any) => p.partnershipStatus === 'active').map((partner: any) => (
                                  <SelectItem key={partner.id} value={partner.id.toString()}>
                                    {partner.restaurantName} - {partner.cuisineType}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={reservationForm.control}
                        name="mealType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Meal Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select meal type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="breakfast">Breakfast</SelectItem>
                                <SelectItem value="lunch">Lunch</SelectItem>
                                <SelectItem value="dinner">Dinner</SelectItem>
                                <SelectItem value="snacks">Snacks</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={reservationForm.control}
                        name="numberOfPeople"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Number of People</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1" 
                                max="10"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={reservationForm.control}
                        name="specialRequests"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Special Requests (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Any dietary restrictions or special requests..."
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={makereservationMutation.isPending}
                      >
                        {makereservationMutation.isPending ? "Reserving..." : "Reserve Meal"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>

              {/* User's Reservations */}
              <Card>
                <CardHeader>
                  <CardTitle>Your Reservations</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    {userReservations.length === 0 ? (
                      <div className="text-center py-8">
                        <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">No reservations yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {userReservations.map((reservation: any) => (
                          <div key={reservation.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-medium">{reservation.mealPartner?.restaurantName}</h4>
                              <Badge className={getStatusColor(reservation.status)}>
                                {reservation.status}
                              </Badge>
                            </div>
                            <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                              <p>{reservation.mealType} for {reservation.numberOfPeople} people</p>
                              <p>{format(new Date(reservation.reservationDate), 'PPP')}</p>
                              {reservation.confirmationCode && (
                                <p className="font-mono text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                                  Code: {reservation.confirmationCode}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Partners</p>
                      <p className="text-2xl font-bold">156</p>
                    </div>
                    <Store className="h-8 w-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Meals Served</p>
                      <p className="text-2xl font-bold">12,450</p>
                    </div>
                    <Utensils className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Tax Benefits</p>
                      <p className="text-2xl font-bold">₹8.5L</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">CSR Score</p>
                      <p className="text-2xl font-bold">94/100</p>
                    </div>
                    <Award className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Partners</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { name: "Spice Garden", meals: 850, rating: 4.8 },
                      { name: "Golden Dragon", meals: 720, rating: 4.7 },
                      { name: "Mama's Kitchen", meals: 680, rating: 4.9 },
                    ].map((partner, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                            index === 0 ? 'bg-yellow-100 text-yellow-800' :
                            index === 1 ? 'bg-gray-100 text-gray-800' :
                            'bg-orange-100 text-orange-800'
                          }`}>
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium">{partner.name}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{partner.meals} meals served</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm font-medium">{partner.rating}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Monthly Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">People Fed</span>
                      <span className="font-bold">2,850</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Food Waste Reduced</span>
                      <span className="font-bold">1.2 tons</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">CO2 Saved</span>
                      <span className="font-bold">320 kg</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Community Reach</span>
                      <span className="font-bold">45 areas</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}