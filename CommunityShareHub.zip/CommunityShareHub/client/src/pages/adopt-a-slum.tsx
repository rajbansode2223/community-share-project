import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/navbar";
import { MapPin, Users, Calendar, Heart, Target, TrendingUp, Star, Clock, Award, CheckCircle } from "lucide-react";

const adoptionSchema = z.object({
  communityId: z.number().min(1, "Please select a community"),
  pledgeType: z.enum(["weekly", "bi_weekly", "monthly", "custom"]),
  targetMeals: z.number().min(10, "Minimum 10 meals required"),
  preferredDay: z.enum(["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]).optional(),
  preferredTime: z.enum(["morning", "afternoon", "evening"]).optional(),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().optional(),
  notes: z.string().optional(),
});

const communityRegistrationSchema = z.object({
  name: z.string().min(3, "Community name must be at least 3 characters"),
  description: z.string().optional(),
  address: z.string().min(10, "Please provide a detailed address"),
  estimatedPopulation: z.number().min(1, "Population estimate is required"),
  contactPerson: z.string().min(2, "Contact person name is required"),
  contactPhone: z.string().min(10, "Valid phone number is required"),
  contactEmail: z.string().email("Valid email is required").optional(),
  accessInstructions: z.string().optional(),
  bestFeedingTimes: z.string().optional(),
  specialNeeds: z.string().optional(),
  safetyConsiderations: z.string().optional(),
});

type AdoptionForm = z.infer<typeof adoptionSchema>;
type CommunityForm = z.infer<typeof communityRegistrationSchema>;

export default function AdoptASlum() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("browse");
  const [showAdoptionForm, setShowAdoptionForm] = useState(false);
  const [showCommunityForm, setShowCommunityForm] = useState(false);
  const [selectedCommunity, setSelectedCommunity] = useState<any>(null);

  const { data: communities, isLoading: communitiesLoading } = useQuery({
    queryKey: ["/api/slum-communities"],
  });

  const { data: myAdoptions, isLoading: adoptionsLoading } = useQuery({
    queryKey: ["/api/restaurant-adoptions", user?.id],
    enabled: !!user,
  });

  const { data: impactStats } = useQuery({
    queryKey: ["/api/adoption-impact"],
  });

  const adoptionForm = useForm<AdoptionForm>({
    resolver: zodResolver(adoptionSchema),
    defaultValues: {
      pledgeType: "weekly",
      targetMeals: 50,
      preferredTime: "afternoon",
    },
  });

  const communityForm = useForm<CommunityForm>({
    resolver: zodResolver(communityRegistrationSchema),
  });

  const adoptionMutation = useMutation({
    mutationFn: async (data: AdoptionForm) => {
      return apiRequest("/api/restaurant-adoptions", {
        method: "POST",
        body: {
          ...data,
          restaurantId: user?.id,
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Community Adopted!",
        description: "Your feeding pledge has been submitted successfully.",
      });
      setShowAdoptionForm(false);
      adoptionForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/restaurant-adoptions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Adoption Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const communityMutation = useMutation({
    mutationFn: async (data: CommunityForm) => {
      return apiRequest("/api/slum-communities", {
        method: "POST",
        body: data,
      });
    },
    onSuccess: () => {
      toast({
        title: "Community Registered!",
        description: "The community has been submitted for verification.",
      });
      setShowCommunityForm(false);
      communityForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/slum-communities"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAdoption = (community: any) => {
    setSelectedCommunity(community);
    adoptionForm.setValue("communityId", community.id);
    setShowAdoptionForm(true);
  };

  const onAdoptionSubmit = (data: AdoptionForm) => {
    adoptionMutation.mutate(data);
  };

  const onCommunitySubmit = (data: CommunityForm) => {
    communityMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Adopt a Community
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Restaurants can pledge to feed one underserved community per week. 
            Create sustainable impact through regular, scheduled community feeding programs.
          </p>
        </div>

        {/* Impact Stats */}
        {impactStats && (
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <Target className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {impactStats.totalCommunities || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">Communities Adopted</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {impactStats.totalPeopleFed?.toLocaleString() || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">People Fed</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Heart className="h-8 w-8 text-red-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {impactStats.totalMeals?.toLocaleString() || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">Meals Served</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {impactStats.activeRestaurants || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">Active Restaurants</div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="browse">Browse Communities</TabsTrigger>
            <TabsTrigger value="my-adoptions">My Adoptions</TabsTrigger>
            <TabsTrigger value="register">Register Community</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                Available Communities
              </h2>
              <Badge variant="secondary" className="text-sm">
                {communities?.length || 0} communities need support
              </Badge>
            </div>

            {communitiesLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {communities?.map((community: any) => (
                  <Card key={community.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{community.name}</CardTitle>
                        <Badge 
                          variant={community.verificationStatus === 'verified' ? 'default' : 'secondary'}
                        >
                          {community.verificationStatus}
                        </Badge>
                      </div>
                      <CardDescription className="text-sm">
                        {community.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                          <MapPin className="h-4 w-4 mr-2" />
                          {community.address}
                        </div>
                        <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                          <Users className="h-4 w-4 mr-2" />
                          ~{community.estimatedPopulation} people
                        </div>
                        {community.lastFeedingDate && (
                          <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                            <Clock className="h-4 w-4 mr-2" />
                            Last fed: {new Date(community.lastFeedingDate).toLocaleDateString()}
                          </div>
                        )}
                        <div className="flex items-center text-sm text-green-600">
                          <Heart className="h-4 w-4 mr-2" />
                          {community.totalPeopleFed} people fed • {community.totalMealsProvided} meals served
                        </div>
                        
                        <Button 
                          onClick={() => handleAdoption(community)}
                          className="w-full mt-4"
                          disabled={community.verificationStatus !== 'verified'}
                        >
                          <Heart className="h-4 w-4 mr-2" />
                          Adopt This Community
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="my-adoptions" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                My Community Adoptions
              </h2>
            </div>

            {adoptionsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : myAdoptions?.length > 0 ? (
              <div className="space-y-4">
                {myAdoptions.map((adoption: any) => (
                  <Card key={adoption.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-xl">{adoption.community.name}</CardTitle>
                          <CardDescription>
                            {adoption.pledgeType} • {adoption.targetMeals} meals per session
                          </CardDescription>
                        </div>
                        <Badge 
                          variant={adoption.status === 'active' ? 'default' : 'secondary'}
                        >
                          {adoption.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-3 gap-6">
                        <div>
                          <h4 className="font-semibold mb-2">Progress</h4>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Feeding Sessions:</span>
                              <span>{adoption.feedingCount}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Total Meals:</span>
                              <span>{adoption.totalMealsDelivered}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>People Fed:</span>
                              <span>{adoption.totalPeopleFed}</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Schedule</h4>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Day:</span>
                              <span className="capitalize">{adoption.preferredDay}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Time:</span>
                              <span className="capitalize">{adoption.preferredTime}</span>
                            </div>
                            {adoption.nextScheduledFeeding && (
                              <div className="flex justify-between text-sm">
                                <span>Next Feeding:</span>
                                <span>{new Date(adoption.nextScheduledFeeding).toLocaleDateString()}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Rating</h4>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 mr-1" />
                            <span>{adoption.averageRating || 'No rating yet'}</span>
                          </div>
                          {adoption.lastFeedingDate && (
                            <div className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                              Last fed: {new Date(adoption.lastFeedingDate).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <Heart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    No Community Adoptions Yet
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Start making a difference by adopting a community today.
                  </p>
                  <Button onClick={() => setActiveTab("browse")}>
                    Browse Communities
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="register" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Register a New Community</CardTitle>
                <CardDescription>
                  Help us identify underserved communities that need regular food support.
                  All registrations will be verified before being made available for adoption.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...communityForm}>
                  <form onSubmit={communityForm.handleSubmit(onCommunitySubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={communityForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Community Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Rajiv Gandhi Slum" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={communityForm.control}
                        name="estimatedPopulation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Estimated Population</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="500"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={communityForm.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Complete Address</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Provide detailed address including nearby landmarks"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={communityForm.control}
                        name="contactPerson"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Person</FormLabel>
                            <FormControl>
                              <Input placeholder="Community leader or representative" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={communityForm.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="+91 9876543210" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={communityForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Community Description (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Brief description of the community and their needs"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={communityForm.control}
                      name="specialNeeds"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Special Needs (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="e.g., Many elderly residents, children, dietary restrictions"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={communityMutation.isPending}
                    >
                      {communityMutation.isPending ? "Registering..." : "Register Community"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Adoption Form Dialog */}
        <Dialog open={showAdoptionForm} onOpenChange={setShowAdoptionForm}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Adopt {selectedCommunity?.name}</DialogTitle>
              <DialogDescription>
                Create a feeding pledge for this community. You'll be responsible for providing regular meals.
              </DialogDescription>
            </DialogHeader>
            <Form {...adoptionForm}>
              <form onSubmit={adoptionForm.handleSubmit(onAdoptionSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={adoptionForm.control}
                    name="pledgeType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Feeding Frequency</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="bi_weekly">Bi-weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="custom">Custom</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={adoptionForm.control}
                    name="targetMeals"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target Meals per Session</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="50"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={adoptionForm.control}
                    name="preferredDay"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Day</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select day" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="monday">Monday</SelectItem>
                            <SelectItem value="tuesday">Tuesday</SelectItem>
                            <SelectItem value="wednesday">Wednesday</SelectItem>
                            <SelectItem value="thursday">Thursday</SelectItem>
                            <SelectItem value="friday">Friday</SelectItem>
                            <SelectItem value="saturday">Saturday</SelectItem>
                            <SelectItem value="sunday">Sunday</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={adoptionForm.control}
                    name="preferredTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Time</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select time" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="morning">Morning (8 AM - 12 PM)</SelectItem>
                            <SelectItem value="afternoon">Afternoon (12 PM - 5 PM)</SelectItem>
                            <SelectItem value="evening">Evening (5 PM - 8 PM)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={adoptionForm.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={adoptionForm.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date (Optional)</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={adoptionForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any special arrangements or considerations"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAdoptionForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={adoptionMutation.isPending}
                  >
                    {adoptionMutation.isPending ? "Creating Pledge..." : "Create Adoption Pledge"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}