import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { 
  Target, 
  Trophy, 
  Clock, 
  Star, 
  Gift, 
  Zap, 
  Medal, 
  Crown,
  Coins,
  Calendar,
  Users,
  Heart,
  Truck,
  UtensilsCrossed,
  MapPin,
  Flame,
  Award
} from "lucide-react";
import Navbar from "@/components/navbar";

interface Mission {
  id: number;
  title: string;
  description: string;
  type: string;
  target: number;
  points: number;
  difficulty: string;
  category: string;
  isActive: boolean;
  startDate: string;
  endDate: string;
  userMission?: {
    progress: number;
    isCompleted: boolean;
  };
  progressPercentage: number;
  timeRemaining: string;
}

interface UserPoints {
  totalPoints: number;
  availableCoins: number;
  currentRank: string;
  rank: number;
  nextRankThreshold: number;
}

interface RewardCoupon {
  id: number;
  title: string;
  description: string;
  discount: string;
  brand: string;
  category: string;
  costInCoins: number;
  validUntil: string;
  isActive: boolean;
}

export default function VolunteerMissions() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { data: missions = [], isLoading: missionsLoading } = useQuery<Mission[]>({
    queryKey: ["/api/missions"],
    enabled: !!user,
  });

  const { data: userPoints } = useQuery<UserPoints>({
    queryKey: ["/api/user-points"],
    enabled: !!user,
  });

  const { data: rewardCoupons = [] } = useQuery<RewardCoupon[]>({
    queryKey: ["/api/reward-coupons"],
    enabled: !!user,
  });

  const { data: leaderboard = [] } = useQuery({
    queryKey: ["/api/missions/leaderboard"],
    enabled: !!user,
  });

  const startMissionMutation = useMutation({
    mutationFn: async (missionId: number) => {
      return apiRequest(`/api/missions/${missionId}/start`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user-points"] });
    },
  });

  const redeemCouponMutation = useMutation({
    mutationFn: async (couponId: number) => {
      return apiRequest(`/api/coupons/${couponId}/redeem`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user-points"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reward-coupons"] });
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'feeding': return <UtensilsCrossed className="h-4 w-4" />;
      case 'delivery': return <Truck className="h-4 w-4" />;
      case 'donation': return <Heart className="h-4 w-4" />;
      case 'community': return <Users className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const filteredMissions = missions.filter(mission => 
    selectedCategory === "all" || mission.category === selectedCategory
  );

  const activeMissions = filteredMissions.filter(m => m.userMission && !m.userMission.isCompleted);
  const availableMissions = filteredMissions.filter(m => !m.userMission);
  const completedMissions = filteredMissions.filter(m => m.userMission?.isCompleted);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
              <Target className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Volunteer Missions
            </h1>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Complete fun challenges, earn Kindness Coins, and unlock amazing rewards while making a difference in your community!
          </p>
        </div>

        {/* User Stats Dashboard */}
        {userPoints && (
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Trophy className="h-8 w-8" />
                  <div>
                    <p className="text-sm opacity-90">Total Points</p>
                    <p className="text-2xl font-bold">{userPoints.totalPoints.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Coins className="h-8 w-8" />
                  <div>
                    <p className="text-sm opacity-90">Kindness Coins</p>
                    <p className="text-2xl font-bold">{userPoints.availableCoins}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Crown className="h-8 w-8" />
                  <div>
                    <p className="text-sm opacity-90">Current Rank</p>
                    <p className="text-lg font-bold">{userPoints.currentRank}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Medal className="h-8 w-8" />
                  <div>
                    <p className="text-sm opacity-90">Leaderboard</p>
                    <p className="text-2xl font-bold">#{userPoints.rank}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="missions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="missions" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Missions
            </TabsTrigger>
            <TabsTrigger value="rewards" className="flex items-center gap-2">
              <Gift className="h-4 w-4" />
              Rewards Store
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="flex items-center gap-2">
              <Trophy className="h-4 w-4" />
              Leaderboard
            </TabsTrigger>
          </TabsList>

          <TabsContent value="missions" className="space-y-6">
            {/* Mission Categories */}
            <div className="flex flex-wrap gap-2 justify-center">
              {['all', 'feeding', 'delivery', 'donation', 'community'].map(category => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory === category ? "bg-purple-600 hover:bg-purple-700" : ""}
                >
                  {getCategoryIcon(category)}
                  <span className="ml-2 capitalize">{category === 'all' ? 'All Missions' : category}</span>
                </Button>
              ))}
            </div>

            {/* Active Missions */}
            {activeMissions.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Flame className="h-6 w-6 text-orange-500" />
                  Active Missions ({activeMissions.length})
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {activeMissions.map(mission => (
                    <Card key={mission.id} className="border-2 border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            {getCategoryIcon(mission.category)}
                            <CardTitle className="text-lg">{mission.title}</CardTitle>
                          </div>
                          <Badge className={getDifficultyColor(mission.difficulty)}>
                            {mission.difficulty}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{mission.description}</p>
                        
                        <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{mission.userMission?.progress || 0}/{mission.target}</span>
                          </div>
                          <Progress value={mission.progressPercentage} className="h-2" />
                          
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-1 text-sm text-purple-600 dark:text-purple-400">
                              <Star className="h-4 w-4" />
                              {mission.points} points
                            </div>
                            <div className="flex items-center gap-1 text-sm text-gray-500">
                              <Clock className="h-4 w-4" />
                              {mission.timeRemaining}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Available Missions */}
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Target className="h-6 w-6 text-blue-500" />
                Available Missions ({availableMissions.length})
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableMissions.map(mission => (
                  <Card key={mission.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getCategoryIcon(mission.category)}
                          <CardTitle className="text-lg">{mission.title}</CardTitle>
                        </div>
                        <Badge className={getDifficultyColor(mission.difficulty)}>
                          {mission.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{mission.description}</p>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1 text-sm text-purple-600 dark:text-purple-400">
                            <Star className="h-4 w-4" />
                            {mission.points} points
                          </div>
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Clock className="h-4 w-4" />
                            {mission.timeRemaining}
                          </div>
                        </div>
                        
                        <Button 
                          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                          onClick={() => startMissionMutation.mutate(mission.id)}
                          disabled={startMissionMutation.isPending}
                        >
                          <Zap className="h-4 w-4 mr-2" />
                          Start Mission
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Completed Missions */}
            {completedMissions.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Award className="h-6 w-6 text-green-500" />
                  Completed Missions ({completedMissions.length})
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {completedMissions.map(mission => (
                    <Card key={mission.id} className="border-2 border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 opacity-75">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            {getCategoryIcon(mission.category)}
                            <CardTitle className="text-lg">{mission.title}</CardTitle>
                          </div>
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                            Completed
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{mission.description}</p>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1 text-sm text-green-600 dark:text-green-400">
                            <Star className="h-4 w-4" />
                            {mission.points} points earned
                          </div>
                          <Trophy className="h-5 w-5 text-green-500" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="rewards" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Gift className="h-6 w-6 text-purple-500" />
                Rewards Store
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Use your Kindness Coins to unlock exclusive discounts and coupons from our partner brands!
              </p>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rewardCoupons.map(coupon => (
                  <Card key={coupon.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{coupon.title}</CardTitle>
                        <Badge variant="secondary">{coupon.category}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <p className="font-semibold text-purple-600 dark:text-purple-400 text-xl">
                            {coupon.discount}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-300">at {coupon.brand}</p>
                        </div>
                        
                        <p className="text-sm text-gray-600 dark:text-gray-300">{coupon.description}</p>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1 text-sm font-semibold">
                            <Coins className="h-4 w-4 text-yellow-500" />
                            {coupon.costInCoins} coins
                          </div>
                          <p className="text-xs text-gray-500">
                            Valid until {new Date(coupon.validUntil).toLocaleDateString()}
                          </p>
                        </div>
                        
                        <Button 
                          className="w-full"
                          variant={userPoints && userPoints.availableCoins >= coupon.costInCoins ? "default" : "outline"}
                          disabled={!userPoints || userPoints.availableCoins < coupon.costInCoins || redeemCouponMutation.isPending}
                          onClick={() => redeemCouponMutation.mutate(coupon.id)}
                        >
                          <Gift className="h-4 w-4 mr-2" />
                          {userPoints && userPoints.availableCoins >= coupon.costInCoins ? "Redeem" : "Not enough coins"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Trophy className="h-6 w-6 text-yellow-500" />
                Community Leaderboard
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                See how you rank against other volunteers in your community!
              </p>
              
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {leaderboard.map((entry: any, index: number) => (
                      <div key={entry.userId} className={`flex items-center gap-4 p-4 rounded-lg ${
                        entry.userId === user?.id ? 'bg-purple-50 dark:bg-purple-900/20 border-2 border-purple-200 dark:border-purple-800' : 'bg-gray-50 dark:bg-gray-800'
                      }`}>
                        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold">
                          {index + 1}
                        </div>
                        
                        <div className="flex-1">
                          <p className="font-semibold">{entry.firstName} {entry.lastName}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-300">{entry.currentRank}</p>
                        </div>
                        
                        <div className="text-right">
                          <p className="font-bold text-purple-600 dark:text-purple-400">{entry.totalPoints.toLocaleString()}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-300">points</p>
                        </div>
                        
                        {index < 3 && (
                          <Medal className={`h-6 w-6 ${
                            index === 0 ? 'text-yellow-500' : 
                            index === 1 ? 'text-gray-400' : 'text-amber-600'
                          }`} />
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}