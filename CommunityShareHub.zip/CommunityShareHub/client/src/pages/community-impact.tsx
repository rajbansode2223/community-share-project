import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  Users, 
  MapPin, 
  TrendingUp, 
  Award, 
  Globe, 
  Utensils, 
  Recycle,
  TreePine,
  Building,
  Target,
  Calendar,
  PieChart,
  BarChart3,
  Activity
} from "lucide-react";
import Navbar from "@/components/navbar";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Cell } from "recharts";

export default function CommunityImpact() {
  // Query community impact data
  const { data: impactData } = useQuery({
    queryKey: ["/api/community-impact"],
    initialData: {
      totalMealsShared: 15420,
      totalUsers: 2845,
      activeCities: 23,
      foodWastePrevented: 8.7, // tons
      co2Saved: 12.5, // tons
      monthlyGrowth: 18.5, // percentage
      topContributors: [
        { name: "Sarah M.", meals: 127, location: "Downtown" },
        { name: "Raj P.", meals: 98, location: "Midtown" },
        { name: "Maria G.", meals: 84, location: "Eastside" }
      ],
      monthlyData: [
        { month: "Jan", meals: 980, users: 145 },
        { month: "Feb", meals: 1240, users: 189 },
        { month: "Mar", meals: 1450, users: 234 },
        { month: "Apr", meals: 1680, users: 298 },
        { month: "May", meals: 1890, users: 356 },
        { month: "Jun", meals: 2150, users: 423 }
      ],
      impactByCategory: [
        { name: "Home Cooked", value: 45, color: "#8884d8" },
        { name: "Restaurant Partners", value: 30, color: "#82ca9d" },
        { name: "Grocery Surplus", value: 15, color: "#ffc658" },
        { name: "Corporate Donations", value: 10, color: "#ff7300" }
      ],
      regionalImpact: [
        { region: "North District", meals: 4200, growth: 23 },
        { region: "South District", meals: 3800, growth: 18 },
        { region: "East District", meals: 3600, growth: 15 },
        { region: "West District", meals: 3820, growth: 21 }
      ]
    }
  });

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white dark:bg-gray-800 px-4 py-2 rounded-full shadow-sm mb-4">
            <Activity className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Community Impact</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4">
            Together We're Making a Difference
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            See the collective impact of our community's food sharing efforts and how we're building a more sustainable future together.
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Utensils className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              </div>
              <div className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-1">
                {formatNumber(impactData.totalMealsShared)}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Meals Shared</div>
              <Badge variant="secondary" className="mt-2">
                <TrendingUp className="h-3 w-3 mr-1" />
                +{impactData.monthlyGrowth}% this month
              </Badge>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-1">
                {formatNumber(impactData.totalUsers)}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Active Users</div>
              <Badge variant="secondary" className="mt-2">
                <Globe className="h-3 w-3 mr-1" />
                {impactData.activeCities} cities
              </Badge>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Recycle className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <div className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-1">
                {impactData.foodWastePrevented}T
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Food Waste Prevented</div>
              <Badge variant="secondary" className="mt-2 bg-green-100 text-green-800">
                <TreePine className="h-3 w-3 mr-1" />
                {impactData.co2Saved}T CO₂ saved
              </Badge>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-1">
                98%
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Satisfaction Rate</div>
              <Badge variant="secondary" className="mt-2 bg-purple-100 text-purple-800">
                <Award className="h-3 w-3 mr-1" />
                Community Choice
              </Badge>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Tabs */}
        <Tabs defaultValue="trends" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="trends" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Growth Trends
            </TabsTrigger>
            <TabsTrigger value="distribution" className="flex items-center gap-2">
              <PieChart className="h-4 w-4" />
              Distribution
            </TabsTrigger>
            <TabsTrigger value="regions" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Regional Impact
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="flex items-center gap-2">
              <Award className="h-4 w-4" />
              Top Contributors
            </TabsTrigger>
          </TabsList>

          {/* Growth Trends Tab */}
          <TabsContent value="trends" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Monthly Meals Shared
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={impactData.monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="meals" 
                        stroke="#8884d8" 
                        fill="#8884d8" 
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    User Growth
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={impactData.monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="users" 
                        stroke="#82ca9d" 
                        strokeWidth={3}
                        dot={{ fill: '#82ca9d', strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Impact Milestones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Impact Milestones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">10K Meals Milestone</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Achieved 2 months ago</div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">20K Meals Goal</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Progress toward next milestone</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">77%</div>
                      <Progress value={77} className="w-24 mt-1" />
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">50 Cities Goal</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Expanding to new regions</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">46%</div>
                      <Progress value={46} className="w-24 mt-1" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Distribution Tab */}
          <TabsContent value="distribution" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Meals by Source</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <Tooltip />
                      <RechartsPieChart data={impactData.impactByCategory}>
                        {impactData.impactByCategory.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </RechartsPieChart>
                    </RechartsPieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-2 mt-4">
                    {impactData.impactByCategory.map((item, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-sm">{item.name}</span>
                        <span className="text-sm font-medium ml-auto">{item.value}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Weekly Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { day: "Monday", meals: 420, percentage: 85 },
                      { day: "Tuesday", meals: 380, percentage: 76 },
                      { day: "Wednesday", meals: 450, percentage: 90 },
                      { day: "Thursday", meals: 410, percentage: 82 },
                      { day: "Friday", meals: 490, percentage: 98 },
                      { day: "Saturday", meals: 520, percentage: 100 },
                      { day: "Sunday", meals: 350, percentage: 70 }
                    ].map((day) => (
                      <div key={day.day} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{day.day}</span>
                          <span className="font-medium">{day.meals} meals</span>
                        </div>
                        <Progress value={day.percentage} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Regional Impact Tab */}
          <TabsContent value="regions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Regional Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={impactData.regionalImpact}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="region" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="meals" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {impactData.regionalImpact.map((region, index) => (
                <Card key={index}>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{formatNumber(region.meals)}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {region.region}
                      </div>
                      <Badge variant="secondary">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        +{region.growth}%
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Top Contributors This Month
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {impactData.topContributors.map((contributor, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                          index === 0 ? 'bg-yellow-100 text-yellow-800' :
                          index === 1 ? 'bg-gray-100 text-gray-800' :
                          'bg-orange-100 text-orange-800'
                        }`}>
                          {index + 1}
                        </div>
                        <div>
                          <div className="font-medium">{contributor.name}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {contributor.location}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{contributor.meals}</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">meals shared</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Most Active Hour</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold">6-7 PM</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Peak sharing time</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Average Response</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold">12 min</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Claim response time</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Success Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold">94%</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Successful pickups</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Call to Action */}
        <Card className="mt-8 bg-gradient-to-r from-green-500 to-blue-600 text-white">
          <CardContent className="pt-6">
            <div className="text-center">
              <Heart className="h-12 w-12 mx-auto mb-4 opacity-90" />
              <h3 className="text-2xl font-bold mb-2">Be Part of the Impact</h3>
              <p className="text-green-100 mb-4">
                Every meal shared brings us closer to a world without food waste. Join our growing community today.
              </p>
              <div className="flex justify-center gap-4">
                <Badge variant="secondary" className="bg-white/20 text-white">
                  <Building className="h-3 w-3 mr-1" />
                  Restaurant Partners
                </Badge>
                <Badge variant="secondary" className="bg-white/20 text-white">
                  <Users className="h-3 w-3 mr-1" />
                  Community Givers
                </Badge>
                <Badge variant="secondary" className="bg-white/20 text-white">
                  <Globe className="h-3 w-3 mr-1" />
                  Global Impact
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}