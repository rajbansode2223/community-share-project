import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Building2, 
  Users, 
  Heart, 
  Truck, 
  Clock, 
  Phone, 
  Mail, 
  CheckCircle,
  AlertCircle,
  Info,
  Award,
  Target,
  Globe
} from "lucide-react";
import Navbar from "@/components/navbar";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const corporateDonationSchema = z.object({
  companyName: z.string().min(2, "Company name must be at least 2 characters"),
  contactPerson: z.string().min(2, "Contact person name is required"),
  contactEmail: z.string().email("Valid email is required"),
  contactPhone: z.string().optional(),
  companyType: z.enum(["restaurant", "grocery", "catering", "food_manufacturer", "retail", "other"]),
  donationType: z.enum(["regular", "surplus", "emergency", "event"]),
  foodItems: z.array(z.string()).min(1, "At least one food item is required"),
  estimatedQuantity: z.string().min(1, "Estimated quantity is required"),
  estimatedCalories: z.number().min(1, "Estimated calories must be positive"),
  frequency: z.enum(["daily", "weekly", "monthly", "occasional"]),
  pickupLocation: z.string().min(5, "Pickup location must be at least 5 characters"),
  pickupTimes: z.string().optional(),
  specialInstructions: z.string().optional(),
  certifications: z.array(z.string()).optional(),
  preferredCenterId: z.number().optional(),
});

type CorporateDonationForm = z.infer<typeof corporateDonationSchema>;

export default function CorporateCSR() {
  const [currentFoodItem, setCurrentFoodItem] = useState("");
  const [currentCertification, setCurrentCertification] = useState("");
  const { toast } = useToast();

  const form = useForm<CorporateDonationForm>({
    resolver: zodResolver(corporateDonationSchema),
    defaultValues: {
      companyType: "restaurant",
      donationType: "regular",
      frequency: "weekly",
      foodItems: [],
      certifications: [],
      estimatedCalories: 0,
    },
  });

  const { data: donationCenters } = useQuery({
    queryKey: ["/api/donation-centers"],
  });

  const submitMutation = useMutation({
    mutationFn: async (data: CorporateDonationForm) => {
      return await apiRequest("/api/corporate-donations", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Your corporate donation application has been submitted for review.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/corporate-donations"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addFoodItem = () => {
    if (currentFoodItem.trim()) {
      const current = form.getValues("foodItems");
      form.setValue("foodItems", [...current, currentFoodItem.trim()]);
      setCurrentFoodItem("");
    }
  };

  const removeFoodItem = (index: number) => {
    const current = form.getValues("foodItems");
    form.setValue("foodItems", current.filter((_, i) => i !== index));
  };

  const addCertification = () => {
    if (currentCertification.trim()) {
      const current = form.getValues("certifications") || [];
      form.setValue("certifications", [...current, currentCertification.trim()]);
      setCurrentCertification("");
    }
  };

  const removeCertification = (index: number) => {
    const current = form.getValues("certifications") || [];
    form.setValue("certifications", current.filter((_, i) => i !== index));
  };

  const onSubmit = (data: CorporateDonationForm) => {
    submitMutation.mutate(data);
  };

  return (
    <div className="min-h-screen app-bg">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600/10 to-green-600/10 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Building2 className="h-16 w-16 mx-auto mb-6 text-blue-600" />
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Corporate Social Responsibility
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Partner with us to make a meaningful impact on food security while fulfilling your corporate social responsibility goals. 
            Together, we can reduce food waste and help communities in need.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Badge variant="secondary" className="text-sm px-4 py-2">
              <Globe className="h-4 w-4 mr-2" />
              UN SDG 2: Zero Hunger
            </Badge>
            <Badge variant="secondary" className="text-sm px-4 py-2">
              <Target className="h-4 w-4 mr-2" />
              WHO Guidelines Compliant
            </Badge>
            <Badge variant="secondary" className="text-sm px-4 py-2">
              <Award className="h-4 w-4 mr-2" />
              UNICEF Partnership Standards
            </Badge>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Guidelines and Information */}
          <div className="lg:col-span-1 space-y-6">
            {/* WHO/UNICEF Guidelines */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Info className="h-5 w-5 mr-2 text-blue-600" />
                  Nutrition Guidelines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">WHO Daily Calorie Requirements</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Adults: 2,000-2,500 calories/day</li>
                    <li>• Children (5-12): 1,600-2,000 calories/day</li>
                    <li>• Adolescents: 2,200-2,800 calories/day</li>
                    <li>• Pregnant women: +300-500 calories/day</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">UNICEF Nutrition Standards</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Balanced macro and micronutrients</li>
                    <li>• Fresh fruits and vegetables priority</li>
                    <li>• Minimal processed food content</li>
                    <li>• Safe food handling practices</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Impact Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Heart className="h-5 w-5 mr-2 text-red-600" />
                  Your Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">1,250,000</div>
                  <div className="text-sm text-muted-foreground">Calories donated by corporations</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">850</div>
                  <div className="text-sm text-muted-foreground">Families fed this month</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">45</div>
                  <div className="text-sm text-muted-foreground">Corporate partners</div>
                </div>
              </CardContent>
            </Card>

            {/* Benefits */}
            <Card>
              <CardHeader>
                <CardTitle>Partnership Benefits</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Tax deduction for food donations
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Enhanced brand reputation
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    ESG compliance reporting
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Employee engagement opportunities
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Community impact metrics
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Application Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Corporate Donation Application</CardTitle>
                <p className="text-muted-foreground">
                  Join our network of corporate partners committed to fighting food insecurity
                </p>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    {/* Company Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Company Information</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="companyName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Company Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your Company Name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="companyType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Company Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="restaurant">Restaurant</SelectItem>
                                  <SelectItem value="grocery">Grocery Store</SelectItem>
                                  <SelectItem value="catering">Catering Service</SelectItem>
                                  <SelectItem value="food_manufacturer">Food Manufacturer</SelectItem>
                                  <SelectItem value="retail">Retail Chain</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="contactPerson"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Contact Person</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="contactEmail"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Contact Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="contact@company.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Phone (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="+1-555-0123" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Donation Details */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Donation Details</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="donationType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Donation Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="regular">Regular Donations</SelectItem>
                                  <SelectItem value="surplus">Surplus Food</SelectItem>
                                  <SelectItem value="emergency">Emergency Relief</SelectItem>
                                  <SelectItem value="event">Event-Based</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="frequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Frequency</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select frequency" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="daily">Daily</SelectItem>
                                  <SelectItem value="weekly">Weekly</SelectItem>
                                  <SelectItem value="monthly">Monthly</SelectItem>
                                  <SelectItem value="occasional">Occasional</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      {/* Food Items */}
                      <div>
                        <FormLabel>Food Items</FormLabel>
                        <div className="flex gap-2 mt-2">
                          <Input
                            placeholder="Add food item (e.g., Fresh vegetables, Prepared meals)"
                            value={currentFoodItem}
                            onChange={(e) => setCurrentFoodItem(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addFoodItem())}
                          />
                          <Button type="button" onClick={addFoodItem} variant="outline">
                            Add
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {form.watch("foodItems").map((item, index) => (
                            <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeFoodItem(index)}>
                              {item} ×
                            </Badge>
                          ))}
                        </div>
                        {form.formState.errors.foodItems && (
                          <p className="text-sm text-red-500 mt-1">{form.formState.errors.foodItems.message}</p>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="estimatedQuantity"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estimated Quantity</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., 50 meals, 100 lbs" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="estimatedCalories"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estimated Calories (Total)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="25000"
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    {/* Logistics */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Logistics</h3>
                      
                      <FormField
                        control={form.control}
                        name="pickupLocation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Pickup Location</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Full address with any specific pickup instructions"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="pickupTimes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preferred Pickup Times (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Mon-Fri 2-4 PM" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="preferredCenterId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preferred Donation Center (Optional)</FormLabel>
                              <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select center" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {donationCenters?.map((center: any) => (
                                    <SelectItem key={center.id} value={center.id.toString()}>
                                      {center.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="specialInstructions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Special Instructions (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Any special handling, storage, or pickup requirements"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Certifications */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Food Safety Certifications (Optional)</h3>
                      
                      <div>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Add certification (e.g., HACCP, FDA, ServSafe)"
                            value={currentCertification}
                            onChange={(e) => setCurrentCertification(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCertification())}
                          />
                          <Button type="button" onClick={addCertification} variant="outline">
                            Add
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {(form.watch("certifications") || []).map((cert, index) => (
                            <Badge key={index} variant="outline" className="cursor-pointer" onClick={() => removeCertification(index)}>
                              {cert} ×
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        All applications are reviewed within 48 hours. We'll contact you to discuss pickup schedules and partnership details.
                      </AlertDescription>
                    </Alert>

                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full"
                      disabled={submitMutation.isPending}
                    >
                      {submitMutation.isPending ? "Submitting..." : "Submit Application"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}