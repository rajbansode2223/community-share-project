import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  Search, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  FileText, 
  Users, 
  HelpCircle,
  Star,
  ThumbsUp,
  ThumbsDown,
  Send,
  Headphones,
  Shield,
  Heart,
  Book,
  UserCheck
} from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";

// Form schemas
const supportTicketSchema = z.object({
  subject: z.string().min(5, "Subject must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  category: z.enum(["technical", "account", "donation", "pickup", "volunteer", "general", "billing", "safety"]),
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
});

const helplineContactSchema = z.object({
  callerName: z.string().min(2, "Name is required"),
  phoneNumber: z.string().min(10, "Valid phone number required"),
  category: z.enum(["emergency", "technical", "volunteer", "donation", "general", "complaint", "feedback"]),
  description: z.string().min(10, "Description is required"),
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
});

const feedbackSchema = z.object({
  feedbackType: z.enum(["general", "suggestion", "complaint"]),
  rating: z.number().min(1).max(5),
  feedback: z.string().min(10, "Feedback must be at least 10 characters"),
  improvementSuggestions: z.string().optional(),
  wouldRecommend: z.boolean().default(true),
});

export default function HelpSupport() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("support");
  const [searchQuery, setSearchQuery] = useState("");

  // Forms
  const ticketForm = useForm({
    resolver: zodResolver(supportTicketSchema),
    defaultValues: {
      subject: "",
      description: "",
      category: "general" as const,
      priority: "medium" as const,
    },
  });

  const helplineForm = useForm({
    resolver: zodResolver(helplineContactSchema),
    defaultValues: {
      callerName: "",
      phoneNumber: "",
      category: "general" as const,
      description: "",
      priority: "medium" as const,
    },
  });

  const feedbackForm = useForm({
    resolver: zodResolver(feedbackSchema),
    defaultValues: {
      feedbackType: "general" as const,
      rating: 5,
      feedback: "",
      improvementSuggestions: "",
      wouldRecommend: true,
    },
  });

  // Query emergency contacts
  const { data: emergencyContacts = [] } = useQuery({
    queryKey: ["/api/support/emergency-contacts"],
  });

  // Query knowledge base articles
  const { data: knowledgeArticles = [] } = useQuery({
    queryKey: ["/api/support/knowledge-base", { search: searchQuery }],
  });

  // Query user's support tickets
  const { data: userTickets = [] } = useQuery({
    queryKey: ["/api/support/tickets/my"],
  });

  // Mutations
  const createTicketMutation = useMutation({
    mutationFn: async (data: z.infer<typeof supportTicketSchema>) => {
      return apiRequest("/api/support/tickets", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Support Ticket Created",
        description: "Your support ticket has been submitted successfully. We'll get back to you soon!",
      });
      ticketForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/support/tickets/my"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create support ticket. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createHelplineContactMutation = useMutation({
    mutationFn: async (data: z.infer<typeof helplineContactSchema>) => {
      return apiRequest("/api/support/helpline", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Helpline Request Submitted",
        description: "Your helpline request has been received. We'll contact you shortly!",
      });
      helplineForm.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit helpline request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const submitFeedbackMutation = useMutation({
    mutationFn: async (data: z.infer<typeof feedbackSchema>) => {
      return apiRequest("/api/support/feedback", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Feedback Submitted",
        description: "Thank you for your feedback! It helps us improve FoodShare.",
      });
      feedbackForm.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit feedback. Please try again.",
        variant: "destructive",
      });
    },
  });

  const voteOnArticleMutation = useMutation({
    mutationFn: async ({ articleId, isHelpful }: { articleId: number; isHelpful: boolean }) => {
      return apiRequest(`/api/support/knowledge-base/${articleId}/vote`, {
        method: "POST",
        body: JSON.stringify({ isHelpful }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/support/knowledge-base"] });
    },
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "high": return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      case "medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "low": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "in-progress": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "resolved": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "closed": return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
      case "escalated": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white dark:bg-gray-800 px-4 py-2 rounded-full shadow-sm mb-4">
            <Headphones className="h-5 w-5 text-orange-600" />
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">24/7 Support Available</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4">
            Help & Support Center
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            We're here to help! Get support through our helpline, email tickets, or browse our knowledge base for quick answers.
          </p>
        </div>

        {/* Quick Contact Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Helpline Support</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Call us for immediate assistance
              </p>
              <div className="space-y-2">
                <p className="font-bold text-lg text-green-600">1-800-FOOD-HELP</p>
                <p className="text-sm text-gray-500">Available 24/7</p>
              </div>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Email Support</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Send us a detailed message
              </p>
              <div className="space-y-2">
                <p className="font-bold text-blue-600">support@foodshare.org</p>
                <p className="text-sm text-gray-500">Response within 2 hours</p>
              </div>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Emergency Line</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                For urgent safety issues
              </p>
              <div className="space-y-2">
                <p className="font-bold text-lg text-red-600">1-800-FOOD-911</p>
                <p className="text-sm text-gray-500">Immediate response</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Support Interface */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="support" className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              Support Tickets
            </TabsTrigger>
            <TabsTrigger value="helpline" className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Helpline
            </TabsTrigger>
            <TabsTrigger value="knowledge" className="flex items-center gap-2">
              <Book className="h-4 w-4" />
              Knowledge Base
            </TabsTrigger>
            <TabsTrigger value="emergency" className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Emergency
            </TabsTrigger>
            <TabsTrigger value="feedback" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              Feedback
            </TabsTrigger>
          </TabsList>

          {/* Support Tickets Tab */}
          <TabsContent value="support" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Create New Ticket */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Create Support Ticket
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...ticketForm}>
                    <form onSubmit={ticketForm.handleSubmit((data) => createTicketMutation.mutate(data))} className="space-y-4">
                      <FormField
                        control={ticketForm.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="technical">Technical Issue</SelectItem>
                                <SelectItem value="account">Account Problem</SelectItem>
                                <SelectItem value="donation">Donation Support</SelectItem>
                                <SelectItem value="pickup">Pickup Assistance</SelectItem>
                                <SelectItem value="volunteer">Volunteer Help</SelectItem>
                                <SelectItem value="general">General Question</SelectItem>
                                <SelectItem value="billing">Billing Issue</SelectItem>
                                <SelectItem value="safety">Safety Concern</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={ticketForm.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select priority" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="low">Low - General inquiry</SelectItem>
                                <SelectItem value="medium">Medium - Standard issue</SelectItem>
                                <SelectItem value="high">High - Urgent matter</SelectItem>
                                <SelectItem value="urgent">Urgent - Critical issue</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={ticketForm.control}
                        name="subject"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Subject</FormLabel>
                            <FormControl>
                              <Input placeholder="Brief description of your issue" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={ticketForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Please provide detailed information about your issue..."
                                className="min-h-[120px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={createTicketMutation.isPending}
                      >
                        {createTicketMutation.isPending ? "Creating..." : "Create Ticket"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>

              {/* Your Tickets */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Your Support Tickets
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    {userTickets.length === 0 ? (
                      <div className="text-center py-8">
                        <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">No support tickets yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {userTickets.map((ticket: any) => (
                          <div key={ticket.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-medium">{ticket.subject}</h4>
                              <div className="flex gap-2">
                                <Badge className={getPriorityColor(ticket.priority)}>
                                  {ticket.priority}
                                </Badge>
                                <Badge className={getStatusColor(ticket.status)}>
                                  {ticket.status}
                                </Badge>
                              </div>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                              {ticket.description}
                            </p>
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <span>Created: {format(new Date(ticket.createdAt), 'MMM dd, yyyy')}</span>
                              {ticket.assignedStaff && (
                                <span>Assigned to: {ticket.assignedStaff.firstName}</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Helpline Tab */}
          <TabsContent value="helpline" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    Request Helpline Callback
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...helplineForm}>
                    <form onSubmit={helplineForm.handleSubmit((data) => createHelplineContactMutation.mutate(data))} className="space-y-4">
                      <FormField
                        control={helplineForm.control}
                        name="callerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={helplineForm.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={helplineForm.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Issue Category</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="emergency">Emergency</SelectItem>
                                <SelectItem value="technical">Technical Support</SelectItem>
                                <SelectItem value="volunteer">Volunteer Help</SelectItem>
                                <SelectItem value="donation">Donation Support</SelectItem>
                                <SelectItem value="general">General Question</SelectItem>
                                <SelectItem value="complaint">Complaint</SelectItem>
                                <SelectItem value="feedback">Feedback</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={helplineForm.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select priority" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="urgent">Urgent</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={helplineForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Describe your issue or question..."
                                className="min-h-[100px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={createHelplineContactMutation.isPending}
                      >
                        {createHelplineContactMutation.isPending ? "Submitting..." : "Request Callback"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Helpline Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert>
                    <Clock className="h-4 w-4" />
                    <AlertDescription>
                      Our helpline is available 24/7 for all your food sharing needs. Average wait time is less than 2 minutes.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-green-600" />
                      <div>
                        <p className="font-semibold">General Support</p>
                        <p className="text-sm text-gray-600">1-800-FOOD-HELP (1-800-366-3435)</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                      <div>
                        <p className="font-semibold">Emergency Line</p>
                        <p className="text-sm text-gray-600">1-800-FOOD-911 (1-800-366-3911)</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Users className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-semibold">Volunteer Support</p>
                        <p className="text-sm text-gray-600">1-800-VOLUNTEER (1-800-865-8683)</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="font-semibold mb-2">What to expect:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Immediate response for emergencies</li>
                      <li>• Professional support agents</li>
                      <li>• Multilingual support available</li>
                      <li>• Follow-up calls when needed</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Knowledge Base Tab */}
          <TabsContent value="knowledge" className="space-y-6">
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input 
                  placeholder="Search knowledge base articles..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {knowledgeArticles.map((article: any) => (
                <Card key={article.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{article.title}</CardTitle>
                    <Badge variant="secondary">{article.category}</Badge>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                      {article.content.substring(0, 150)}...
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>{article.viewCount} views</span>
                        <span>{article.helpfulVotes} helpful</span>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => voteOnArticleMutation.mutate({ articleId: article.id, isHelpful: true })}
                        >
                          <ThumbsUp className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => voteOnArticleMutation.mutate({ articleId: article.id, isHelpful: false })}
                        >
                          <ThumbsDown className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Emergency Tab */}
          <TabsContent value="emergency" className="space-y-6">
            <Alert className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 dark:text-red-200">
                For immediate life-threatening emergencies, call 911 first, then contact our emergency line at 1-800-FOOD-911.
              </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-6">
              {emergencyContacts.map((contact: any) => (
                <Card key={contact.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                      {contact.name}
                    </CardTitle>
                    <Badge variant="secondary">{contact.contactType}</Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-green-600" />
                        <span className="font-semibold">{contact.phoneNumber}</span>
                      </div>
                      {contact.email && (
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-blue-600" />
                          <span>{contact.email}</span>
                        </div>
                      )}
                      {contact.operatingHours && (
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-gray-600" />
                          <span className="text-sm">{contact.operatingHours}</span>
                        </div>
                      )}
                      {contact.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {contact.description}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Feedback Tab */}
          <TabsContent value="feedback" className="space-y-6">
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  Share Your Feedback
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...feedbackForm}>
                  <form onSubmit={feedbackForm.handleSubmit((data) => submitFeedbackMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={feedbackForm.control}
                      name="feedbackType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Feedback Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select feedback type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="general">General Feedback</SelectItem>
                              <SelectItem value="suggestion">Suggestion</SelectItem>
                              <SelectItem value="complaint">Complaint</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={feedbackForm.control}
                      name="rating"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Overall Rating</FormLabel>
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Button
                                key={star}
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => field.onChange(star)}
                              >
                                <Star 
                                  className={`h-5 w-5 ${
                                    star <= field.value 
                                      ? 'text-yellow-400 fill-current' 
                                      : 'text-gray-300'
                                  }`}
                                />
                              </Button>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={feedbackForm.control}
                      name="feedback"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Feedback</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your experience with FoodShare..."
                              className="min-h-[120px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={feedbackForm.control}
                      name="improvementSuggestions"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Suggestions for Improvement (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="How can we make FoodShare better?"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={submitFeedbackMutation.isPending}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      {submitFeedbackMutation.isPending ? "Submitting..." : "Submit Feedback"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}