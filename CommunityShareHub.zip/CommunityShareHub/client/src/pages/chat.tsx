import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { MessageCircle, Clock, MapPin, Check, X, Send, Calendar, Shield, Timer } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

export default function Chat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedChatId, setSelectedChatId] = useState<number | null>(null);
  const [messageText, setMessageText] = useState("");
  const [proposalData, setProposalData] = useState({
    proposedTime: "",
    proposedLocation: "",
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch user's chat rooms
  const { data: chatRooms = [], isLoading: loadingChats } = useQuery({
    queryKey: ["/api/chat/rooms"],
    enabled: !!user,
  });

  // Fetch messages for selected chat
  const { data: messages = [], isLoading: loadingMessages } = useQuery({
    queryKey: ["/api/chat/messages", selectedChatId],
    enabled: !!selectedChatId,
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest(`/api/chat/${selectedChatId}/messages`, "POST", {
        content,
        messageType: "text",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", selectedChatId] });
      queryClient.invalidateQueries({ queryKey: ["/api/chat/rooms"] });
      setMessageText("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // Propose pickup mutation
  const proposePickupMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest(`/api/chat/${selectedChatId}/pickup/propose`, "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", selectedChatId] });
      setProposalData({ proposedTime: "", proposedLocation: "" });
      toast({
        title: "Pickup Proposed",
        description: "Your pickup proposal has been sent",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to propose pickup",
        variant: "destructive",
      });
    },
  });

  // Respond to pickup mutation
  const respondToPickupMutation = useMutation({
    mutationFn: async ({ pickupId, status, responseMessage }: any) => {
      return apiRequest(`/api/chat/pickup/${pickupId}/respond`, "POST", {
        status,
        responseMessage,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", selectedChatId] });
      toast({
        title: "Response Sent",
        description: "Your pickup response has been sent",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to respond to pickup",
        variant: "destructive",
      });
    },
  });

  const selectedChat = chatRooms.find((chat: any) => chat.id === selectedChatId);

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedChatId) return;
    sendMessageMutation.mutate(messageText);
  };

  const handleProposePickup = () => {
    if (!proposalData.proposedTime || !proposalData.proposedLocation) {
      toast({
        title: "Missing Information",
        description: "Please provide both time and location",
        variant: "destructive",
      });
      return;
    }
    proposePickupMutation.mutate(proposalData);
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  const getChatStatus = (chat: any) => {
    const now = new Date();
    const expiresAt = new Date(chat.expiresAt);
    
    if (chat.status === 'expired' || now > expiresAt) {
      return { status: 'expired', color: 'bg-gray-500', text: 'Expired' };
    }
    if (chat.status === 'completed') {
      return { status: 'completed', color: 'bg-green-500', text: 'Completed' };
    }
    if (chat.status === 'pickup_scheduled') {
      return { status: 'scheduled', color: 'bg-blue-500', text: 'Pickup Scheduled' };
    }
    return { status: 'active', color: 'bg-green-500', text: 'Active' };
  };

  if (loadingChats) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <MessageCircle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600 dark:text-gray-300">Loading your conversations...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full">
              <MessageCircle className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">In-App Chat & Pickup Coordination</h1>
              <p className="text-gray-600 dark:text-gray-300">
                Secure, time-limited chat between donors & receivers
              </p>
            </div>
          </div>

          {/* Privacy Notice */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-blue-600" />
              <div>
                <h3 className="font-semibold text-blue-800 dark:text-blue-200">Privacy Protected</h3>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Chats automatically expire after task completion for your privacy and security
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Chat List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Your Conversations ({chatRooms.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {chatRooms.length === 0 ? (
                  <div className="p-6 text-center">
                    <MessageCircle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600 dark:text-gray-300 mb-2">No conversations yet</p>
                    <p className="text-sm text-gray-500">
                      Start chatting when you claim or offer food
                    </p>
                  </div>
                ) : (
                  <div className="divide-y">
                    {chatRooms.map((chat: any) => {
                      const otherUser = chat.donor.id === user?.id ? chat.receiver : chat.donor;
                      const statusInfo = getChatStatus(chat);
                      const timeRemaining = new Date(chat.expiresAt).getTime() - new Date().getTime();
                      const hoursRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60)));

                      return (
                        <div
                          key={chat.id}
                          className={`p-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors ${
                            selectedChatId === chat.id ? 'bg-blue-50 dark:bg-blue-900/20 border-r-4 border-blue-500' : ''
                          }`}
                          onClick={() => setSelectedChatId(chat.id)}
                        >
                          <div className="flex items-start gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={otherUser.profileImageUrl} />
                              <AvatarFallback>
                                {otherUser.firstName?.[0]}{otherUser.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <h3 className="font-semibold text-sm truncate">
                                  {otherUser.firstName} {otherUser.lastName}
                                </h3>
                                <Badge 
                                  variant="secondary" 
                                  className={`${statusInfo.color} text-white text-xs`}
                                >
                                  {statusInfo.text}
                                </Badge>
                              </div>
                              
                              <p className="text-sm text-gray-600 dark:text-gray-300 truncate mb-2">
                                {chat.post.title}
                              </p>
                              
                              {chat.latestMessage && (
                                <p className="text-xs text-gray-500 truncate">
                                  {chat.latestMessage.content}
                                </p>
                              )}
                              
                              <div className="flex items-center justify-between mt-2">
                                {chat.unreadCount > 0 && (
                                  <Badge variant="destructive" className="text-xs">
                                    {chat.unreadCount} new
                                  </Badge>
                                )}
                                
                                {statusInfo.status === 'active' && (
                                  <div className="flex items-center gap-1 text-xs text-orange-600">
                                    <Timer className="h-3 w-3" />
                                    {hoursRemaining}h left
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Chat Interface */}
          <div className="lg:col-span-2">
            {selectedChat ? (
              <Card className="h-[600px] flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={selectedChat.donor.id === user?.id ? selectedChat.receiver.profileImageUrl : selectedChat.donor.profileImageUrl} />
                        <AvatarFallback>
                          {selectedChat.donor.id === user?.id ? 
                            `${selectedChat.receiver.firstName?.[0]}${selectedChat.receiver.lastName?.[0]}` :
                            `${selectedChat.donor.firstName?.[0]}${selectedChat.donor.lastName?.[0]}`
                          }
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">
                          {selectedChat.donor.id === user?.id ? 
                            `${selectedChat.receiver.firstName} ${selectedChat.receiver.lastName}` :
                            `${selectedChat.donor.firstName} ${selectedChat.donor.lastName}`
                          }
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {selectedChat.post.title}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <Badge variant="secondary" className={`${getChatStatus(selectedChat).color} text-white`}>
                        {getChatStatus(selectedChat).text}
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">
                        Expires {formatDistanceToNow(new Date(selectedChat.expiresAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  {loadingMessages ? (
                    <div className="text-center py-8">
                      <p className="text-gray-600 dark:text-gray-300">Loading messages...</p>
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                      <p className="text-gray-600 dark:text-gray-300">No messages yet</p>
                      <p className="text-sm text-gray-500">Start the conversation!</p>
                    </div>
                  ) : (
                    messages.map((message: any) => (
                      <div
                        key={message.id}
                        className={`flex ${message.sender.id === user?.id ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          message.messageType === 'system' 
                            ? 'bg-gray-100 dark:bg-gray-700 text-center text-sm text-gray-600 dark:text-gray-300 mx-auto' 
                            : message.sender.id === user?.id
                              ? 'bg-blue-500 text-white'
                              : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
                        }`}>
                          {message.messageType === 'pickup_confirmation' && (
                            <div className="flex items-center gap-2 mb-2">
                              <Check className="h-4 w-4 text-green-500" />
                              <span className="font-semibold text-green-500">Pickup Confirmed</span>
                            </div>
                          )}
                          
                          <p className="text-sm">{message.content}</p>
                          
                          {message.messageType !== 'system' && (
                            <p className="text-xs opacity-75 mt-1">
                              {formatMessageTime(message.sentAt)}
                            </p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </CardContent>

                {/* Message Input */}
                {getChatStatus(selectedChat).status === 'active' && (
                  <div className="flex-shrink-0 p-4 border-t">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Type your message..."
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        disabled={sendMessageMutation.isPending}
                      />
                      <Button 
                        onClick={handleSendMessage}
                        disabled={sendMessageMutation.isPending || !messageText.trim()}
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>

                    {/* Pickup Coordination */}
                    <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Propose Pickup Time & Location
                      </h4>
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <Input
                          type="datetime-local"
                          value={proposalData.proposedTime}
                          onChange={(e) => setProposalData(prev => ({ ...prev, proposedTime: e.target.value }))}
                          min={new Date().toISOString().slice(0, 16)}
                        />
                        <Input
                          placeholder="Pickup location"
                          value={proposalData.proposedLocation}
                          onChange={(e) => setProposalData(prev => ({ ...prev, proposedLocation: e.target.value }))}
                        />
                      </div>
                      <Button 
                        size="sm" 
                        onClick={handleProposePickup}
                        disabled={proposePickupMutation.isPending}
                        className="w-full"
                      >
                        <MapPin className="h-4 w-4 mr-2" />
                        Propose Pickup
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            ) : (
              <Card className="h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <h3 className="font-semibold text-lg mb-2">Select a Conversation</h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Choose a chat from the list to start messaging
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}