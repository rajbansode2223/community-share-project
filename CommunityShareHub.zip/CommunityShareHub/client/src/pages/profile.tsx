import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Gift, HandHeart, Calendar, MapPin, User } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/navbar";
import PostCard from "@/components/post-card";
import RatingDisplay from "@/components/rating-display";
import { UserWithStats, PostWithAuthor, Rating } from "@shared/schema";

export default function Profile() {
  const { userId } = useParams();
  const { user: currentUser, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  
  const targetUserId = userId || currentUser?.id;
  const isOwnProfile = !userId || userId === currentUser?.id;

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: user, isLoading: userLoading } = useQuery<UserWithStats>({
    queryKey: ["/api/users", targetUserId],
    queryFn: () => fetch(`/api/users/${targetUserId}`).then(res => res.json()),
    enabled: !!targetUserId,
  });

  const { data: userPosts, isLoading: postsLoading, refetch: refetchPosts } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts/user", targetUserId],
    queryFn: () => fetch(`/api/posts/user/${targetUserId}`).then(res => res.json()),
    enabled: !!targetUserId,
  });

  const { data: userRatings, isLoading: ratingsLoading } = useQuery<Rating[]>({
    queryKey: ["/api/users", targetUserId, "ratings"],
    queryFn: () => fetch(`/api/users/${targetUserId}/ratings`).then(res => res.json()),
    enabled: !!targetUserId,
  });

  if (authLoading || userLoading) {
    return (
      <div className="min-h-screen app-bg">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-1/3 mb-6"></div>
            <div className="h-32 bg-muted rounded mb-6"></div>
            <div className="h-64 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen app-bg">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="text-center p-8">
            <User className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-semibold mb-2">User not found</h2>
            <p className="text-muted-foreground">The user you're looking for doesn't exist.</p>
          </Card>
        </div>
      </div>
    );
  }

  const averageRating = parseFloat(user.averageRating || "0");
  const donations = userPosts?.filter(post => post.type === "donation") || [];
  const requests = userPosts?.filter(post => post.type === "request") || [];

  return (
    <div className="min-h-screen app-bg">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
              <Avatar className="w-24 h-24">
                <AvatarImage src={user.profileImageUrl || ""} alt={`${user.firstName} ${user.lastName}`} />
                <AvatarFallback className="text-2xl bg-primary text-primary-foreground">
                  {user.firstName?.[0]}{user.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h1 className="text-3xl font-bold">
                    {user.firstName} {user.lastName}
                  </h1>
                  {isOwnProfile && (
                    <Badge variant="secondary">You</Badge>
                  )}
                </div>
                
                <div className="flex items-center space-x-4 mb-4">
                  <div className="flex items-center">
                    <RatingDisplay rating={averageRating} />
                    <span className="ml-2 text-sm text-muted-foreground">
                      {averageRating.toFixed(1)} • {user.totalRatings} rating{user.totalRatings !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 mr-1" />
                    Joined {new Date(user.createdAt).toLocaleDateString()}
                  </div>
                </div>
                
                <div className="grid grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{donations.length}</div>
                    <div className="text-sm text-muted-foreground flex items-center justify-center">
                      <Gift className="h-3 w-3 mr-1" />
                      Donations
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">{requests.length}</div>
                    <div className="text-sm text-muted-foreground flex items-center justify-center">
                      <HandHeart className="h-3 w-3 mr-1" />
                      Requests
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {donations.filter(d => d.status === 'completed').length + requests.filter(r => r.status === 'completed').length}
                    </div>
                    <div className="text-sm text-muted-foreground">Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{user.totalRatings}</div>
                    <div className="text-sm text-muted-foreground flex items-center justify-center">
                      <Star className="h-3 w-3 mr-1" />
                      Reviews
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content Tabs */}
        <Tabs defaultValue="posts" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="posts" className="flex items-center">
              <Gift className="h-4 w-4 mr-2" />
              Posts ({userPosts?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="donations" className="flex items-center">
              <Gift className="h-4 w-4 mr-2" />
              Donations ({donations.length})
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center">
              <HandHeart className="h-4 w-4 mr-2" />
              Requests ({requests.length})
            </TabsTrigger>
            <TabsTrigger value="reviews" className="flex items-center">
              <Star className="h-4 w-4 mr-2" />
              Reviews ({user.totalRatings})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-6">
            {postsLoading ? (
              <div className="space-y-6">
                {[1, 2, 3].map(i => (
                  <Card key={i} className="p-6">
                    <div className="animate-pulse">
                      <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
                      <div className="h-32 bg-muted rounded mb-4"></div>
                      <div className="h-4 bg-muted rounded w-1/2"></div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : userPosts && userPosts.length > 0 ? (
              <div className="space-y-6">
                {userPosts.map((post) => (
                  <PostCard key={post.id} post={post} onUpdate={refetchPosts} />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <Gift className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No posts yet</h3>
                <p className="text-muted-foreground">
                  {isOwnProfile 
                    ? "You haven't shared any food yet. Start by posting your first donation or request!"
                    : `${user.firstName} hasn't shared any food yet.`
                  }
                </p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="donations" className="space-y-6">
            {donations.length > 0 ? (
              <div className="space-y-6">
                {donations.map((post) => (
                  <PostCard key={post.id} post={post} onUpdate={refetchPosts} />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <Gift className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No donations yet</h3>
                <p className="text-muted-foreground">
                  {isOwnProfile 
                    ? "You haven't posted any food donations yet."
                    : `${user.firstName} hasn't posted any food donations yet.`
                  }
                </p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="requests" className="space-y-6">
            {requests.length > 0 ? (
              <div className="space-y-6">
                {requests.map((post) => (
                  <PostCard key={post.id} post={post} onUpdate={refetchPosts} />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <HandHeart className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No requests yet</h3>
                <p className="text-muted-foreground">
                  {isOwnProfile 
                    ? "You haven't posted any food requests yet."
                    : `${user.firstName} hasn't posted any food requests yet.`
                  }
                </p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            {user.totalRatings > 0 ? (
              <div className="space-y-6">
                {/* Rating Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Star className="h-5 w-5 mr-2" />
                      Rating Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Overall Rating */}
                      <div className="text-center">
                        <div className="text-4xl font-bold text-yellow-600 mb-2">
                          {averageRating.toFixed(1)}
                        </div>
                        <RatingDisplay rating={averageRating} size="lg" />
                        <p className="text-sm text-muted-foreground mt-2">
                          Based on {user.totalRatings} review{user.totalRatings !== 1 ? 's' : ''}
                        </p>
                      </div>
                      
                      {/* Rating Distribution */}
                      <div className="space-y-2">
                        {[5, 4, 3, 2, 1].map((stars) => {
                          const count = userRatings?.filter(r => r.rating === stars).length || 0;
                          const percentage = user.totalRatings > 0 ? (count / user.totalRatings) * 100 : 0;
                          
                          return (
                            <div key={stars} className="flex items-center space-x-2">
                              <span className="text-sm w-8">{stars} ★</span>
                              <div className="flex-1 bg-muted rounded-full h-2">
                                <div 
                                  className="bg-yellow-400 h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${percentage}%` }}
                                />
                              </div>
                              <span className="text-sm text-muted-foreground w-12">{count}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Individual Reviews */}
                {ratingsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <Card key={i} className="p-6">
                        <div className="animate-pulse">
                          <div className="flex items-center space-x-3 mb-3">
                            <div className="w-10 h-10 bg-muted rounded-full"></div>
                            <div className="flex-1 space-y-2">
                              <div className="h-4 bg-muted rounded w-1/4"></div>
                              <div className="h-3 bg-muted rounded w-1/3"></div>
                            </div>
                          </div>
                          <div className="h-4 bg-muted rounded w-3/4"></div>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : userRatings && userRatings.length > 0 ? (
                  <div className="space-y-4">
                    {userRatings.map((rating) => (
                      <Card key={rating.id}>
                        <CardContent className="p-6">
                          <div className="flex items-start space-x-4">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={rating.rater?.profileImageUrl || ""} />
                              <AvatarFallback>
                                {rating.rater?.firstName?.[0]}{rating.rater?.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center space-x-2">
                                  <span className="font-semibold">
                                    {rating.rater?.firstName} {rating.rater?.lastName}
                                  </span>
                                  <RatingDisplay rating={rating.rating} />
                                </div>
                                <span className="text-sm text-muted-foreground">
                                  {new Date(rating.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                              
                              {rating.comment && (
                                <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
                                  "{rating.comment}"
                                </p>
                              )}
                              
                              <div className="flex items-center space-x-2 mt-3">
                                <Badge variant="secondary" className="text-xs">
                                  {rating.transactionType === 'donation' ? '🎁 Donation' : '🤝 Request'}
                                </Badge>
                                {rating.isVerified && (
                                  <Badge variant="default" className="text-xs bg-green-100 text-green-800">
                                    ✓ Verified
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="text-center p-12">
                    <Star className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-semibold mb-2">No detailed reviews yet</h3>
                    <p className="text-muted-foreground">
                      Reviews will appear here after successful food sharing transactions.
                    </p>
                  </Card>
                )}
              </div>
            ) : (
              <Card className="text-center p-12">
                <Star className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No reviews yet</h3>
                <p className="text-muted-foreground">
                  {isOwnProfile 
                    ? "You haven't received any reviews yet. Complete some food sharing transactions to build your reputation!"
                    : `${user.firstName} hasn't received any reviews yet.`
                  }
                </p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}