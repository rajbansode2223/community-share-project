import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Car, 
  Truck, 
  Package, 
  CheckCircle, 
  AlertCircle,
  Plus,
  Heart,
  Clock3,
  MapPinIcon
} from "lucide-react";
import { format } from "date-fns";

// Event Registration Form Schema
const eventRegistrationSchema = z.object({
  eventName: z.string().min(1, "Event name is required"),
  eventType: z.string().min(1, "Event type is required"),
  organizerName: z.string().min(1, "Organizer name is required"),
  organizerPhone: z.string().min(1, "Phone number is required"),
  organizerEmail: z.string().email().optional().or(z.literal("")),
  eventVenue: z.string().min(1, "Venue name is required"),
  eventAddress: z.string().min(1, "Event address is required"),
  eventDate: z.string().min(1, "Event date is required"),
  eventEndTime: z.string().min(1, "Event end time is required"),
  pickupStartTime: z.string().min(1, "Pickup start time is required"),
  pickupEndTime: z.string().min(1, "Pickup end time is required"),
  estimatedGuests: z.number().min(1, "Number of guests is required"),
  estimatedLeftoverPercentage: z.number().min(1).max(100),
  foodTypes: z.string().min(1, "Food types are required"),
  cuisineType: z.string().optional(),
  specialInstructions: z.string().optional(),
  contactPerson: z.string().optional(),
  contactPersonPhone: z.string().optional(),
  servingContainers: z.boolean().default(false),
  requiresRefrigeration: z.boolean().default(false),
  accessInstructions: z.string().optional(),
  parkingAvailable: z.boolean().default(true),
  loadingAccess: z.boolean().default(true),
  maxVolunteers: z.number().min(1).default(10),
});

// Volunteer Registration Form Schema
const volunteerRegistrationSchema = z.object({
  vehicleType: z.string().min(1, "Vehicle type is required"),
  vehicleCapacity: z.string().optional(),
  availableFrom: z.string().min(1, "Availability start time is required"),
  availableTo: z.string().min(1, "Availability end time is required"),
  specialSkills: z.string().optional(),
  emergencyContact: z.string().optional(),
  emergencyPhone: z.string().optional(),
});

type EventFormData = z.infer<typeof eventRegistrationSchema>;
type VolunteerFormData = z.infer<typeof volunteerRegistrationSchema>;

export default function EventFoodPickup() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("browse");
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);

  // Fetch available events
  const { data: events, isLoading: eventsLoading } = useQuery({
    queryKey: ["/api/event-pickups"],
  });

  // Fetch user's volunteer registrations
  const { data: userRegistrations, isLoading: registrationsLoading } = useQuery({
    queryKey: ["/api/event-pickups/registrations", user?.id],
    enabled: !!user?.id,
  });

  // Event registration mutation
  const eventMutation = useMutation({
    mutationFn: async (data: EventFormData) => {
      return apiRequest("/api/event-pickups", {
        method: "POST",
        body: JSON.stringify({
          ...data,
          eventDate: new Date(data.eventDate).toISOString(),
          eventEndTime: new Date(data.eventEndTime).toISOString(),
          pickupStartTime: new Date(data.pickupStartTime).toISOString(),
          pickupEndTime: new Date(data.pickupEndTime).toISOString(),
          foodTypes: JSON.stringify(data.foodTypes.split(',').map(t => t.trim())),
          createdBy: user?.id,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Event Registered",
        description: "Your event has been submitted for approval. You'll be notified once it's reviewed.",
      });
      setIsEventDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/event-pickups"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Volunteer registration mutation
  const volunteerMutation = useMutation({
    mutationFn: async ({ eventId, data }: { eventId: number; data: VolunteerFormData }) => {
      return apiRequest(`/api/event-pickups/${eventId}/volunteer`, {
        method: "POST",
        body: JSON.stringify({
          ...data,
          availableFrom: new Date(data.availableFrom).toISOString(),
          availableTo: new Date(data.availableTo).toISOString(),
          userId: user?.id,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Volunteer Registration Successful",
        description: "You've been registered as a volunteer for this event.",
      });
      setSelectedEventId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/event-pickups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/event-pickups/registrations", user?.id] });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Event registration form
  const eventForm = useForm<EventFormData>({
    resolver: zodResolver(eventRegistrationSchema),
    defaultValues: {
      estimatedLeftoverPercentage: 30,
      servingContainers: false,
      requiresRefrigeration: false,
      parkingAvailable: true,
      loadingAccess: true,
      maxVolunteers: 10,
    },
  });

  // Volunteer registration form
  const volunteerForm = useForm<VolunteerFormData>({
    resolver: zodResolver(volunteerRegistrationSchema),
  });

  const onEventSubmit = (data: EventFormData) => {
    eventMutation.mutate(data);
  };

  const onVolunteerSubmit = (data: VolunteerFormData) => {
    if (selectedEventId) {
      volunteerMutation.mutate({ eventId: selectedEventId, data });
    }
  };

  const getEventTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      wedding: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
      corporate: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      birthday: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
      conference: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
      festival: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      religious: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
      graduation: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200",
    };
    return colors[type] || "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
      approved: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      active: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      completed: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
      cancelled: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
      expired: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen app-bg">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">Please log in to access Event Food Pickup</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Join our community to help reduce food waste from large events
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen app-bg">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
              <Heart className="h-6 w-6 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Event Food Pickup</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Help rescue surplus food from large events and distribute it to those in need
              </p>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="browse">Browse Events</TabsTrigger>
            <TabsTrigger value="register">Register Event</TabsTrigger>
            <TabsTrigger value="my-activity">My Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Available Events</h2>
              <Badge variant="outline" className="px-3 py-1">
                {events?.length || 0} events available
              </Badge>
            </div>

            {eventsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {events?.filter((event: any) => event.status === 'approved' || event.status === 'active').map((event: any) => (
                  <Card key={event.id} className="group hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge className={getEventTypeColor(event.eventType)}>
                          {event.eventType}
                        </Badge>
                        <Badge className={getStatusColor(event.status)}>
                          {event.status}
                        </Badge>
                      </div>
                      <CardTitle className="line-clamp-2">{event.eventName}</CardTitle>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{event.eventVenue}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-500" />
                          <span>{format(new Date(event.eventDate), "MMM dd")}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-gray-500" />
                          <span>{format(new Date(event.pickupStartTime), "HH:mm")}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-gray-500" />
                          <span>{event.estimatedGuests} guests</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Package className="h-4 w-4 text-gray-500" />
                          <span>{event.estimatedLeftoverPercentage}% surplus</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-600 dark:text-gray-400 line-clamp-1">
                          {event.eventAddress}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="text-sm">
                          <span className="font-medium">{event.currentVolunteers}</span>
                          <span className="text-gray-500">/{event.maxVolunteers} volunteers</span>
                        </div>
                        
                        <Dialog open={selectedEventId === event.id} onOpenChange={(open) => {
                          setSelectedEventId(open ? event.id : null);
                          if (!open) volunteerForm.reset();
                        }}>
                          <DialogTrigger asChild>
                            <Button size="sm" disabled={event.currentVolunteers >= event.maxVolunteers}>
                              {event.currentVolunteers >= event.maxVolunteers ? "Full" : "Volunteer"}
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle>Volunteer for {event.eventName}</DialogTitle>
                            </DialogHeader>
                            <Form {...volunteerForm}>
                              <form onSubmit={volunteerForm.handleSubmit(onVolunteerSubmit)} className="space-y-4">
                                <FormField
                                  control={volunteerForm.control}
                                  name="vehicleType"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Vehicle Type</FormLabel>
                                      <FormControl>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                          <SelectTrigger>
                                            <SelectValue placeholder="Select vehicle type" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="car">Car</SelectItem>
                                            <SelectItem value="suv">SUV</SelectItem>
                                            <SelectItem value="van">Van</SelectItem>
                                            <SelectItem value="truck">Truck</SelectItem>
                                            <SelectItem value="bicycle">Bicycle</SelectItem>
                                            <SelectItem value="motorcycle">Motorcycle</SelectItem>
                                            <SelectItem value="walking">Walking</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />

                                <FormField
                                  control={volunteerForm.control}
                                  name="vehicleCapacity"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Vehicle Capacity (optional)</FormLabel>
                                      <FormControl>
                                        <Input placeholder="e.g., 50 kg, 20 containers" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />

                                <div className="grid grid-cols-2 gap-4">
                                  <FormField
                                    control={volunteerForm.control}
                                    name="availableFrom"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Available From</FormLabel>
                                        <FormControl>
                                          <Input type="datetime-local" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />

                                  <FormField
                                    control={volunteerForm.control}
                                    name="availableTo"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Available To</FormLabel>
                                        <FormControl>
                                          <Input type="datetime-local" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                </div>

                                <FormField
                                  control={volunteerForm.control}
                                  name="specialSkills"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Special Skills (optional)</FormLabel>
                                      <FormControl>
                                        <Textarea 
                                          placeholder="e.g., Refrigerated transport, Heavy lifting, Food safety certification"
                                          {...field} 
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />

                                <div className="grid grid-cols-2 gap-4">
                                  <FormField
                                    control={volunteerForm.control}
                                    name="emergencyContact"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Emergency Contact</FormLabel>
                                        <FormControl>
                                          <Input placeholder="Contact name" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />

                                  <FormField
                                    control={volunteerForm.control}
                                    name="emergencyPhone"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Emergency Phone</FormLabel>
                                        <FormControl>
                                          <Input placeholder="Phone number" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                </div>

                                <Button 
                                  type="submit" 
                                  className="w-full" 
                                  disabled={volunteerMutation.isPending}
                                >
                                  {volunteerMutation.isPending ? "Registering..." : "Register as Volunteer"}
                                </Button>
                              </form>
                            </Form>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {!eventsLoading && (!events || events.length === 0) && (
              <Card className="text-center py-12">
                <CardContent>
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No events available</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    There are currently no events looking for volunteers. Check back later!
                  </p>
                  <Button onClick={() => setActiveTab("register")}>
                    Register Your Event
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="register" className="space-y-6">
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-semibold mb-2">Register Your Event</h2>
                <p className="text-gray-600 dark:text-gray-400">
                  Have a large event with surplus food? Register it here to connect with volunteers who can help distribute the leftovers.
                </p>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Plus className="h-5 w-5" />
                    Event Registration Form
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...eventForm}>
                    <form onSubmit={eventForm.handleSubmit(onEventSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="eventName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Johnson Wedding Reception" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="eventType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event Type</FormLabel>
                              <FormControl>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select event type" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="wedding">Wedding</SelectItem>
                                    <SelectItem value="corporate">Corporate Event</SelectItem>
                                    <SelectItem value="birthday">Birthday Party</SelectItem>
                                    <SelectItem value="anniversary">Anniversary</SelectItem>
                                    <SelectItem value="conference">Conference</SelectItem>
                                    <SelectItem value="festival">Festival</SelectItem>
                                    <SelectItem value="community">Community Event</SelectItem>
                                    <SelectItem value="religious">Religious Event</SelectItem>
                                    <SelectItem value="graduation">Graduation</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                  </SelectContent>
                                </Select>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="organizerName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Organizer Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Smith" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="organizerPhone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Organizer Phone</FormLabel>
                              <FormControl>
                                <Input placeholder="+1 (555) 123-4567" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={eventForm.control}
                        name="organizerEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Organizer Email (optional)</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="john@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="eventVenue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event Venue</FormLabel>
                              <FormControl>
                                <Input placeholder="Grand Ballroom Hotel" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="eventAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event Address</FormLabel>
                              <FormControl>
                                <Input placeholder="123 Main St, City, State" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="eventDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event Date</FormLabel>
                              <FormControl>
                                <Input type="datetime-local" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="eventEndTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Event End Time</FormLabel>
                              <FormControl>
                                <Input type="datetime-local" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="pickupStartTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Pickup Start Time</FormLabel>
                              <FormControl>
                                <Input type="datetime-local" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="pickupEndTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Pickup End Time</FormLabel>
                              <FormControl>
                                <Input type="datetime-local" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="estimatedGuests"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estimated Guests</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="100" 
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="estimatedLeftoverPercentage"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estimated Leftover %</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  min="1" 
                                  max="100" 
                                  placeholder="30" 
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 30)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="maxVolunteers"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Max Volunteers</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  min="1" 
                                  placeholder="10" 
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 10)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="foodTypes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Food Types</FormLabel>
                              <FormControl>
                                <Input placeholder="appetizers, main course, desserts" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="cuisineType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cuisine Type (optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Italian, Indian, American" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={eventForm.control}
                        name="specialInstructions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Special Instructions (optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Any special handling instructions, dietary information, or notes for volunteers"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="contactPerson"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Contact Person (optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Event manager name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="contactPersonPhone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Contact Person Phone (optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Contact phone number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={eventForm.control}
                        name="accessInstructions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Access Instructions (optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="How volunteers should access the venue, security protocols, etc."
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <FormField
                          control={eventForm.control}
                          name="servingContainers"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Serving Containers</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="requiresRefrigeration"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Needs Refrigeration</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="parkingAvailable"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Parking Available</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={eventForm.control}
                          name="loadingAccess"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Loading Access</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={eventMutation.isPending}
                      >
                        {eventMutation.isPending ? "Submitting..." : "Submit Event for Approval"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="my-activity" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">My Activity</h2>
            </div>

            {registrationsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {userRegistrations?.length > 0 ? (
                  userRegistrations.map((registration: any) => (
                    <Card key={registration.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              {registration.event.eventName}
                              <Badge className={getEventTypeColor(registration.event.eventType)}>
                                {registration.event.eventType}
                              </Badge>
                            </CardTitle>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {registration.event.eventVenue}
                            </p>
                          </div>
                          <Badge className={getStatusColor(registration.status)}>
                            {registration.status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span>{format(new Date(registration.event.eventDate), "MMM dd, yyyy")}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock3 className="h-4 w-4 text-gray-500" />
                            <span>{format(new Date(registration.availableFrom), "HH:mm")} - {format(new Date(registration.availableTo), "HH:mm")}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Car className="h-4 w-4 text-gray-500" />
                            <span className="capitalize">{registration.vehicleType}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPinIcon className="h-4 w-4 text-gray-500" />
                            <span className="line-clamp-1">{registration.event.eventAddress}</span>
                          </div>
                        </div>
                        
                        {registration.status === 'completed' && (
                          <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                            <div className="flex items-center gap-2 text-green-800 dark:text-green-200">
                              <CheckCircle className="h-5 w-5" />
                              <span className="font-medium">Volunteer service completed</span>
                            </div>
                            {registration.organizerFeedback && (
                              <p className="text-sm text-green-700 dark:text-green-300 mt-2">
                                "{registration.organizerFeedback}"
                              </p>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card className="text-center py-12">
                    <CardContent>
                      <Clock3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No volunteer activity yet</h3>
                      <p className="text-gray-600 dark:text-gray-400 mb-4">
                        Start volunteering for events to help reduce food waste in your community.
                      </p>
                      <Button onClick={() => setActiveTab("browse")}>
                        Browse Available Events
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}