import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Heart, Trophy, Plus, MapPin, Star, Crown, Award, Medal, Home, Building2, School, Briefcase, UserPlus } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/navbar";

export default function GroupGivers() {
  const { user, isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [groupTypeFilter, setGroupTypeFilter] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);

  // Mock data for demonstration - would come from API in real implementation
  const featuredGroups = [
    {
      id: 1,
      name: "Sunset Family Circle",
      groupType: "family",
      location: "Sunset District, San Francisco",
      totalMembers: 8,
      totalDonations: 47,
      totalMealsShared: 124,
      badgeLevel: "neighborhood_nourisher",
      badges: [
        { name: "Neighborhood Nourisher", emoji: "🏠", description: "5+ active members" },
        { name: "Meal Heroes", emoji: "🍽️", description: "50+ meals shared" }
      ],
      recentActivity: "Shared 12 holiday meals last week",
      joinable: true
    },
    {
      id: 2,
      name: "Oak Grove Housing Society",
      groupType: "housing_society",
      location: "Oak Grove Apartments, Austin",
      totalMembers: 23,
      totalDonations: 89,
      totalMealsShared: 267,
      badgeLevel: "community_champions",
      badges: [
        { name: "Street Squad", emoji: "🏘️", description: "10+ neighbors united" },
        { name: "Block Blessers", emoji: "🏢", description: "20+ group meals" },
        { name: "Community Champions", emoji: "🏆", description: "15+ members, 50+ meals" }
      ],
      recentActivity: "Organized Thanksgiving feast for 40 families",
      joinable: false
    },
    {
      id: 3,
      name: "Unity Workplace Givers",
      groupType: "workplace",
      location: "Tech Hub, Seattle",
      totalMembers: 15,
      totalDonations: 34,
      totalMealsShared: 91,
      badgeLevel: "street_squad",
      badges: [
        { name: "Neighborhood Nourisher", emoji: "🏠", description: "5+ active members" },
        { name: "Street Squad", emoji: "🏘️", description: "10+ members united" }
      ],
      recentActivity: "Weekly lunch donations to local shelter",
      joinable: true
    }
  ];

  const badgeIcons = {
    "new_group": { icon: Star, color: "bg-gray-100 text-gray-600" },
    "neighborhood_nourisher": { icon: Home, color: "bg-green-100 text-green-600" },
    "street_squad": { icon: Building2, color: "bg-blue-100 text-blue-600" },
    "block_blessers": { icon: Award, color: "bg-purple-100 text-purple-600" },
    "community_champions": { icon: Crown, color: "bg-yellow-100 text-yellow-600" },
    "unity_leaders": { icon: Medal, color: "bg-red-100 text-red-600" }
  };

  const groupTypeIcons = {
    "family": { icon: Users, label: "Family" },
    "housing_society": { icon: Building2, label: "Housing Society" },
    "neighborhood": { icon: Home, label: "Neighborhood" },
    "workplace": { icon: Briefcase, label: "Workplace" },
    "school": { icon: School, label: "School" },
    "friends": { icon: Heart, label: "Friends" },
    "other": { icon: Users, label: "Other" }
  };

  const filteredGroups = featuredGroups.filter(group => {
    const matchesSearch = group.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         group.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = !groupTypeFilter || group.groupType === groupTypeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
              <Users className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Group Givers & Family Mode
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-6">
            💞 <strong>Collective giving, better impact.</strong><br/>
            Families or housing societies can create group accounts to donate in bulk.<br/>
            Earn joint badges like "Neighborhood Nourisher" or "Street Squad".
          </p>
          
          {isAuthenticated && (
            <Button 
              onClick={() => setShowCreateForm(true)}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 rounded-full text-lg"
            >
              <Plus className="h-5 w-5 mr-2" />
              Create Your Group
            </Button>
          )}
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <Input
            placeholder="Search groups by name or location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
          <Select value={groupTypeFilter} onValueChange={setGroupTypeFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Group Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Types</SelectItem>
              <SelectItem value="family">Family</SelectItem>
              <SelectItem value="housing_society">Housing Society</SelectItem>
              <SelectItem value="neighborhood">Neighborhood</SelectItem>
              <SelectItem value="workplace">Workplace</SelectItem>
              <SelectItem value="school">School</SelectItem>
              <SelectItem value="friends">Friends</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Badge Progression Info */}
        <Card className="mb-8 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-gray-800 dark:to-gray-700 border-none">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              Group Badge Progression
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {Object.entries(badgeIcons).map(([level, { icon: Icon, color }]) => (
                <div key={level} className="text-center">
                  <div className={`w-12 h-12 rounded-full ${color} flex items-center justify-center mx-auto mb-2`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-medium capitalize">
                    {level.replace(/_/g, ' ')}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Groups Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredGroups.map((group) => {
            const BadgeIcon = badgeIcons[group.badgeLevel as keyof typeof badgeIcons]?.icon || Star;
            const badgeColor = badgeIcons[group.badgeLevel as keyof typeof badgeIcons]?.color || "bg-gray-100 text-gray-600";
            const TypeIcon = groupTypeIcons[group.groupType as keyof typeof groupTypeIcons]?.icon || Users;
            const typeLabel = groupTypeIcons[group.groupType as keyof typeof groupTypeIcons]?.label || "Group";

            return (
              <Card key={group.id} className="overflow-hidden hover:shadow-lg transition-shadow bg-white dark:bg-gray-800">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2 flex items-center gap-2">
                        <TypeIcon className="h-5 w-5 text-purple-500" />
                        {group.name}
                      </CardTitle>
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300 mb-2">
                        <MapPin className="h-4 w-4" />
                        {group.location}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {typeLabel}
                      </Badge>
                    </div>
                    <div className={`w-10 h-10 rounded-full ${badgeColor} flex items-center justify-center`}>
                      <BadgeIcon className="h-5 w-5" />
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-purple-600">{group.totalMembers}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-300">Members</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-600">{group.totalDonations}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-300">Donations</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-orange-600">{group.totalMealsShared}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-300">Meals</div>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold">Earned Badges:</h4>
                    <div className="flex flex-wrap gap-2">
                      {group.badges.map((badge, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {badge.emoji} {badge.name}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Recent Activity */}
                  <div className="border-t pt-3">
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      <span className="font-medium">Recent:</span> {group.recentActivity}
                    </p>
                  </div>

                  {/* Action Button */}
                  {isAuthenticated && group.joinable && (
                    <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Request to Join
                    </Button>
                  )}
                  
                  {!group.joinable && (
                    <Button variant="outline" className="w-full" disabled>
                      Private Group
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* No results */}
        {filteredGroups.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-300 mb-2">
              No groups found
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your search criteria or create a new group.
            </p>
          </div>
        )}

        {/* How It Works Section */}
        <Card className="mt-12 bg-gradient-to-r from-green-50 to-blue-50 dark:from-gray-800 dark:to-gray-700 border-none">
          <CardHeader>
            <CardTitle className="text-center">How Group Giving Works</CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Plus className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Create or Join</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Form a family group, housing society, or workplace team to pool your giving efforts.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Donate Together</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Coordinate bulk donations and share meals collectively for greater impact.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="h-8 w-8 text-yellow-600" />
              </div>
              <h3 className="font-semibold mb-2">Earn Joint Badges</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Unlock shared achievements and build neighborhood pride through collective giving.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}