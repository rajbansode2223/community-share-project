import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Search, Plus, MapPin, Users, Calendar, Heart, Baby, GraduationCap, Stethoscope, Clock, Phone, Mail, Shield, Star, TrendingUp, Building, UserCheck, Gift } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";

const institutionFormSchema = z.object({
  name: z.string().min(3, "Institution name must be at least 3 characters"),
  institutionType: z.enum(["orphanage", "old_age_home", "rehabilitation_center", "shelter_home"]),
  description: z.string().min(10, "Description must be at least 10 characters"),
  address: z.string().min(5, "Address is required"),
  capacity: z.number().min(1, "Capacity must be at least 1"),
  currentResidents: z.number().min(0, "Current residents cannot be negative"),
  contactPerson: z.string().min(2, "Contact person name is required"),
  contactPhone: z.string().min(10, "Valid phone number is required"),
  contactEmail: z.string().email("Valid email is required").optional().or(z.literal("")),
  registrationNumber: z.string().optional(),
  mealsPerDay: z.number().min(1, "Must provide at least 1 meal per day").max(6, "Maximum 6 meals per day"),
  specialDietaryNeeds: z.string().optional(),
});

const adoptionFormSchema = z.object({
  institutionId: z.number(),
  donorType: z.enum(["individual", "restaurant", "corporate", "ngo", "community_group"]),
  donorName: z.string().min(2, "Donor name is required"),
  donorContact: z.string().optional(),
  pledgeType: z.enum(["daily", "weekly", "monthly", "festival", "one_time"]),
  mealsPerSession: z.number().min(1, "Must provide at least 1 meal"),
  preferredTime: z.string().optional(),
  specialRequests: z.string().optional(),
  startDate: z.string(),
});

type InstitutionFormData = z.infer<typeof institutionFormSchema>;
type AdoptionFormData = z.infer<typeof adoptionFormSchema>;

export default function CareInstitutions() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showInstitutionForm, setShowInstitutionForm] = useState(false);
  const [showAdoptionForm, setShowAdoptionForm] = useState(false);
  const [selectedInstitution, setSelectedInstitution] = useState<any>(null);
  const [filters, setFilters] = useState({
    search: "",
    institutionType: "all",
    verificationStatus: "all",
  });

  const { data: institutions = [], isLoading } = useQuery({
    queryKey: ["/api/care-institutions", filters],
    queryFn: () => apiRequest(`/api/care-institutions?${new URLSearchParams(
      Object.entries(filters).filter(([_, value]) => value && value !== "all")
    )}`),
  });

  const { data: impact } = useQuery({
    queryKey: ["/api/institution-impact"],
  });

  const { data: myAdoptions = [] } = useQuery({
    queryKey: ["/api/institution-adoptions"],
    enabled: !!user,
  });

  const institutionForm = useForm<InstitutionFormData>({
    resolver: zodResolver(institutionFormSchema),
    defaultValues: {
      institutionType: "orphanage",
      mealsPerDay: 3,
      capacity: 50,
      currentResidents: 0,
    },
  });

  const adoptionForm = useForm<AdoptionFormData>({
    resolver: zodResolver(adoptionFormSchema),
    defaultValues: {
      donorType: "individual",
      pledgeType: "monthly",
      startDate: new Date().toISOString().split('T')[0],
    },
  });

  const createInstitutionMutation = useMutation({
    mutationFn: (data: InstitutionFormData) => apiRequest("/api/care-institutions", {
      method: "POST",
      body: data,
    }),
    onSuccess: () => {
      toast({ title: "Institution registered successfully!" });
      setShowInstitutionForm(false);
      institutionForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/care-institutions"] });
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to register institution", 
        variant: "destructive" 
      });
    },
  });

  const createAdoptionMutation = useMutation({
    mutationFn: (data: AdoptionFormData) => apiRequest("/api/institution-adoptions", {
      method: "POST",
      body: data,
    }),
    onSuccess: () => {
      toast({ title: "Adoption pledge created successfully!" });
      setShowAdoptionForm(false);
      adoptionForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/institution-adoptions"] });
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to create adoption pledge", 
        variant: "destructive" 
      });
    },
  });

  const filteredInstitutions = institutions.filter((institution: any) => {
    const matchesSearch = !filters.search || 
      institution.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      institution.address.toLowerCase().includes(filters.search.toLowerCase());
    
    return matchesSearch;
  });

  const getInstitutionIcon = (type: string) => {
    switch (type) {
      case "orphanage": return <Baby className="h-6 w-6" />;
      case "old_age_home": return <Heart className="h-6 w-6" />;
      case "rehabilitation_center": return <Stethoscope className="h-6 w-6" />;
      case "shelter_home": return <Building className="h-6 w-6" />;
      default: return <Building className="h-6 w-6" />;
    }
  };

  const getInstitutionTypeLabel = (type: string) => {
    switch (type) {
      case "orphanage": return "Orphanage";
      case "old_age_home": return "Old Age Home";
      case "rehabilitation_center": return "Rehabilitation Center";
      case "shelter_home": return "Shelter Home";
      default: return type;
    }
  };

  return (
    <div className="min-h-screen app-bg">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Baby className="h-12 w-12" />
            <Heart className="h-12 w-12" />
            <Building className="h-12 w-12" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Support Care Institutions
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Help orphanages, old age homes, and care centers provide regular meals to those who need it most. 
            Your support creates lasting impact in the lives of children and elderly residents.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Dialog open={showAdoptionForm} onOpenChange={setShowAdoptionForm}>
              <DialogTrigger asChild>
                <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                  <Gift className="mr-2 h-5 w-5" />
                  Sponsor a Care Institution
                </Button>
              </DialogTrigger>
            </Dialog>
            
            <Dialog open={showInstitutionForm} onOpenChange={setShowInstitutionForm}>
              <DialogTrigger asChild>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-blue-600">
                  <Plus className="mr-2 h-5 w-5" />
                  Register Institution
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>
      </section>

      {/* Impact Statistics */}
      {impact && (
        <section className="py-12 bg-white dark:bg-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Our Impact on Care Institutions
              </h2>
              <p className="text-gray-600 dark:text-gray-300">
                Together, we're making a difference in the lives of vulnerable communities
              </p>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center mb-4">
                    <Building className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">{impact.totalInstitutions}</div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Total Institutions</p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center mb-4">
                    <Users className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="text-3xl font-bold text-green-600 mb-2">{impact.totalResidents}</div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Residents Supported</p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center mb-4">
                    <Gift className="h-8 w-8 text-orange-600" />
                  </div>
                  <div className="text-3xl font-bold text-orange-600 mb-2">{impact.totalMealsProvided.toLocaleString()}</div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Meals Provided</p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center mb-4">
                    <TrendingUp className="h-8 w-8 text-purple-600" />
                  </div>
                  <div className="text-3xl font-bold text-purple-600 mb-2">{impact.activeAdoptions}</div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Active Sponsorships</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Baby className="h-6 w-6 text-pink-600" />
                    <h3 className="text-lg font-semibold">Children Supported</h3>
                  </div>
                  <div className="text-2xl font-bold text-pink-600 mb-2">{impact.childrenSupported}</div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Across {impact.orphanages} orphanages</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Heart className="h-6 w-6 text-red-600" />
                    <h3 className="text-lg font-semibold">Elderly Cared For</h3>
                  </div>
                  <div className="text-2xl font-bold text-red-600 mb-2">{impact.elderlySupported}</div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Across {impact.oldAgeHomes} care centers</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      )}

      {/* Search and Filters */}
      <section className="py-8 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search institutions by name or location..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="pl-10"
              />
            </div>
            
            <Select
              value={filters.institutionType}
              onValueChange={(value) => setFilters({ ...filters, institutionType: value })}
            >
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Institution Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="orphanage">Orphanages</SelectItem>
                <SelectItem value="old_age_home">Old Age Homes</SelectItem>
                <SelectItem value="rehabilitation_center">Rehabilitation Centers</SelectItem>
                <SelectItem value="shelter_home">Shelter Homes</SelectItem>
              </SelectContent>
            </Select>
            
            <Select
              value={filters.verificationStatus}
              onValueChange={(value) => setFilters({ ...filters, verificationStatus: value })}
            >
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Verification Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="verified">Verified</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Institutions List */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Care Institutions ({filteredInstitutions.length})
            </h2>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredInstitutions.map((institution: any) => (
                <Card key={institution.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {getInstitutionIcon(institution.institutionType)}
                        <div>
                          <CardTitle className="text-lg">{institution.name}</CardTitle>
                          <CardDescription>{getInstitutionTypeLabel(institution.institutionType)}</CardDescription>
                        </div>
                      </div>
                      <Badge 
                        variant={institution.verificationStatus === 'verified' ? 'default' : 'secondary'}
                        className={institution.verificationStatus === 'verified' ? 'bg-green-100 text-green-800' : ''}
                      >
                        {institution.verificationStatus === 'verified' ? (
                          <><Shield className="h-3 w-3 mr-1" /> Verified</>
                        ) : (
                          'Pending'
                        )}
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">
                      {institution.description}
                    </p>
                    
                    <div className="space-y-3 mb-4">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-300">{institution.address}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-300">
                          {institution.currentResidents}/{institution.capacity} residents
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-300">
                          {institution.mealsPerDay} meals per day
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-300">{institution.contactPhone}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-center">
                        <div className="text-lg font-semibold text-blue-600">{institution.totalMealsProvided.toLocaleString()}</div>
                        <div className="text-xs text-gray-500">Meals Provided</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-green-600">
                          {institution.lastDonationDate ? 
                            new Date(institution.lastDonationDate).toLocaleDateString() : 
                            'No donations yet'
                          }
                        </div>
                        <div className="text-xs text-gray-500">Last Donation</div>
                      </div>
                    </div>
                    
                    {institution.specialDietaryNeeds && (
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          <strong>Special Needs:</strong> {institution.specialDietaryNeeds}
                        </p>
                      </div>
                    )}
                    
                    <Button 
                      className="w-full" 
                      onClick={() => {
                        setSelectedInstitution(institution);
                        adoptionForm.setValue('institutionId', institution.id);
                        setShowAdoptionForm(true);
                      }}
                    >
                      <Gift className="mr-2 h-4 w-4" />
                      Sponsor This Institution
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* My Sponsorships */}
      {user && myAdoptions.length > 0 && (
        <section className="py-12 bg-gray-50 dark:bg-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
              My Active Sponsorships
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myAdoptions.map((adoption: any) => (
                <Card key={adoption.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">{adoption.institution?.name}</CardTitle>
                    <CardDescription>
                      {getInstitutionTypeLabel(adoption.institution?.institutionType)}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Pledge Type:</span>
                        <Badge variant="outline">{adoption.pledgeType}</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Meals per Session:</span>
                        <span className="font-semibold">{adoption.mealsPerSession}</span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Progress:</span>
                        <span className="font-semibold">
                          {adoption.completedSessions}/{adoption.totalSessions} sessions
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Total Meals Provided:</span>
                        <span className="font-semibold text-green-600">{adoption.totalMealsProvided}</span>
                      </div>
                      
                      <Badge 
                        variant={adoption.status === 'active' ? 'default' : 'secondary'}
                        className="w-full justify-center"
                      >
                        {adoption.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Institution Registration Dialog */}
      <Dialog open={showInstitutionForm} onOpenChange={setShowInstitutionForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Register Care Institution</DialogTitle>
            <DialogDescription>
              Register your orphanage, old age home, or care center to receive food donations and support.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...institutionForm}>
            <form onSubmit={institutionForm.handleSubmit((data) => createInstitutionMutation.mutate(data))} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={institutionForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Institution Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Sunshine Children's Home" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={institutionForm.control}
                  name="institutionType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Institution Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="orphanage">Orphanage</SelectItem>
                          <SelectItem value="old_age_home">Old Age Home</SelectItem>
                          <SelectItem value="rehabilitation_center">Rehabilitation Center</SelectItem>
                          <SelectItem value="shelter_home">Shelter Home</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={institutionForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe your institution, the people you serve, and your mission..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={institutionForm.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Input placeholder="Complete address including city and state" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={institutionForm.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Total Capacity</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={institutionForm.control}
                  name="currentResidents"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Residents</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={institutionForm.control}
                  name="mealsPerDay"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meals Per Day</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 3)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={institutionForm.control}
                  name="contactPerson"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Person</FormLabel>
                      <FormControl>
                        <Input placeholder="Name of primary contact" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={institutionForm.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="+1-555-0123" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={institutionForm.control}
                  name="contactEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Email (Optional)</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="contact@institution.org" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={institutionForm.control}
                  name="registrationNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Registration Number (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="NGO/Trust registration number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={institutionForm.control}
                name="specialDietaryNeeds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Dietary Needs (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="e.g., Vegetarian options, diabetic-friendly meals, soft foods for elderly..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex gap-4 pt-4">
                <Button 
                  type="submit" 
                  disabled={createInstitutionMutation.isPending}
                  className="flex-1"
                >
                  {createInstitutionMutation.isPending ? "Registering..." : "Register Institution"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowInstitutionForm(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Adoption Dialog */}
      <Dialog open={showAdoptionForm} onOpenChange={setShowAdoptionForm}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Sponsor Care Institution</DialogTitle>
            <DialogDescription>
              Create a regular sponsorship to provide consistent meal support to a care institution.
            </DialogDescription>
          </DialogHeader>
          
          {selectedInstitution && (
            <div className="mb-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                {getInstitutionIcon(selectedInstitution.institutionType)}
                <div>
                  <h4 className="font-semibold">{selectedInstitution.name}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {getInstitutionTypeLabel(selectedInstitution.institutionType)}
                  </p>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {selectedInstitution.currentResidents} residents • {selectedInstitution.mealsPerDay} meals per day
              </p>
            </div>
          )}
          
          <Form {...adoptionForm}>
            <form onSubmit={adoptionForm.handleSubmit((data) => createAdoptionMutation.mutate(data))} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={adoptionForm.control}
                  name="donorType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Donor Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="individual">Individual</SelectItem>
                          <SelectItem value="restaurant">Restaurant</SelectItem>
                          <SelectItem value="corporate">Corporate</SelectItem>
                          <SelectItem value="ngo">NGO</SelectItem>
                          <SelectItem value="community_group">Community Group</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={adoptionForm.control}
                  name="pledgeType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pledge Frequency</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="festival">Festival Special</SelectItem>
                          <SelectItem value="one_time">One Time</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={adoptionForm.control}
                name="donorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Donor Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name or organization name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={adoptionForm.control}
                  name="mealsPerSession"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meals per Session</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="50" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={adoptionForm.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={adoptionForm.control}
                name="preferredTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Time (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 12:00 PM, Evening" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={adoptionForm.control}
                name="specialRequests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Requests (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Any special requirements or preferences..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex gap-4 pt-4">
                <Button 
                  type="submit" 
                  disabled={createAdoptionMutation.isPending}
                  className="flex-1"
                >
                  {createAdoptionMutation.isPending ? "Creating..." : "Create Sponsorship"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAdoptionForm(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}