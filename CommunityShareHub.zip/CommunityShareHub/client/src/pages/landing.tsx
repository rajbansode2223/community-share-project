import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Users, Building, Globe, MapPin, Calendar, Share2, Search, Leaf, Beef } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Navigation */}
      <nav className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <span className="text-2xl">🍽️</span>
              <span className="text-xl font-bold">FoodShare</span>
            </div>
            <Button onClick={() => window.location.href = '/api/login'}>
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Unity Through Food Visual */}
          <div className="mb-8">
            <div className="flex justify-center items-center mb-6">
              <svg viewBox="0 0 600 160" className="w-full max-w-3xl h-40">
                {/* Background circle representing unity */}
                <circle cx="300" cy="80" r="70" fill="none" stroke="#FFA500" strokeWidth="2" strokeDasharray="5,5" opacity="0.6" />
                
                {/* Person 1 - African woman with child */}
                <g transform="translate(120, 50)">
                  <ellipse cx="0" cy="0" rx="16" ry="22" fill="#8B4513" />
                  <circle cx="0" cy="-12" r="10" fill="#654321" />
                  <path d="M-10,-18 Q-5,-22 0,-20 Q5,-22 10,-18" fill="#2F1B14" />
                  <circle cx="-3" cy="-15" r="1.2" fill="white" />
                  <circle cx="3" cy="-15" r="1.2" fill="white" />
                  <path d="M-2,-8 Q0,-6 2,-8" fill="none" stroke="#8B4513" strokeWidth="1" />
                  {/* Child beside */}
                  <circle cx="18" cy="5" r="6" fill="#8B4513" />
                  <circle cx="18" cy="-2" r="4" fill="#B8860B" />
                  <circle cx="16.5" cy="-3" r="0.8" fill="white" />
                  <circle cx="19.5" cy="-3" r="0.8" fill="white" />
                </g>
                
                {/* Person 2 - Asian elderly man */}
                <g transform="translate(200, 45)">
                  <ellipse cx="0" cy="0" rx="15" ry="20" fill="#4A90E2" />
                  <circle cx="0" cy="-12" r="9" fill="#F4C2A1" />
                  <path d="M-8,-18 Q0,-20 8,-18" fill="#D3D3D3" />
                  <ellipse cx="-2.5" cy="-15" rx="0.8" ry="0.6" fill="#2F1B14" />
                  <ellipse cx="2.5" cy="-15" rx="0.8" ry="0.6" fill="#2F1B14" />
                  <path d="M-2,-8 Q0,-6 2,-8" fill="none" stroke="#2F1B14" strokeWidth="1" />
                </g>
                
                {/* Person 3 - Middle Eastern woman */}
                <g transform="translate(280, 40)">
                  <ellipse cx="0" cy="0" rx="16" ry="23" fill="#9B59B6" />
                  <circle cx="0" cy="-13" r="10" fill="#D4A574" />
                  <path d="M-9,-20 Q0,-24 9,-20" fill="#4A4A4A" />
                  <circle cx="-3" cy="-16" r="1.1" fill="#654321" />
                  <circle cx="3" cy="-16" r="1.1" fill="#654321" />
                  <path d="M-2,-9 Q0,-7 2,-9" fill="none" stroke="#8B4513" strokeWidth="1" />
                  <path d="M-12,-18 Q-8,-22 -4,-18" fill="#4A4A4A" opacity="0.8" />
                </g>
                
                {/* Person 4 - European family (man and woman) */}
                <g transform="translate(360, 45)">
                  <ellipse cx="0" cy="0" rx="15" ry="21" fill="#E74C3C" />
                  <circle cx="0" cy="-12" r="9" fill="#FFE4B5" />
                  <path d="M-7,-18 Q0,-20 7,-18" fill="#B8860B" />
                  <circle cx="-2.5" cy="-15" r="1.2" fill="#4169E1" />
                  <circle cx="2.5" cy="-15" r="1.2" fill="#4169E1" />
                  <path d="M-2,-8 Q0,-6 2,-8" fill="none" stroke="#8B4513" strokeWidth="1" />
                  {/* Woman beside */}
                  <ellipse cx="-20" cy="0" rx="14" ry="20" fill="#E74C3C" />
                  <circle cx="-20" cy="-12" r="8.5" fill="#FDBCB4" />
                  <path d="M-28,-18 Q-20,-22 -12,-18" fill="#8B4513" />
                  <circle cx="-22" cy="-15" r="1.1" fill="#4169E1" />
                  <circle cx="-18" cy="-15" r="1.1" fill="#4169E1" />
                </g>
                
                {/* Person 5 - Latino young woman */}
                <g transform="translate(460, 50)">
                  <ellipse cx="0" cy="0" rx="15" ry="21" fill="#2ECC71" />
                  <circle cx="0" cy="-12" r="9" fill="#D2B48C" />
                  <path d="M-8,-18 Q0,-22 8,-18" fill="#2F1B14" />
                  <circle cx="-2.5" cy="-15" r="1.2" fill="#654321" />
                  <circle cx="2.5" cy="-15" r="1.2" fill="#654321" />
                  <path d="M-2,-8 Q0,-6 2,-8" fill="none" stroke="#2F1B14" strokeWidth="1" />
                </g>
                
                {/* Additional children playing around */}
                <g transform="translate(180, 90)">
                  <circle cx="0" cy="0" r="5" fill="#FF6B6B" />
                  <circle cx="0" cy="-8" r="3.5" fill="#F4C2A1" />
                  <circle cx="-1" cy="-9" r="0.6" fill="black" />
                  <circle cx="1" cy="-9" r="0.6" fill="black" />
                </g>
                
                <g transform="translate(420, 85)">
                  <circle cx="0" cy="0" r="5" fill="#FFB366" />
                  <circle cx="0" cy="-8" r="3.5" fill="#D4A574" />
                  <circle cx="-1" cy="-9" r="0.6" fill="brown" />
                  <circle cx="1" cy="-9" r="0.6" fill="brown" />
                </g>
                
                {/* Connecting hands/arms representing unity */}
                <path d="M136,60 Q158,55 185,60" stroke="#FF6B35" strokeWidth="3" fill="none" />
                <path d="M215,55 Q248,50 265,55" stroke="#FF6B35" strokeWidth="3" fill="none" />
                <path d="M295,55 Q325,50 340,55" stroke="#FF6B35" strokeWidth="3" fill="none" />
                <path d="M380,60 Q420,55 445,60" stroke="#FF6B35" strokeWidth="3" fill="none" />
                
                {/* Central food sharing symbol */}
                <g transform="translate(300, 110)">
                  <circle cx="0" cy="0" r="22" fill="#FF6B35" opacity="0.9" />
                  <circle cx="0" cy="0" r="17" fill="#FFD700" opacity="0.8" />
                  <text x="0" y="7" textAnchor="middle" fontSize="22" fill="white">🍽️</text>
                </g>
                
                {/* Unity hearts and symbols floating around */}
                <circle cx="220" cy="25" r="3" fill="#E74C3C" opacity="0.7" />
                <circle cx="380" cy="30" r="3" fill="#E74C3C" opacity="0.7" />
                <circle cx="150" cy="120" r="3" fill="#E74C3C" opacity="0.7" />
                <circle cx="450" cy="115" r="3" fill="#E74C3C" opacity="0.7" />
                
                {/* Small family symbols */}
                <text x="100" y="25" fontSize="14" opacity="0.6">👨‍👩‍👧‍👦</text>
                <text x="500" y="30" fontSize="14" opacity="0.6">🤝</text>
                
                {/* Diversity text beneath */}
                <text x="300" y="150" textAnchor="middle" fontSize="14" fill="#666" fontWeight="600">
                  Families, Communities, Humanity United
                </text>
              </svg>
            </div>
            
            <div className="bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 p-8 rounded-xl border border-orange-200 dark:border-orange-800 mb-8 max-w-4xl mx-auto">
              <div className="flex items-center justify-center gap-2 mb-4">
                <span className="text-2xl">🌍</span>
                <h2 className="text-2xl font-bold text-orange-800 dark:text-orange-200">
                  Food Connects All Humanity
                </h2>
                <span className="text-2xl">🤝</span>
              </div>
              <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                Beyond race, religion, caste, and ethnicity - food is our universal language of love, compassion, and unity. 
                Every shared meal builds bridges between communities, every helping hand strengthens our bonds as one human family. 
                Through interfaith collaboration and cross-cultural partnerships, we nourish both body and soul.
              </p>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            Welcome to FoodShare
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            A comprehensive community platform uniting people across all backgrounds through food sharing, 
            medical aid, clothing donations, and interfaith collaboration
          </p>
          
          <Button 
            size="lg" 
            className="text-lg px-8 py-4"
            onClick={() => window.location.href = '/api/login'}
          >
            Join Our Community
          </Button>
        </div>
      </section>

      {/* Complete Platform Features */}
      <section className="py-16 bg-white/50 dark:bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Complete Community Support Platform</h2>
            <p className="text-lg text-gray-600 dark:text-gray-300">
              Everything your community needs in one unified platform
            </p>
          </div>

          {/* Core Services */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-orange-100 dark:bg-orange-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Share2 className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Food Sharing</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Share meals, reduce waste, and connect with neighbors through food donations and requests
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-blue-100 dark:bg-blue-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Medical Aid</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Access free and low-cost healthcare services from verified medical providers
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-green-100 dark:bg-green-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Clothing Donations</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Connect with clothing NGOs and donation centers for essential clothing needs
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-purple-100 dark:bg-purple-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Food Banks</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Locate nearby food banks, distribution centers, and donation facilities
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Additional Services */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-red-100 dark:bg-red-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Corporate CSR</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Partner with businesses for large-scale community impact initiatives
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-yellow-100 dark:bg-yellow-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Interactive Maps</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Visualize nearby resources, donations, and community services on interactive maps
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-indigo-100 dark:bg-indigo-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="h-8 w-8 text-indigo-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Community Events</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Join and organize interfaith events, cultural exchanges, and collaborative programs
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Interfaith Community Partnerships */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-8">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold mb-3 text-purple-800 dark:text-purple-200">
                Interfaith Community Partnerships
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Building bridges between different faiths and cultures through collaborative service
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
              <div className="text-center">
                <div className="bg-purple-100 dark:bg-purple-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🏫</span>
                </div>
                <h4 className="font-semibold mb-2">Schools</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Educational institutions fostering community learning</p>
              </div>
              <div className="text-center">
                <div className="bg-purple-100 dark:bg-purple-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🕌</span>
                </div>
                <h4 className="font-semibold mb-2">Mosques</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Islamic centers promoting community unity</p>
              </div>
              <div className="text-center">
                <div className="bg-purple-100 dark:bg-purple-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🛕</span>
                </div>
                <h4 className="font-semibold mb-2">Temples</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Hindu and Buddhist temples serving all communities</p>
              </div>
              <div className="text-center">
                <div className="bg-purple-100 dark:bg-purple-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">⛪</span>
                </div>
                <h4 className="font-semibold mb-2">Churches</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Christian institutions embracing interfaith dialogue</p>
              </div>
              <div className="text-center">
                <div className="bg-purple-100 dark:bg-purple-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🕍</span>
                </div>
                <h4 className="font-semibold mb-2">Synagogues</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Jewish centers promoting interfaith collaboration</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Features Highlight */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Advanced Platform Features</h2>
            <p className="text-lg text-gray-600 dark:text-gray-300">
              Powerful tools to enhance community collaboration
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-emerald-100 dark:bg-emerald-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Smart Search</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Advanced filtering by location, dietary preferences, and availability
              </p>
            </div>

            <div className="text-center">
              <div className="bg-cyan-100 dark:bg-cyan-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="h-8 w-8 text-cyan-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Dietary Options</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Vegetarian, vegan, halal, kosher, and other dietary accommodations
              </p>
            </div>

            <div className="text-center">
              <div className="bg-pink-100 dark:bg-pink-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-pink-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">User Ratings</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Community-driven trust system with ratings and reviews
              </p>
            </div>

            <div className="text-center">
              <div className="bg-amber-100 dark:bg-amber-900/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Global Impact</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Track community impact and celebrate collective achievements
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* UN SDG Banner */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🎯</span>
              <div>
                <h3 className="text-2xl font-bold">UN SDG 2: ZERO HUNGER</h3>
                <p className="text-blue-100">Supporting Global Sustainability Goals</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-3xl">🤝</span>
              <div>
                <h3 className="text-2xl font-bold">UN SDG 17: PARTNERSHIPS</h3>
                <p className="text-blue-100">Building Communities Together</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Animal Welfare Section - Compact */}
      <section className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <div className="flex justify-center items-center mb-4">
              <span className="text-2xl mr-2">🐾</span>
              <h2 className="text-2xl font-bold text-green-800 dark:text-green-200">
                Extending Compassion to All Living Beings
              </h2>
              <span className="text-2xl ml-2">🐕</span>
            </div>
            <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Our mission extends beyond humans to all sentient beings through partnerships with animal welfare organizations.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-green-100 dark:bg-green-900/30 w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="text-xl">🐕</span>
                </div>
                <div>
                  <h3 className="font-semibold">Animal Welfare Partnerships</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">PETA, ASPCA, Local Shelters</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Coordinated feeding programs for stray animals through specialized protocols and veterinary oversight.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-amber-100 dark:bg-amber-900/30 w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="text-xl">⚠️</span>
                </div>
                <div>
                  <h3 className="font-semibold">Safety Guidelines</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Separate Programs, Same Compassion</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Animal and human programs operate independently with specialized protocols to ensure safety and regulatory compliance.
              </p>
            </div>
          </div>

          <div className="text-center">
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-green-600 hover:bg-green-700 text-white border-green-600"
              onClick={() => window.open('https://www.peta.org', '_blank')}
            >
              <Heart className="mr-2 h-4 w-4" />
              Learn About Animal Welfare
            </Button>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Make a Difference?</h2>
          <p className="text-xl mb-8">
            Join thousands of community members working together to create positive change
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            className="text-lg px-8 py-4"
            onClick={() => window.location.href = '/api/login'}
          >
            Get Started Today
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <span className="text-2xl">🍽️</span>
            <span className="text-xl font-bold">FoodShare</span>
          </div>
          <p className="text-gray-400">
            Building stronger communities through food, compassion, and unity
          </p>
        </div>
      </footer>
    </div>
  );
}