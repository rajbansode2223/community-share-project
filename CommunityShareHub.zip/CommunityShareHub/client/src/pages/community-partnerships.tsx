import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { GraduationCap, Church, Users, MapPin, Clock, Star, Plus, Search, Filter, Heart, Globe } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import { apiRequest, queryClient } from "@/lib/queryClient";

const communityInstitutionSchema = z.object({
  institutionName: z.string().min(2, "Institution name must be at least 2 characters"),
  institutionType: z.string().min(1, "Institution type is required"),
  contactPerson: z.string().min(2, "Contact person name is required"),
  contactTitle: z.string().optional(),
  contactEmail: z.string().email("Valid email is required"),
  contactPhone: z.string().min(10, "Valid phone number is required"),
  address: z.string().min(5, "Full address is required"),
  city: z.string().min(2, "City is required"),
  state: z.string().min(2, "State is required"),
  postalCode: z.string().min(5, "Valid postal code is required"),
  capacity: z.number().min(1, "Capacity must be at least 1"),
  establishedYear: z.number().min(1800, "Valid establishment year required").optional(),
  servicesOffered: z.array(z.string()).min(1, "At least one service is required"),
  operatingHours: z.string().min(5, "Operating hours are required"),
  targetCommunity: z.string().min(10, "Target community description is required"),
  collaborationAreas: z.array(z.string()).min(1, "At least one collaboration area is required"),
  facilitiesAvailable: z.array(z.string()).min(1, "At least one facility is required"),
  languagesSupported: z.array(z.string()).min(1, "At least one language is required"),
  dietaryAccommodations: z.array(z.string()).optional(),
  volunteerCapacity: z.number().min(0, "Volunteer capacity must be 0 or more"),
  donationPreferences: z.array(z.string()).min(1, "At least one donation preference required"),
  pickupAvailable: z.boolean(),
  deliveryAvailable: z.boolean(),
  storageCapacity: z.string().min(1, "Storage capacity is required"),
  refrigerationAvailable: z.boolean(),
  registrationNumber: z.string().optional(),
  interfaithParticipation: z.boolean(),
  youthPrograms: z.boolean(),
  seniorPrograms: z.boolean(),
  familyPrograms: z.boolean(),
  educationalLevel: z.string().optional(),
  denomination: z.string().optional(),
});

type CommunityInstitutionForm = z.infer<typeof communityInstitutionSchema>;

export default function CommunityPartnerships() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showRegisterForm, setShowRegisterForm] = useState(false);
  const [filters, setFilters] = useState({
    search: "",
    institutionType: "all",
    location: "all",
    interfaith: "all"
  });

  const { data: institutions, isLoading, refetch } = useQuery({
    queryKey: ["/api/community-institutions"],
  });

  const form = useForm<CommunityInstitutionForm>({
    resolver: zodResolver(communityInstitutionSchema),
    defaultValues: {
      institutionName: "",
      institutionType: "",
      contactPerson: "",
      contactTitle: "",
      contactEmail: "",
      contactPhone: "",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      capacity: 50,
      establishedYear: undefined,
      servicesOffered: [],
      operatingHours: "",
      targetCommunity: "",
      collaborationAreas: [],
      facilitiesAvailable: [],
      languagesSupported: [],
      dietaryAccommodations: [],
      volunteerCapacity: 0,
      donationPreferences: [],
      pickupAvailable: false,
      deliveryAvailable: false,
      storageCapacity: "",
      refrigerationAvailable: false,
      registrationNumber: "",
      interfaithParticipation: true,
      youthPrograms: false,
      seniorPrograms: false,
      familyPrograms: false,
      educationalLevel: "",
      denomination: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: CommunityInstitutionForm) => {
      await apiRequest("/api/community-institutions", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Registration Submitted",
        description: "Your community institution registration is under review.",
      });
      setShowRegisterForm(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/community-institutions"] });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredInstitutions = institutions?.filter((institution: any) => {
    const matchesSearch = !filters.search || 
      institution.institutionName.toLowerCase().includes(filters.search.toLowerCase()) ||
      institution.city.toLowerCase().includes(filters.search.toLowerCase()) ||
      institution.targetCommunity.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesType = filters.institutionType === "all" || institution.institutionType === filters.institutionType;
    const matchesLocation = filters.location === "all" || institution.city.toLowerCase().includes(filters.location.toLowerCase());
    const matchesInterfaith = filters.interfaith === "all" || 
      (filters.interfaith === "yes" && institution.interfaithParticipation) ||
      (filters.interfaith === "no" && !institution.interfaithParticipation);
    
    return matchesSearch && matchesType && matchesLocation && matchesInterfaith && institution.status === 'approved';
  });

  const onSubmit = (data: CommunityInstitutionForm) => {
    registerMutation.mutate(data);
  };

  const institutionTypes = [
    "school", "mosque", "temple", "church", "synagogue", "community_center"
  ];

  const servicesOptions = [
    "food_distribution", "educational_programs", "community_events", "interfaith_dialogue",
    "youth_mentorship", "senior_care", "cultural_programs", "language_classes"
  ];

  const collaborationOptions = [
    "food_sharing", "educational_outreach", "interfaith_events", "community_service",
    "cultural_exchange", "volunteer_coordination", "emergency_response", "social_harmony"
  ];

  const facilityOptions = [
    "kitchen", "dining_hall", "meeting_rooms", "parking", "playground",
    "library", "computer_lab", "sports_facilities", "prayer_hall", "classrooms"
  ];

  const languageOptions = [
    "english", "spanish", "arabic", "hindi", "mandarin", "french", "urdu", "bengali"
  ];

  const dietaryOptions = [
    "halal", "kosher", "vegetarian", "vegan", "gluten_free", "no_restrictions"
  ];

  const donationOptions = [
    "non_perishable", "fresh_produce", "cooked_meals", "educational_materials",
    "clothing", "books", "toys", "school_supplies"
  ];

  const getInstitutionIcon = (type: string) => {
    switch (type) {
      case 'school':
        return <GraduationCap className="h-5 w-5" />;
      case 'mosque':
      case 'temple':
      case 'church':
      case 'synagogue':
        return <Church className="h-5 w-5" />;
      default:
        return <Users className="h-5 w-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Community Partnerships</h1>
          <div className="flex items-center gap-2 mb-4">
            <Heart className="h-5 w-5 text-red-500" />
            <span className="text-lg text-gray-600 dark:text-gray-300 font-medium">Promoting Social Harmony</span>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Connect with local schools, mosques, temples, churches, and community centers to build bridges, 
            share resources, and promote interfaith collaboration in your community.
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search institutions, locations, or communities..."
              className="pl-10"
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            />
          </div>
          
          <div className="flex gap-2">
            <Select value={filters.institutionType} onValueChange={(value) => setFilters(prev => ({ ...prev, institutionType: value }))}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Institution Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="school">Schools</SelectItem>
                <SelectItem value="mosque">Mosques</SelectItem>
                <SelectItem value="temple">Temples</SelectItem>
                <SelectItem value="church">Churches</SelectItem>
                <SelectItem value="synagogue">Synagogues</SelectItem>
                <SelectItem value="community_center">Community Centers</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.interfaith} onValueChange={(value) => setFilters(prev => ({ ...prev, interfaith: value }))}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Interfaith" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="yes">Interfaith</SelectItem>
                <SelectItem value="no">Single Faith</SelectItem>
              </SelectContent>
            </Select>

            <Dialog open={showRegisterForm} onOpenChange={setShowRegisterForm}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Register Institution
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Register Community Institution</DialogTitle>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="institutionName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Institution Name</FormLabel>
                            <FormControl>
                              <Input placeholder="St. Mary's School / Al-Noor Mosque" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="institutionType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Institution Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {institutionTypes.map(type => (
                                  <SelectItem key={type} value={type}>
                                    {type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ')}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="contactPerson"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Person</FormLabel>
                            <FormControl>
                              <Input placeholder="Principal / Imam / Pastor" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="contactTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Principal, Imam, Pastor, Rabbi" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="contactEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Email</FormLabel>
                            <FormControl>
                              <Input placeholder="contact@institution.org" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="+1234567890" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Address</FormLabel>
                          <FormControl>
                            <Input placeholder="123 Main Street" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input placeholder="City" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State</FormLabel>
                            <FormControl>
                              <Input placeholder="State" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="postalCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Postal Code</FormLabel>
                            <FormControl>
                              <Input placeholder="12345" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="space-y-3">
                      <FormLabel>Services Offered</FormLabel>
                      <div className="grid grid-cols-2 gap-2">
                        {servicesOptions.map((service) => (
                          <FormField
                            key={service}
                            control={form.control}
                            name="servicesOffered"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(service)}
                                    onCheckedChange={(checked) => {
                                      if (checked) {
                                        field.onChange([...field.value, service]);
                                      } else {
                                        field.onChange(field.value?.filter((value) => value !== service));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal">
                                  {service.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    <FormField
                      control={form.control}
                      name="targetCommunity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Community Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe the community you serve (e.g., local families, students, elderly, interfaith community...)"
                              className="min-h-[80px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="interfaithParticipation"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Interfaith Participation</FormLabel>
                              <p className="text-xs text-muted-foreground">
                                Open to collaborating with other faiths
                              </p>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="youthPrograms"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Youth Programs</FormLabel>
                              <p className="text-xs text-muted-foreground">
                                Programs for children and teenagers
                              </p>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button type="button" variant="outline" onClick={() => setShowRegisterForm(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={registerMutation.isPending}>
                        {registerMutation.isPending ? "Submitting..." : "Submit Registration"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Community Institutions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredInstitutions?.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Globe className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No Institutions Found</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                No community institutions match your current search criteria.
              </p>
            </div>
          ) : (
            filteredInstitutions?.map((institution: any) => (
              <Card key={institution.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                        {getInstitutionIcon(institution.institutionType)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{institution.institutionName}</CardTitle>
                        <p className="text-sm text-blue-600 dark:text-blue-400 capitalize">
                          {institution.institutionType.replace('_', ' ')}
                        </p>
                      </div>
                    </div>
                    {institution.interfaithParticipation && (
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        Interfaith
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <MapPin className="h-4 w-4" />
                      {institution.city}, {institution.state}
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <Clock className="h-4 w-4" />
                      {institution.operatingHours}
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <Users className="h-4 w-4" />
                      <span className="line-clamp-2">{institution.targetCommunity}</span>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {institution.servicesOffered?.slice(0, 3).map((service: string) => (
                        <Badge key={service} variant="outline" className="text-xs">
                          {service.replace(/_/g, ' ')}
                        </Badge>
                      ))}
                      {institution.servicesOffered?.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{institution.servicesOffered.length - 3} more
                        </Badge>
                      )}
                    </div>

                    <Button className="w-full mt-4">
                      Connect & Collaborate
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}