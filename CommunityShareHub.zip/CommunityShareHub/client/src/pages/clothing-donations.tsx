import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Users, MapPin, Clock, Star, Plus, Search, Filter, Shirt } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import { apiRequest, queryClient } from "@/lib/queryClient";

const clothingNgoSchema = z.object({
  organizationName: z.string().min(2, "Organization name must be at least 2 characters"),
  registrationNumber: z.string().min(5, "Valid registration number is required"),
  contactPerson: z.string().min(2, "Contact person name is required"),
  contactPhone: z.string().min(10, "Valid phone number is required"),
  contactEmail: z.string().email("Valid email is required"),
  location: z.string().min(2, "Location is required"),
  serviceAreas: z.array(z.string()).min(1, "At least one service area is required"),
  clothingTypes: z.array(z.string()).min(1, "At least one clothing type is required"),
  targetBeneficiaries: z.string().min(10, "Target beneficiaries description is required"),
  operatingHours: z.string().min(5, "Operating hours are required"),
  pickupAvailable: z.boolean(),
  dropoffAvailable: z.boolean(),
  description: z.string().min(20, "Description must be at least 20 characters"),
  website: z.string().optional(),
});

type ClothingNgoForm = z.infer<typeof clothingNgoSchema>;

export default function ClothingDonations() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showRegisterForm, setShowRegisterForm] = useState(false);
  const [filters, setFilters] = useState({
    search: "",
    clothingType: "all",
    location: "all",
    serviceType: "all"
  });

  const { data: ngos, isLoading, refetch } = useQuery({
    queryKey: ["/api/clothing-ngos"],
  });

  const form = useForm<ClothingNgoForm>({
    resolver: zodResolver(clothingNgoSchema),
    defaultValues: {
      organizationName: "",
      registrationNumber: "",
      contactPerson: "",
      contactPhone: "",
      contactEmail: "",
      location: "",
      serviceAreas: [],
      clothingTypes: [],
      targetBeneficiaries: "",
      operatingHours: "",
      pickupAvailable: false,
      dropoffAvailable: false,
      description: "",
      website: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: ClothingNgoForm) => {
      await apiRequest("/api/clothing-ngos", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Registration Submitted",
        description: "Your NGO registration is under review.",
      });
      setShowRegisterForm(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/clothing-ngos"] });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredNgos = ngos?.filter((ngo: any) => {
    const matchesSearch = !filters.search || 
      ngo.organizationName.toLowerCase().includes(filters.search.toLowerCase()) ||
      ngo.location.toLowerCase().includes(filters.search.toLowerCase()) ||
      ngo.targetBeneficiaries.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesClothingType = filters.clothingType === "all" || ngo.clothingTypes.includes(filters.clothingType);
    const matchesLocation = filters.location === "all" || ngo.location.includes(filters.location);
    const matchesServiceType = filters.serviceType === "all" || 
      (filters.serviceType === "pickup" && ngo.pickupAvailable) ||
      (filters.serviceType === "dropoff" && ngo.dropoffAvailable);
    
    return matchesSearch && matchesClothingType && matchesLocation && matchesServiceType && ngo.status === 'approved';
  });

  const onSubmit = (data: ClothingNgoForm) => {
    registerMutation.mutate(data);
  };

  const clothingTypeOptions = [
    "Adult Clothing",
    "Children's Clothing",
    "Baby Clothes",
    "Winter Wear",
    "Professional Attire",
    "Shoes",
    "Accessories",
    "Uniforms"
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Clothing Donations</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Find verified NGOs accepting clothing donations to help those in need in your community.
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search organizations, locations, or beneficiaries..."
              className="pl-10"
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            />
          </div>
          
          <div className="flex gap-2">
            <Select value={filters.clothingType} onValueChange={(value) => setFilters(prev => ({ ...prev, clothingType: value }))}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Clothing Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {clothingTypeOptions.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.serviceType} onValueChange={(value) => setFilters(prev => ({ ...prev, serviceType: value }))}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Service" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Services</SelectItem>
                <SelectItem value="pickup">Pickup Available</SelectItem>
                <SelectItem value="dropoff">Drop-off Only</SelectItem>
              </SelectContent>
            </Select>

            <Dialog open={showRegisterForm} onOpenChange={setShowRegisterForm}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Register NGO
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Register Clothing Donation NGO</DialogTitle>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="organizationName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Organization Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Hope Foundation" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="registrationNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Registration Number</FormLabel>
                            <FormControl>
                              <Input placeholder="NGO123456" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="contactPerson"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Person</FormLabel>
                            <FormControl>
                              <Input placeholder="John Smith" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="+1234567890" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="contactEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Email</FormLabel>
                            <FormControl>
                              <Input placeholder="contact@ngo.org" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <Input placeholder="City, State" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="operatingHours"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Operating Hours</FormLabel>
                          <FormControl>
                            <Input placeholder="Mon-Fri 9AM-5PM, Sat 10AM-3PM" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="space-y-3">
                      <FormLabel>Clothing Types Accepted</FormLabel>
                      <div className="grid grid-cols-2 gap-2">
                        {clothingTypeOptions.map((type) => (
                          <FormField
                            key={type}
                            control={form.control}
                            name="clothingTypes"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(type)}
                                    onCheckedChange={(checked) => {
                                      if (checked) {
                                        field.onChange([...field.value, type]);
                                      } else {
                                        field.onChange(field.value?.filter((value) => value !== type));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal">
                                  {type}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="pickupAvailable"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Pickup Available</FormLabel>
                              <p className="text-xs text-muted-foreground">
                                We can pick up donations
                              </p>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="dropoffAvailable"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Drop-off Available</FormLabel>
                              <p className="text-xs text-muted-foreground">
                                Donors can drop off items
                              </p>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="targetBeneficiaries"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Beneficiaries</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe who will benefit from donations (e.g., homeless individuals, low-income families, children in foster care...)"
                              className="min-h-[80px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Organization Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your organization's mission, services, and impact in the community..."
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex gap-2 pt-4">
                      <Button type="button" variant="outline" onClick={() => setShowRegisterForm(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={registerMutation.isPending}>
                        {registerMutation.isPending ? "Submitting..." : "Submit Registration"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* NGOs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredNgos?.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Shirt className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No NGOs Found</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                No organizations match your current search criteria.
              </p>
            </div>
          ) : (
            filteredNgos?.map((ngo: any) => (
              <Card key={ngo.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{ngo.organizationName}</CardTitle>
                      <p className="text-sm text-purple-600 dark:text-purple-400">{ngo.contactPerson}</p>
                    </div>
                    <div className="flex gap-1">
                      {ngo.pickupAvailable && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                          Pickup
                        </Badge>
                      )}
                      {ngo.dropoffAvailable && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                          Drop-off
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <MapPin className="h-4 w-4" />
                      {ngo.location}
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <Clock className="h-4 w-4" />
                      {ngo.operatingHours}
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <Users className="h-4 w-4" />
                      <span className="line-clamp-2">{ngo.targetBeneficiaries}</span>
                    </div>

                    <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-3">
                      {ngo.description}
                    </p>

                    <div className="flex flex-wrap gap-1">
                      {ngo.clothingTypes?.slice(0, 3).map((type: string) => (
                        <Badge key={type} variant="outline" className="text-xs">
                          {type}
                        </Badge>
                      ))}
                      {ngo.clothingTypes?.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{ngo.clothingTypes.length - 3} more
                        </Badge>
                      )}
                    </div>

                    <Button className="w-full mt-4">
                      Contact Organization
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}